--
-- PostgreSQL database dump
--

\restrict 25VSQ2HK8jjOaAO2jIB5TaZbvuKIuBHhwAvm70S9ierSBgknBp5XX0y5UQ7DFNQ

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    id integer NOT NULL,
    version integer NOT NULL,
    name character varying(100) NOT NULL,
    applied_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: _migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public._migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: _migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public._migrations_id_seq OWNED BY public._migrations.id;


--
-- Name: active_print_spoolman; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_print_spoolman (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    archive_id integer NOT NULL,
    filament_usage json NOT NULL,
    ams_trays json NOT NULL,
    slot_to_tray json,
    layer_usage json,
    filament_properties json
);


--
-- Name: active_print_spoolman_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_print_spoolman_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_print_spoolman_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_print_spoolman_id_seq OWNED BY public.active_print_spoolman.id;


--
-- Name: ams_labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ams_labels (
    id integer NOT NULL,
    ams_serial_number character varying(50) NOT NULL,
    ams_id integer,
    label character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ams_labels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ams_labels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ams_labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ams_labels_id_seq OWNED BY public.ams_labels.id;


--
-- Name: ams_sensor_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ams_sensor_history (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    ams_id integer NOT NULL,
    humidity double precision,
    humidity_raw double precision,
    temperature double precision,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ams_sensor_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ams_sensor_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ams_sensor_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ams_sensor_history_id_seq OWNED BY public.ams_sensor_history.id;


--
-- Name: ams_setting_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ams_setting_audit (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    user_id integer,
    action character varying(50) NOT NULL,
    payload_json text NOT NULL,
    sequence_id character varying(50),
    result character varying(20) NOT NULL,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: ams_setting_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ams_setting_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ams_setting_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ams_setting_audit_id_seq OWNED BY public.ams_setting_audit.id;


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(16) NOT NULL,
    can_queue boolean NOT NULL,
    can_control_printer boolean NOT NULL,
    can_read_status boolean NOT NULL,
    printer_ids json,
    enabled boolean NOT NULL,
    last_used timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp without time zone,
    user_id integer,
    can_access_cloud boolean DEFAULT false NOT NULL
);


--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: auth_ephemeral_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_ephemeral_tokens (
    id integer NOT NULL,
    token character varying(128) NOT NULL,
    token_type character varying(20) NOT NULL,
    username character varying(150),
    provider_id integer,
    nonce character varying(128),
    code_verifier character varying(128),
    challenge_id character varying(128),
    used_at timestamp without time zone,
    family_id character varying(32),
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: auth_ephemeral_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_ephemeral_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_ephemeral_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_ephemeral_tokens_id_seq OWNED BY public.auth_ephemeral_tokens.id;


--
-- Name: auth_rate_limit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_rate_limit_events (
    id integer NOT NULL,
    username character varying(150) NOT NULL,
    event_type character varying(20) NOT NULL,
    occurred_at timestamp without time zone NOT NULL
);


--
-- Name: auth_rate_limit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_rate_limit_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_rate_limit_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_rate_limit_events_id_seq OWNED BY public.auth_rate_limit_events.id;


--
-- Name: auto_queue_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_queue_items (
    id integer NOT NULL,
    archive_id integer,
    library_file_id integer,
    project_id integer,
    target_model character varying(50),
    target_location character varying(100),
    required_filament_types text,
    filament_overrides text,
    force_color_match boolean NOT NULL,
    plate_id integer,
    bed_levelling boolean NOT NULL,
    flow_cali boolean NOT NULL,
    layer_inspect boolean NOT NULL,
    timelapse boolean NOT NULL,
    use_ams boolean NOT NULL,
    mesh_mode_fast_check boolean NOT NULL,
    execute_swap_macros boolean NOT NULL,
    swap_macro_events text,
    "position" integer NOT NULL,
    scheduled_time timestamp without time zone,
    manual_start boolean NOT NULL,
    auto_off_after boolean NOT NULL,
    require_previous_success boolean NOT NULL,
    status character varying(20) NOT NULL,
    waiting_reason text,
    assigned_to_item_id integer,
    assigned_at timestamp without time zone,
    cancelled_at timestamp without time zone,
    print_time_seconds integer,
    been_jumped boolean NOT NULL,
    batch_id character varying(36),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by_id integer
);


--
-- Name: auto_queue_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auto_queue_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auto_queue_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auto_queue_items_id_seq OWNED BY public.auto_queue_items.id;


--
-- Name: bug_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bug_reports (
    id integer NOT NULL,
    description text NOT NULL,
    reporter_email character varying(255),
    github_issue_number integer,
    github_issue_url character varying(500),
    status character varying(20) DEFAULT 'submitted'::character varying NOT NULL,
    error_message text,
    email_sent boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: bug_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bug_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bug_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bug_reports_id_seq OWNED BY public.bug_reports.id;


--
-- Name: calibration_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calibration_audit (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    session_id integer,
    filament_calibration_id integer,
    user_id integer,
    action character varying(40) NOT NULL,
    payload_json text NOT NULL,
    sequence_id character varying(50),
    result character varying(20) NOT NULL,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: calibration_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.calibration_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: calibration_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.calibration_audit_id_seq OWNED BY public.calibration_audit.id;


--
-- Name: calibration_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calibration_session (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    user_id integer,
    cali_mode character varying(30) NOT NULL,
    method character varying(20) NOT NULL,
    nozzle_diameter double precision NOT NULL,
    nozzle_volume_type character varying(20) NOT NULL,
    extruder_id integer DEFAULT 0 NOT NULL,
    filaments_json text NOT NULL,
    status character varying(30) NOT NULL,
    mqtt_sequence_id character varying(50),
    print_queue_item_id integer,
    parent_session_id integer,
    stage integer DEFAULT 1 NOT NULL,
    coarse_ratio double precision,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    dispatch_args_json text
);


--
-- Name: calibration_session_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.calibration_session_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: calibration_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.calibration_session_id_seq OWNED BY public.calibration_session.id;


--
-- Name: color_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.color_catalog (
    id integer NOT NULL,
    manufacturer character varying(200) NOT NULL,
    color_name character varying(200) NOT NULL,
    hex_color character varying(7) NOT NULL,
    material character varying(100),
    is_default boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: color_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.color_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: color_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.color_catalog_id_seq OWNED BY public.color_catalog.id;


--
-- Name: external_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_links (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    url character varying(500) NOT NULL,
    icon character varying(50) NOT NULL,
    custom_icon character varying(255),
    open_in_new_tab boolean NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    nav_group character varying(20) DEFAULT 'external'::character varying NOT NULL
);


--
-- Name: external_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.external_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: external_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.external_links_id_seq OWNED BY public.external_links.id;


--
-- Name: filament_calibration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filament_calibration (
    id integer NOT NULL,
    filament_id character varying(50) NOT NULL,
    filament_setting_id character varying(100),
    nozzle_diameter double precision NOT NULL,
    nozzle_volume_type character varying(20) NOT NULL,
    extruder_id integer DEFAULT 0 NOT NULL,
    pa_k_value double precision,
    pa_n_coef double precision,
    flow_ratio double precision,
    confidence integer,
    cali_mode character varying(30) NOT NULL,
    source character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    cali_idx integer,
    name character varying(120) NOT NULL,
    notes text,
    nozzle_id character varying(20),
    calibrated_by_user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    printer_id integer,
    tower_result double precision
);


--
-- Name: filament_calibration_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filament_calibration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filament_calibration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filament_calibration_id_seq OWNED BY public.filament_calibration.id;


--
-- Name: filament_shopping_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filament_shopping_list (
    id integer NOT NULL,
    material character varying(50) NOT NULL,
    subtype character varying(50),
    brand character varying(100),
    quantity_spools integer DEFAULT 1 NOT NULL,
    note character varying(500),
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    purchased_at timestamp without time zone,
    added_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: filament_shopping_list_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filament_shopping_list_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filament_shopping_list_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filament_shopping_list_id_seq OWNED BY public.filament_shopping_list.id;


--
-- Name: filament_sku_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filament_sku_settings (
    id integer NOT NULL,
    material character varying(50) NOT NULL,
    subtype character varying(50),
    brand character varying(100),
    lead_time_days integer DEFAULT 0 NOT NULL,
    safety_margin_value integer DEFAULT 14 NOT NULL,
    safety_margin_unit character varying(10) DEFAULT 'days'::character varying NOT NULL,
    alerts_snoozed boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: filament_sku_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filament_sku_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filament_sku_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filament_sku_settings_id_seq OWNED BY public.filament_sku_settings.id;


--
-- Name: git_backup_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_backup_config (
    id integer NOT NULL,
    provider character varying(20) NOT NULL,
    repository_url character varying(500) NOT NULL,
    access_token text NOT NULL,
    branch character varying(100) NOT NULL,
    api_base_url character varying(500),
    schedule_enabled boolean NOT NULL,
    schedule_type character varying(20) NOT NULL,
    schedule_cron character varying(100),
    backup_kprofiles boolean NOT NULL,
    backup_cloud_profiles boolean NOT NULL,
    backup_settings boolean NOT NULL,
    backup_spools boolean NOT NULL,
    backup_archives boolean NOT NULL,
    enabled boolean NOT NULL,
    last_backup_at timestamp without time zone,
    last_backup_status character varying(20),
    last_backup_message text,
    last_backup_commit_sha character varying(40),
    next_scheduled_run timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: git_backup_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.git_backup_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: git_backup_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.git_backup_config_id_seq OWNED BY public.git_backup_config.id;


--
-- Name: git_backup_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_backup_logs (
    id integer NOT NULL,
    config_id integer NOT NULL,
    started_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp without time zone,
    status character varying(20) NOT NULL,
    trigger character varying(20) NOT NULL,
    commit_sha character varying(40),
    files_changed integer NOT NULL,
    error_message text
);


--
-- Name: git_backup_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.git_backup_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: git_backup_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.git_backup_logs_id_seq OWNED BY public.git_backup_logs.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    permissions json NOT NULL,
    is_system boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: kprofile_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kprofile_notes (
    id integer NOT NULL,
    filament_calibration_id integer NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: kprofile_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kprofile_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kprofile_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kprofile_notes_id_seq OWNED BY public.kprofile_notes.id;


--
-- Name: library_file_makerworld_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_file_makerworld_meta (
    id integer NOT NULL,
    library_file_id integer NOT NULL,
    title character varying(500),
    description text,
    author_name character varying(255),
    author_profile_url character varying(500),
    license character varying(64),
    original_design_id integer,
    variant_title character varying(500),
    variant_description text,
    variant_url character varying(500),
    profile_id integer,
    cover_path character varying(500),
    variant_cover_path character varying(500),
    sliced_for character varying(64),
    compatible_models jsonb,
    needs_ams boolean,
    material_count integer,
    materials jsonb,
    model_id_alphanumeric character varying(64),
    raw_payload jsonb,
    imported_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: library_file_makerworld_meta_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_file_makerworld_meta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_file_makerworld_meta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_file_makerworld_meta_id_seq OWNED BY public.library_file_makerworld_meta.id;


--
-- Name: library_file_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_file_notes (
    id integer NOT NULL,
    library_file_id integer NOT NULL,
    user_id integer,
    body character varying(1000) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: library_file_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_file_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_file_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_file_notes_id_seq OWNED BY public.library_file_notes.id;


--
-- Name: library_file_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_file_projects (
    file_id integer NOT NULL,
    project_id integer NOT NULL
);


--
-- Name: library_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_files (
    id integer NOT NULL,
    folder_id integer,
    is_external boolean DEFAULT false NOT NULL,
    filename character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_type character varying(10) NOT NULL,
    file_size integer NOT NULL,
    file_hash character varying(64),
    thumbnail_path character varying(500),
    file_metadata json,
    last_printed_at timestamp without time zone,
    notes text,
    created_by_id integer,
    swap_compatible boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    print_count integer DEFAULT 0 NOT NULL,
    deleted_at timestamp without time zone,
    source_type character varying(32),
    source_url character varying(512),
    file_tags json DEFAULT '[]'::json NOT NULL
);


--
-- Name: library_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_files_id_seq OWNED BY public.library_files.id;


--
-- Name: library_folder_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_folder_projects (
    folder_id integer NOT NULL,
    project_id integer NOT NULL
);


--
-- Name: library_folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_folders (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    parent_id integer,
    is_external boolean NOT NULL,
    external_readonly boolean NOT NULL,
    external_show_hidden boolean NOT NULL,
    external_path character varying(500),
    archive_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: library_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_folders_id_seq OWNED BY public.library_folders.id;


--
-- Name: local_presets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_presets (
    id integer NOT NULL,
    name character varying(300) NOT NULL,
    preset_type character varying(20) NOT NULL,
    source character varying(50) NOT NULL,
    filament_type character varying(50),
    filament_vendor character varying(200),
    nozzle_temp_min integer,
    nozzle_temp_max integer,
    pressure_advance character varying(50),
    default_filament_colour character varying(50),
    filament_cost character varying(50),
    filament_density character varying(50),
    compatible_printers text,
    setting text NOT NULL,
    inherits character varying(300),
    version character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: local_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.local_presets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: local_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.local_presets_id_seq OWNED BY public.local_presets.id;


--
-- Name: long_lived_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.long_lived_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(100) NOT NULL,
    lookup_prefix character varying(8) NOT NULL,
    secret_hash character varying(255) NOT NULL,
    scope character varying(32) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    last_used_at timestamp without time zone,
    revoked_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: long_lived_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.long_lived_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: long_lived_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.long_lived_tokens_id_seq OWNED BY public.long_lived_tokens.id;


--
-- Name: macros; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.macros (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    printer_models text NOT NULL,
    swap_mode_only boolean NOT NULL,
    swap_profile character varying(50),
    event character varying(50) NOT NULL,
    action_type character varying(20) DEFAULT 'gcode'::character varying NOT NULL,
    mqtt_action character varying(50),
    delay_seconds integer DEFAULT 0 NOT NULL,
    gcode text NOT NULL,
    is_custom boolean NOT NULL,
    enabled boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: macros_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.macros_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: macros_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.macros_id_seq OWNED BY public.macros.id;


--
-- Name: maintenance_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_history (
    id integer NOT NULL,
    printer_maintenance_id integer NOT NULL,
    performed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    hours_at_maintenance double precision NOT NULL,
    notes text,
    performed_by_user_id integer,
    performed_by_chat_id integer
);


--
-- Name: maintenance_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.maintenance_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maintenance_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.maintenance_history_id_seq OWNED BY public.maintenance_history.id;


--
-- Name: maintenance_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_types (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    default_interval_hours double precision NOT NULL,
    interval_type character varying(20) NOT NULL,
    icon character varying(50),
    wiki_url character varying(500),
    printer_models text NOT NULL,
    type_code character varying(50),
    is_system boolean NOT NULL,
    is_deleted boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: maintenance_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.maintenance_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maintenance_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.maintenance_types_id_seq OWNED BY public.maintenance_types.id;


--
-- Name: notification_digest_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_digest_queue (
    id integer NOT NULL,
    provider_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    printer_id integer,
    printer_name character varying(100),
    created_at timestamp without time zone
);


--
-- Name: notification_digest_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_digest_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_digest_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_digest_queue_id_seq OWNED BY public.notification_digest_queue.id;


--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_logs (
    id integer NOT NULL,
    provider_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    success boolean,
    error_message text,
    printer_id integer,
    printer_name character varying(100),
    created_at timestamp without time zone
);


--
-- Name: notification_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_logs_id_seq OWNED BY public.notification_logs.id;


--
-- Name: notification_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_providers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    provider_type character varying(50) NOT NULL,
    enabled boolean,
    config text NOT NULL,
    on_print_start boolean,
    on_print_complete boolean,
    on_print_failed boolean,
    on_print_stopped boolean,
    on_print_progress boolean,
    on_print_missing_spool_assignment boolean,
    on_printer_offline boolean,
    on_printer_error boolean,
    on_filament_low boolean,
    on_maintenance_due boolean,
    on_ams_humidity_high boolean,
    on_ams_temperature_high boolean,
    on_ams_ht_humidity_high boolean,
    on_ams_ht_temperature_high boolean,
    on_plate_not_empty boolean,
    on_bed_cooled boolean,
    on_first_layer_complete boolean,
    on_queue_job_added boolean,
    on_queue_job_started boolean,
    on_queue_job_waiting boolean,
    on_queue_job_skipped boolean,
    on_queue_job_failed boolean,
    on_queue_completed boolean,
    quiet_hours_enabled boolean,
    quiet_hours_start character varying(5),
    quiet_hours_end character varying(5),
    daily_digest_enabled boolean,
    daily_digest_time character varying(5),
    printer_id integer,
    last_success timestamp without time zone,
    last_error text,
    last_error_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    on_print_paused boolean DEFAULT true,
    on_print_resumed boolean DEFAULT true,
    on_stock_reorder_alert boolean DEFAULT false NOT NULL,
    on_stock_break_alert boolean DEFAULT false NOT NULL,
    on_printer_queue_completed boolean DEFAULT true
);


--
-- Name: notification_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_providers_id_seq OWNED BY public.notification_providers.id;


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_templates (
    id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    title_template text NOT NULL,
    body_template text NOT NULL,
    is_default boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_templates_id_seq OWNED BY public.notification_templates.id;


--
-- Name: oidc_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oidc_providers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    issuer_url character varying(500) NOT NULL,
    client_id character varying(255) NOT NULL,
    client_secret character varying(512) NOT NULL,
    scopes character varying(500) NOT NULL,
    is_enabled boolean NOT NULL,
    auto_create_users boolean NOT NULL,
    auto_link_existing_accounts boolean NOT NULL,
    email_claim character varying(64) DEFAULT 'email'::character varying NOT NULL,
    require_email_verified boolean DEFAULT true NOT NULL,
    icon_url text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    default_group_id integer,
    CONSTRAINT ck_auto_link_requires_verified_email_claim CHECK (((auto_link_existing_accounts = false) OR ((email_claim)::text <> 'email'::text) OR (require_email_verified = true)))
);


--
-- Name: oidc_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oidc_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oidc_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oidc_providers_id_seq OWNED BY public.oidc_providers.id;


--
-- Name: orca_base_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orca_base_profiles (
    id integer NOT NULL,
    name character varying(300) NOT NULL,
    profile_type character varying(20) NOT NULL,
    setting text NOT NULL,
    fetched_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: orca_base_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orca_base_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orca_base_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orca_base_profiles_id_seq OWNED BY public.orca_base_profiles.id;


--
-- Name: print_archives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_archives (
    id integer NOT NULL,
    printer_id integer,
    project_id integer,
    library_file_id integer,
    queue_id integer,
    batch_id character varying(36),
    error_message text,
    filename character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer NOT NULL,
    content_hash character varying(64),
    source_content_hash character varying(64),
    applied_patches text,
    subtask_id character varying(64),
    thumbnail_path character varying(500),
    timelapse_path character varying(500),
    source_3mf_path character varying(500),
    f3d_path character varying(500),
    print_name character varying(255),
    print_time_seconds integer,
    filament_used_grams double precision,
    filament_type character varying(50),
    filament_color character varying(50),
    layer_height double precision,
    total_layers integer,
    nozzle_diameter double precision,
    bed_temperature integer,
    nozzle_temperature integer,
    sliced_for_model character varying(50),
    plate_index integer,
    status character varying(20) NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    extra_data json,
    makerworld_url character varying(500),
    designer character varying(255),
    external_url character varying(500),
    is_favorite boolean NOT NULL,
    tags text,
    notes text,
    cost double precision,
    photos json,
    failure_reason character varying(100),
    quantity integer NOT NULL,
    energy_kwh double precision,
    energy_cost double precision,
    energy_start_kwh double precision,
    swap_compatible boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp without time zone,
    created_by_id integer,
    bed_type character varying(64),
    is_calibration boolean DEFAULT false NOT NULL,
    calibration_session_id integer,
    from_auto_queue boolean DEFAULT false NOT NULL
);


--
-- Name: print_archives_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.print_archives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: print_archives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.print_archives_id_seq OWNED BY public.print_archives.id;


--
-- Name: print_options_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_options_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    printer_model character varying(64) NOT NULL,
    options json NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: print_options_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.print_options_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: print_options_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.print_options_preferences_id_seq OWNED BY public.print_options_preferences.id;


--
-- Name: print_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_queue (
    id integer NOT NULL,
    queue_id integer NOT NULL,
    waiting_reason text,
    archive_id integer,
    library_file_id integer,
    project_id integer,
    "position" integer DEFAULT 0 NOT NULL,
    scheduled_time timestamp without time zone,
    manual_start boolean DEFAULT false NOT NULL,
    auto_off_after boolean DEFAULT false NOT NULL,
    ams_mapping text,
    plate_id integer,
    bed_levelling boolean DEFAULT true NOT NULL,
    flow_cali boolean DEFAULT true NOT NULL,
    layer_inspect boolean DEFAULT false NOT NULL,
    timelapse boolean DEFAULT false NOT NULL,
    use_ams boolean DEFAULT true NOT NULL,
    mesh_mode_fast_check boolean DEFAULT true NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    execute_swap_macros boolean DEFAULT true,
    swap_macro_events text,
    batch_id character varying(36),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by_id integer,
    source_auto_item_id integer,
    gcode_injection boolean DEFAULT false NOT NULL,
    is_calibration boolean DEFAULT false NOT NULL,
    calibration_session_id integer
);


--
-- Name: print_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.print_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: print_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.print_queue_id_seq OWNED BY public.print_queue.id;


--
-- Name: printer_maintenance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_maintenance (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    maintenance_type_id integer NOT NULL,
    custom_interval_hours double precision,
    custom_interval_type character varying(20),
    enabled boolean NOT NULL,
    last_performed_at timestamp without time zone,
    last_performed_hours double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: printer_maintenance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printer_maintenance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_maintenance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printer_maintenance_id_seq OWNED BY public.printer_maintenance.id;


--
-- Name: printer_queues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_queues (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    status character varying(20) DEFAULT 'idle'::character varying NOT NULL,
    last_activity_at timestamp without time zone,
    current_item_id integer,
    pending_count integer DEFAULT 0 NOT NULL,
    skipped_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auto_distribute_eligible boolean DEFAULT true NOT NULL,
    is_paused boolean DEFAULT false NOT NULL
);


--
-- Name: printer_queues_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printer_queues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printer_queues_id_seq OWNED BY public.printer_queues.id;


--
-- Name: printer_setting_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_setting_audit (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    user_id integer,
    tab character varying(30) NOT NULL,
    action character varying(50) NOT NULL,
    payload_json text NOT NULL,
    sequence_id character varying(50),
    result character varying(20) NOT NULL,
    error_message text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: printer_setting_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printer_setting_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_setting_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printer_setting_audit_id_seq OWNED BY public.printer_setting_audit.id;


--
-- Name: printers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    serial_number character varying(50) NOT NULL,
    ip_address character varying(253) NOT NULL,
    access_code character varying(20) NOT NULL,
    model character varying(50),
    location character varying(100),
    nozzle_count integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    auto_archive boolean DEFAULT true NOT NULL,
    cleanup_after_print boolean DEFAULT false NOT NULL,
    mqtt_connection_timeout integer DEFAULT 900 NOT NULL,
    print_hours_offset double precision DEFAULT 0.0 NOT NULL,
    runtime_seconds integer DEFAULT 0 NOT NULL,
    last_runtime_update timestamp without time zone,
    external_camera_url character varying(500),
    external_camera_type character varying(20),
    external_camera_enabled boolean DEFAULT false NOT NULL,
    camera_rotation integer DEFAULT 0 NOT NULL,
    plate_detection_enabled boolean DEFAULT false NOT NULL,
    plate_detection_roi_x double precision,
    plate_detection_roi_y double precision,
    plate_detection_roi_w double precision,
    plate_detection_roi_h double precision,
    stagger_interval_minutes integer DEFAULT 0 NOT NULL,
    swap_mode_enabled boolean DEFAULT false NOT NULL,
    swap_profile character varying(50),
    require_plate_clear boolean DEFAULT true NOT NULL,
    awaiting_plate_clear boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    external_camera_snapshot_url character varying(500)
);


--
-- Name: printers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printers_id_seq OWNED BY public.printers.id;


--
-- Name: project_bom_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_bom_items (
    id integer NOT NULL,
    project_id integer NOT NULL,
    name character varying(255) NOT NULL,
    quantity_needed integer NOT NULL,
    quantity_acquired integer NOT NULL,
    unit_price double precision,
    sourcing_url character varying(512),
    archive_id integer,
    stl_filename character varying(255),
    remarks text,
    sort_order integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: project_bom_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_bom_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_bom_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_bom_items_id_seq OWNED BY public.project_bom_items.id;


--
-- Name: project_print_plan_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_print_plan_items (
    id integer NOT NULL,
    project_id integer NOT NULL,
    library_file_id integer NOT NULL,
    copies integer DEFAULT 1 NOT NULL,
    order_index integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: project_print_plan_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_print_plan_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_print_plan_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_print_plan_items_id_seq OWNED BY public.project_print_plan_items.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    color character varying(20),
    status character varying(20) NOT NULL,
    target_count integer,
    target_parts_count integer,
    notes text,
    attachments json,
    tags text,
    due_date timestamp without time zone,
    priority character varying(20) NOT NULL,
    budget double precision,
    is_template boolean NOT NULL,
    template_source_id integer,
    parent_id integer,
    url character varying(2048),
    cover_image_filename character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: slot_preset_mappings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slot_preset_mappings (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    ams_id integer NOT NULL,
    tray_id integer NOT NULL,
    preset_id character varying(100) NOT NULL,
    preset_name character varying(200) NOT NULL,
    preset_source character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: slot_preset_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.slot_preset_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: slot_preset_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.slot_preset_mappings_id_seq OWNED BY public.slot_preset_mappings.id;


--
-- Name: smart_plug_energy_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_plug_energy_snapshots (
    id integer NOT NULL,
    plug_id integer NOT NULL,
    recorded_at timestamp without time zone NOT NULL,
    lifetime_kwh double precision NOT NULL
);


--
-- Name: smart_plug_energy_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_plug_energy_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_plug_energy_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_plug_energy_snapshots_id_seq OWNED BY public.smart_plug_energy_snapshots.id;


--
-- Name: smart_plugs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_plugs (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    ip_address character varying(45),
    plug_type character varying(20) NOT NULL,
    ha_entity_id character varying(100),
    ha_power_entity character varying(100),
    ha_energy_today_entity character varying(100),
    ha_energy_total_entity character varying(100),
    mqtt_topic character varying(200),
    mqtt_power_topic character varying(200),
    mqtt_power_path character varying(100),
    mqtt_power_multiplier double precision NOT NULL,
    mqtt_energy_topic character varying(200),
    mqtt_energy_path character varying(100),
    mqtt_energy_multiplier double precision NOT NULL,
    mqtt_state_topic character varying(200),
    mqtt_state_path character varying(100),
    mqtt_state_on_value character varying(50),
    mqtt_multiplier double precision NOT NULL,
    rest_on_url character varying(500),
    rest_on_body text,
    rest_off_url character varying(500),
    rest_off_body text,
    rest_method character varying(10),
    rest_headers text,
    rest_status_url character varying(500),
    rest_status_path character varying(200),
    rest_status_on_value character varying(50),
    rest_power_url character varying(500),
    rest_power_path character varying(200),
    rest_power_multiplier double precision NOT NULL,
    rest_energy_url character varying(500),
    rest_energy_path character varying(200),
    rest_energy_multiplier double precision NOT NULL,
    printer_id integer,
    enabled boolean NOT NULL,
    auto_on boolean NOT NULL,
    auto_off boolean NOT NULL,
    auto_off_persistent boolean NOT NULL,
    off_delay_mode character varying(20) NOT NULL,
    off_delay_minutes integer NOT NULL,
    off_temp_threshold integer NOT NULL,
    username character varying(50),
    password character varying(100),
    power_alert_enabled boolean NOT NULL,
    power_alert_high double precision,
    power_alert_low double precision,
    power_alert_last_triggered timestamp without time zone,
    schedule_enabled boolean NOT NULL,
    schedule_on_time character varying(5),
    schedule_off_time character varying(5),
    show_in_switchbar boolean NOT NULL,
    show_on_printer_card boolean NOT NULL,
    last_state character varying(10),
    last_checked timestamp without time zone,
    auto_off_executed boolean NOT NULL,
    auto_off_pending boolean NOT NULL,
    auto_off_pending_since timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: smart_plugs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_plugs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_plugs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_plugs_id_seq OWNED BY public.smart_plugs.id;


--
-- Name: spool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spool (
    id integer NOT NULL,
    material character varying(50) NOT NULL,
    subtype character varying(50),
    color_name character varying(100),
    rgba character varying(8),
    brand character varying(100),
    label_weight integer NOT NULL,
    core_weight integer NOT NULL,
    core_weight_catalog_id integer,
    weight_used double precision NOT NULL,
    weight_locked boolean NOT NULL,
    last_scale_weight integer,
    last_weighed_at timestamp without time zone,
    slicer_filament character varying(50),
    slicer_filament_name character varying(100),
    nozzle_temp_min integer,
    nozzle_temp_max integer,
    note character varying(500),
    added_full boolean,
    cost_per_kg double precision,
    last_used timestamp without time zone,
    encode_time timestamp without time zone,
    purchase_date timestamp without time zone,
    filament_diameter character varying(8) NOT NULL,
    lot integer,
    tag_uid character varying(32),
    tray_uuid character varying(32),
    data_origin character varying(20),
    tag_type character varying(20),
    archived_at timestamp without time zone,
    extra_colors character varying(255),
    effect_type character varying(20),
    category character varying(50),
    low_stock_threshold_pct integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    storage_location character varying(255)
);


--
-- Name: spool_assignment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spool_assignment (
    id integer NOT NULL,
    spool_id integer NOT NULL,
    printer_id integer NOT NULL,
    ams_id integer NOT NULL,
    tray_id integer NOT NULL,
    fingerprint_color character varying(8),
    fingerprint_type character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: spool_assignment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spool_assignment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spool_assignment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spool_assignment_id_seq OWNED BY public.spool_assignment.id;


--
-- Name: spool_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spool_catalog (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    weight integer NOT NULL,
    is_default boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: spool_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spool_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spool_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spool_catalog_id_seq OWNED BY public.spool_catalog.id;


--
-- Name: spool_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spool_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spool_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spool_id_seq OWNED BY public.spool.id;


--
-- Name: spool_k_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spool_k_profile (
    id integer NOT NULL,
    spool_id integer NOT NULL,
    printer_id integer NOT NULL,
    extruder integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    filament_calibration_id integer
);


--
-- Name: spool_k_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spool_k_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spool_k_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spool_k_profile_id_seq OWNED BY public.spool_k_profile.id;


--
-- Name: spool_usage_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spool_usage_history (
    id integer NOT NULL,
    spool_id integer NOT NULL,
    printer_id integer,
    print_name character varying(500),
    archive_id integer,
    weight_used double precision NOT NULL,
    percent_used integer NOT NULL,
    status character varying(20) NOT NULL,
    cost double precision,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: spool_usage_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spool_usage_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spool_usage_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spool_usage_history_id_seq OWNED BY public.spool_usage_history.id;


--
-- Name: spoolman_k_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spoolman_k_profile (
    id integer NOT NULL,
    spoolman_spool_id integer NOT NULL,
    printer_id integer NOT NULL,
    extruder integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    filament_calibration_id integer,
    CONSTRAINT ck_spoolman_kp_extruder_range CHECK (((extruder >= 0) AND (extruder <= 1)))
);


--
-- Name: spoolman_k_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spoolman_k_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spoolman_k_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spoolman_k_profile_id_seq OWNED BY public.spoolman_k_profile.id;


--
-- Name: spoolman_slot_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spoolman_slot_assignments (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    ams_id integer NOT NULL,
    tray_id integer NOT NULL,
    spoolman_spool_id integer NOT NULL,
    assigned_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_spoolman_slot_ams_id_range CHECK ((((ams_id >= 0) AND (ams_id <= 7)) OR (ams_id = 255))),
    CONSTRAINT ck_spoolman_slot_tray_id_range CHECK (((tray_id >= 0) AND (tray_id <= 3)))
);


--
-- Name: spoolman_slot_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spoolman_slot_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spoolman_slot_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spoolman_slot_assignments_id_seq OWNED BY public.spoolman_slot_assignments.id;


--
-- Name: telegram_chats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.telegram_chats (
    id integer NOT NULL,
    chat_id bigint NOT NULL,
    label character varying(100),
    group_id integer,
    user_id integer,
    is_active boolean NOT NULL,
    notify_events json,
    daily_digest boolean NOT NULL,
    quiet_hours_enabled boolean NOT NULL,
    quiet_hours_start character varying(5),
    quiet_hours_end character varying(5),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: telegram_chats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.telegram_chats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: telegram_chats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.telegram_chats_id_seq OWNED BY public.telegram_chats.id;


--
-- Name: user_email_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_email_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    notify_print_start boolean NOT NULL,
    notify_print_complete boolean NOT NULL,
    notify_print_failed boolean NOT NULL,
    notify_print_stopped boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_email_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_email_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_email_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_email_preferences_id_seq OWNED BY public.user_email_preferences.id;


--
-- Name: user_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_groups (
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: user_oidc_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_oidc_links (
    id integer NOT NULL,
    user_id integer NOT NULL,
    provider_id integer NOT NULL,
    provider_user_id character varying(500) NOT NULL,
    provider_email character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_oidc_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_oidc_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_oidc_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_oidc_links_id_seq OWNED BY public.user_oidc_links.id;


--
-- Name: user_otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_otp_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code_hash character varying(255) NOT NULL,
    attempts integer NOT NULL,
    used boolean NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_otp_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_otp_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_otp_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_otp_codes_id_seq OWNED BY public.user_otp_codes.id;


--
-- Name: user_totp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_totp (
    id integer NOT NULL,
    user_id integer NOT NULL,
    secret character varying(512) NOT NULL,
    is_enabled boolean NOT NULL,
    backup_codes_json text,
    last_totp_counter bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_totp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_totp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_totp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_totp_id_seq OWNED BY public.user_totp.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255),
    password_hash character varying(255),
    role character varying(20) NOT NULL,
    auth_source character varying(20) NOT NULL,
    is_active boolean NOT NULL,
    password_changed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cloud_token character varying(500),
    cloud_email character varying(255),
    cloud_region character varying(10)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: virtual_printers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.virtual_printers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    enabled boolean NOT NULL,
    mode character varying(20) NOT NULL,
    auto_dispatch boolean NOT NULL,
    model character varying(50),
    access_code character varying(8),
    target_printer_id integer,
    target_folder_id integer,
    bind_ip character varying(45),
    remote_interface_ip character varying(45),
    serial_suffix character varying(9) NOT NULL,
    tailscale_disabled boolean DEFAULT true NOT NULL,
    "position" integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    queue_force_color_match boolean DEFAULT false NOT NULL
);


--
-- Name: virtual_printers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.virtual_printers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: virtual_printers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.virtual_printers_id_seq OWNED BY public.virtual_printers.id;


--
-- Name: _migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations ALTER COLUMN id SET DEFAULT nextval('public._migrations_id_seq'::regclass);


--
-- Name: active_print_spoolman id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_print_spoolman ALTER COLUMN id SET DEFAULT nextval('public.active_print_spoolman_id_seq'::regclass);


--
-- Name: ams_labels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_labels ALTER COLUMN id SET DEFAULT nextval('public.ams_labels_id_seq'::regclass);


--
-- Name: ams_sensor_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_sensor_history ALTER COLUMN id SET DEFAULT nextval('public.ams_sensor_history_id_seq'::regclass);


--
-- Name: ams_setting_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_setting_audit ALTER COLUMN id SET DEFAULT nextval('public.ams_setting_audit_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: auth_ephemeral_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_ephemeral_tokens ALTER COLUMN id SET DEFAULT nextval('public.auth_ephemeral_tokens_id_seq'::regclass);


--
-- Name: auth_rate_limit_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_rate_limit_events ALTER COLUMN id SET DEFAULT nextval('public.auth_rate_limit_events_id_seq'::regclass);


--
-- Name: auto_queue_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items ALTER COLUMN id SET DEFAULT nextval('public.auto_queue_items_id_seq'::regclass);


--
-- Name: bug_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bug_reports ALTER COLUMN id SET DEFAULT nextval('public.bug_reports_id_seq'::regclass);


--
-- Name: calibration_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit ALTER COLUMN id SET DEFAULT nextval('public.calibration_audit_id_seq'::regclass);


--
-- Name: calibration_session id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session ALTER COLUMN id SET DEFAULT nextval('public.calibration_session_id_seq'::regclass);


--
-- Name: color_catalog id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.color_catalog ALTER COLUMN id SET DEFAULT nextval('public.color_catalog_id_seq'::regclass);


--
-- Name: external_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_links ALTER COLUMN id SET DEFAULT nextval('public.external_links_id_seq'::regclass);


--
-- Name: filament_calibration id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_calibration ALTER COLUMN id SET DEFAULT nextval('public.filament_calibration_id_seq'::regclass);


--
-- Name: filament_shopping_list id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_shopping_list ALTER COLUMN id SET DEFAULT nextval('public.filament_shopping_list_id_seq'::regclass);


--
-- Name: filament_sku_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_sku_settings ALTER COLUMN id SET DEFAULT nextval('public.filament_sku_settings_id_seq'::regclass);


--
-- Name: git_backup_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_backup_config ALTER COLUMN id SET DEFAULT nextval('public.git_backup_config_id_seq'::regclass);


--
-- Name: git_backup_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_backup_logs ALTER COLUMN id SET DEFAULT nextval('public.git_backup_logs_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: kprofile_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kprofile_notes ALTER COLUMN id SET DEFAULT nextval('public.kprofile_notes_id_seq'::regclass);


--
-- Name: library_file_makerworld_meta id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_makerworld_meta ALTER COLUMN id SET DEFAULT nextval('public.library_file_makerworld_meta_id_seq'::regclass);


--
-- Name: library_file_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_notes ALTER COLUMN id SET DEFAULT nextval('public.library_file_notes_id_seq'::regclass);


--
-- Name: library_files id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_files ALTER COLUMN id SET DEFAULT nextval('public.library_files_id_seq'::regclass);


--
-- Name: library_folders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folders ALTER COLUMN id SET DEFAULT nextval('public.library_folders_id_seq'::regclass);


--
-- Name: local_presets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_presets ALTER COLUMN id SET DEFAULT nextval('public.local_presets_id_seq'::regclass);


--
-- Name: long_lived_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.long_lived_tokens ALTER COLUMN id SET DEFAULT nextval('public.long_lived_tokens_id_seq'::regclass);


--
-- Name: macros id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.macros ALTER COLUMN id SET DEFAULT nextval('public.macros_id_seq'::regclass);


--
-- Name: maintenance_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_history ALTER COLUMN id SET DEFAULT nextval('public.maintenance_history_id_seq'::regclass);


--
-- Name: maintenance_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_types ALTER COLUMN id SET DEFAULT nextval('public.maintenance_types_id_seq'::regclass);


--
-- Name: notification_digest_queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_digest_queue ALTER COLUMN id SET DEFAULT nextval('public.notification_digest_queue_id_seq'::regclass);


--
-- Name: notification_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs ALTER COLUMN id SET DEFAULT nextval('public.notification_logs_id_seq'::regclass);


--
-- Name: notification_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_providers ALTER COLUMN id SET DEFAULT nextval('public.notification_providers_id_seq'::regclass);


--
-- Name: notification_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates ALTER COLUMN id SET DEFAULT nextval('public.notification_templates_id_seq'::regclass);


--
-- Name: oidc_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers ALTER COLUMN id SET DEFAULT nextval('public.oidc_providers_id_seq'::regclass);


--
-- Name: orca_base_profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orca_base_profiles ALTER COLUMN id SET DEFAULT nextval('public.orca_base_profiles_id_seq'::regclass);


--
-- Name: print_archives id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives ALTER COLUMN id SET DEFAULT nextval('public.print_archives_id_seq'::regclass);


--
-- Name: print_options_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_options_preferences ALTER COLUMN id SET DEFAULT nextval('public.print_options_preferences_id_seq'::regclass);


--
-- Name: print_queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue ALTER COLUMN id SET DEFAULT nextval('public.print_queue_id_seq'::regclass);


--
-- Name: printer_maintenance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_maintenance ALTER COLUMN id SET DEFAULT nextval('public.printer_maintenance_id_seq'::regclass);


--
-- Name: printer_queues id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_queues ALTER COLUMN id SET DEFAULT nextval('public.printer_queues_id_seq'::regclass);


--
-- Name: printer_setting_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_setting_audit ALTER COLUMN id SET DEFAULT nextval('public.printer_setting_audit_id_seq'::regclass);


--
-- Name: printers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printers ALTER COLUMN id SET DEFAULT nextval('public.printers_id_seq'::regclass);


--
-- Name: project_bom_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_bom_items ALTER COLUMN id SET DEFAULT nextval('public.project_bom_items_id_seq'::regclass);


--
-- Name: project_print_plan_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_print_plan_items ALTER COLUMN id SET DEFAULT nextval('public.project_print_plan_items_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: slot_preset_mappings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slot_preset_mappings ALTER COLUMN id SET DEFAULT nextval('public.slot_preset_mappings_id_seq'::regclass);


--
-- Name: smart_plug_energy_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_energy_snapshots ALTER COLUMN id SET DEFAULT nextval('public.smart_plug_energy_snapshots_id_seq'::regclass);


--
-- Name: smart_plugs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plugs ALTER COLUMN id SET DEFAULT nextval('public.smart_plugs_id_seq'::regclass);


--
-- Name: spool id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool ALTER COLUMN id SET DEFAULT nextval('public.spool_id_seq'::regclass);


--
-- Name: spool_assignment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_assignment ALTER COLUMN id SET DEFAULT nextval('public.spool_assignment_id_seq'::regclass);


--
-- Name: spool_catalog id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_catalog ALTER COLUMN id SET DEFAULT nextval('public.spool_catalog_id_seq'::regclass);


--
-- Name: spool_k_profile id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_k_profile ALTER COLUMN id SET DEFAULT nextval('public.spool_k_profile_id_seq'::regclass);


--
-- Name: spool_usage_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_usage_history ALTER COLUMN id SET DEFAULT nextval('public.spool_usage_history_id_seq'::regclass);


--
-- Name: spoolman_k_profile id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_k_profile ALTER COLUMN id SET DEFAULT nextval('public.spoolman_k_profile_id_seq'::regclass);


--
-- Name: spoolman_slot_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_slot_assignments ALTER COLUMN id SET DEFAULT nextval('public.spoolman_slot_assignments_id_seq'::regclass);


--
-- Name: telegram_chats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats ALTER COLUMN id SET DEFAULT nextval('public.telegram_chats_id_seq'::regclass);


--
-- Name: user_email_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_email_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_email_preferences_id_seq'::regclass);


--
-- Name: user_oidc_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links ALTER COLUMN id SET DEFAULT nextval('public.user_oidc_links_id_seq'::regclass);


--
-- Name: user_otp_codes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_otp_codes ALTER COLUMN id SET DEFAULT nextval('public.user_otp_codes_id_seq'::regclass);


--
-- Name: user_totp id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_totp ALTER COLUMN id SET DEFAULT nextval('public.user_totp_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: virtual_printers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtual_printers ALTER COLUMN id SET DEFAULT nextval('public.virtual_printers_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (id, version, name, applied_at) FROM stdin;
1	0	bambuddy_to_bamdude_301	2026-11-15 06:09:29
2	1	bamdude_baseline	2026-11-15 06:09:30
3	2	bamdude_311	2026-11-15 06:09:30
4	3	enforce_admin_user	2026-11-15 06:09:30
5	4	m002_reconcile	2026-11-15 06:09:30
6	5	swap_profiles	2026-11-15 06:09:31
7	6	mesh_mode_fast_check	2026-11-15 06:09:31
8	7	drop_vibration_cali	2026-11-15 06:09:31
9	8	swap_macro_queue_fields	2026-11-15 06:09:31
10	9	archive_source_hash	2026-11-15 06:09:31
11	10	queue_reliability	2026-11-15 06:09:31
12	11	cloud_region	2026-11-15 06:09:31
13	12	mfa	2026-11-15 06:09:31
14	13	library_file_print_count	2026-11-15 06:09:31
15	14	archive_library_link	2026-11-15 06:09:31
16	15	refresh_token_support	2026-11-15 06:09:31
17	16	project_print_plan	2026-11-15 06:09:31
18	17	macro_action_type	2026-11-15 06:09:31
19	18	queue_library_fk_set_null	2026-11-15 06:09:31
20	19	archive_queue_batch_error	2026-11-15 06:09:31
21	20	spool_purchase_date	2026-11-15 06:09:31
22	21	drop_auto_light_off	2026-11-15 06:09:31
23	22	label_object_metadata_backfill	2026-11-15 06:09:31
24	23	per_plate_metadata_backfill	2026-11-15 06:09:31
25	24	auto_queue	2026-11-15 06:09:31
26	25	settings_dedupe	2026-11-15 06:09:31
27	26	spool_extensions	2026-11-15 06:09:31
28	27	project_url_and_cover	2026-11-15 06:09:31
29	28	long_lived_tokens	2026-11-15 06:09:31
30	29	library_trash	2026-11-15 06:09:31
31	30	vp_tailscale	2026-11-15 06:09:31
32	31	oidc_email_claim	2026-11-15 06:09:31
33	32	gcode_injection	2026-11-15 06:09:31
34	33	library_file_source	2026-11-15 06:09:31
35	34	archive_trash	2026-11-15 06:09:31
36	35	normalize_file_type	2026-11-15 06:09:31
37	36	library_file_tags	2026-11-15 06:09:32
38	37	project_geometry_tags	2026-11-15 06:09:32
39	38	archive_plate_index	2026-11-15 06:09:32
40	39	archive_source_hash_backfill	2026-11-15 06:09:32
41	40	vp_target_folder	2026-11-15 06:09:32
42	41	drain_pending_and_purge_archived	2026-11-15 06:09:32
43	42	drop_pending_uploads	2026-11-15 06:12:55.113354
44	43	print_options_preferences	2026-11-15 06:12:55.182137
45	44	library_project_pivots	2026-11-15 06:12:55.376709
46	45	telegram_config_refactor	2026-11-15 06:12:55.397333
47	46	normalize_group_permissions	2026-11-15 06:12:56.295261
48	47	external_camera_snapshot_url	2026-11-15 06:12:56.317997
49	48	backfill_print_plan_from_pivots	2026-11-15 06:12:56.340214
50	49	api_key_owner_and_cloud_scope	2026-11-15 06:12:56.384001
51	50	vp_queue_force_color_match	2026-11-15 06:12:56.411558
52	51	oidc_default_group	2026-11-15 06:12:56.435116
53	52	notification_pause_resume_events	2026-11-15 06:12:56.52038
54	53	spoolman_inventory_tables	2026-11-15 06:12:56.611338
55	54	bug_reports	2026-11-15 06:12:56.636647
56	55	external_link_nav_group	2026-11-15 06:12:56.653431
57	56	library_file_makerworld_meta	2026-11-15 06:12:57.221076
58	57	archive_bed_type	2026-11-15 06:12:57.244702
59	58	settings_dedupe_unique_key	2026-11-15 06:12:57.255823
60	59	stock_forecasting	2026-11-15 06:12:57.319277
61	60	ams_setting_audit	2026-11-15 06:12:57.353761
62	61	printer_setting_audit	2026-11-15 06:12:57.392429
63	62	filament_calibration	2026-11-15 06:12:57.509824
64	63	filament_calibration_per_printer	2026-11-15 06:12:57.578957
65	64	spool_kprofile_link_table	2026-11-15 06:12:57.714384
66	65	kprofile_notes_rekey	2026-11-15 06:12:57.792631
67	66	auto_queue_archive_flag	2026-11-15 06:12:57.868105
68	67	printer_queue_is_paused	2026-11-15 06:12:57.925005
69	68	printer_queue_completed_event	2026-11-15 06:12:58.009424
70	69	filament_calibration_tower_result	2026-11-15 06:12:58.086997
71	70	calibration_session_dispatch_args	2026-11-15 06:12:58.128184
\.


--
-- Data for Name: active_print_spoolman; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.active_print_spoolman (id, printer_id, archive_id, filament_usage, ams_trays, slot_to_tray, layer_usage, filament_properties) FROM stdin;
\.


--
-- Data for Name: ams_labels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ams_labels (id, ams_serial_number, ams_id, label, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ams_sensor_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ams_sensor_history (id, printer_id, ams_id, humidity, humidity_raw, temperature, recorded_at) FROM stdin;
\.


--
-- Data for Name: ams_setting_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ams_setting_audit (id, printer_id, user_id, action, payload_json, sequence_id, result, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_keys (id, name, key_hash, key_prefix, can_queue, can_control_printer, can_read_status, printer_ids, enabled, last_used, created_at, expires_at, user_id, can_access_cloud) FROM stdin;
\.


--
-- Data for Name: auth_ephemeral_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_ephemeral_tokens (id, token, token_type, username, provider_id, nonce, code_verifier, challenge_id, used_at, family_id, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: auth_rate_limit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_rate_limit_events (id, username, event_type, occurred_at) FROM stdin;
\.


--
-- Data for Name: auto_queue_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auto_queue_items (id, archive_id, library_file_id, project_id, target_model, target_location, required_filament_types, filament_overrides, force_color_match, plate_id, bed_levelling, flow_cali, layer_inspect, timelapse, use_ams, mesh_mode_fast_check, execute_swap_macros, swap_macro_events, "position", scheduled_time, manual_start, auto_off_after, require_previous_success, status, waiting_reason, assigned_to_item_id, assigned_at, cancelled_at, print_time_seconds, been_jumped, batch_id, created_at, created_by_id) FROM stdin;
\.


--
-- Data for Name: bug_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bug_reports (id, description, reporter_email, github_issue_number, github_issue_url, status, error_message, email_sent, created_at) FROM stdin;
\.


--
-- Data for Name: calibration_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calibration_audit (id, printer_id, session_id, filament_calibration_id, user_id, action, payload_json, sequence_id, result, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: calibration_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calibration_session (id, printer_id, user_id, cali_mode, method, nozzle_diameter, nozzle_volume_type, extruder_id, filaments_json, status, mqtt_sequence_id, print_queue_item_id, parent_session_id, stage, coarse_ratio, error_message, created_at, updated_at, dispatch_args_json) FROM stdin;
\.


--
-- Data for Name: color_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.color_catalog (id, manufacturer, color_name, hex_color, material, is_default, created_at) FROM stdin;
1	Bambu Lab	Jade White	#FFFFFF	PLA Basic	t	2026-11-15 06:09:30
2	Bambu Lab	Black	#000000	PLA Basic	t	2026-11-15 06:09:30
3	Bambu Lab	Silver	#A6A9AA	PLA Basic	t	2026-11-15 06:09:30
4	Bambu Lab	Light Gray	#D1D3D5	PLA Basic	t	2026-11-15 06:09:30
5	Bambu Lab	Gray	#8E9089	PLA Basic	t	2026-11-15 06:09:30
6	Bambu Lab	Dark Gray	#545454	PLA Basic	t	2026-11-15 06:09:30
7	Bambu Lab	Red	#C12E1F	PLA Basic	t	2026-11-15 06:09:30
8	Bambu Lab	Maroon Red	#9D2235	PLA Basic	t	2026-11-15 06:09:30
9	Bambu Lab	Magenta	#EC008C	PLA Basic	t	2026-11-15 06:09:30
10	Bambu Lab	Hot Pink	#F5547C	PLA Basic	t	2026-11-15 06:09:30
11	Bambu Lab	Pink	#F55A74	PLA Basic	t	2026-11-15 06:09:30
12	Bambu Lab	Beige	#F7E6DE	PLA Basic	t	2026-11-15 06:09:30
13	Bambu Lab	Yellow	#F4EE2A	PLA Basic	t	2026-11-15 06:09:30
14	Bambu Lab	Sunflower Yellow	#FEC600	PLA Basic	t	2026-11-15 06:09:30
15	Bambu Lab	Gold	#E4BD68	PLA Basic	t	2026-11-15 06:09:30
16	Bambu Lab	Orange	#FF6A13	PLA Basic	t	2026-11-15 06:09:30
17	Bambu Lab	Pumpkin Orange	#FF9016	PLA Basic	t	2026-11-15 06:09:30
18	Bambu Lab	Bright Green	#BECF00	PLA Basic	t	2026-11-15 06:09:30
19	Bambu Lab	Bambu Green	#00AE42	PLA Basic	t	2026-11-15 06:09:30
20	Bambu Lab	Mistletoe Green	#3F8E43	PLA Basic	t	2026-11-15 06:09:30
21	Bambu Lab	Turquoise	#00B1B7	PLA Basic	t	2026-11-15 06:09:30
22	Bambu Lab	Cyan	#0086D6	PLA Basic	t	2026-11-15 06:09:30
23	Bambu Lab	Blue	#0A2989	PLA Basic	t	2026-11-15 06:09:30
24	Bambu Lab	Blue Grey	#5B6579	PLA Basic	t	2026-11-15 06:09:30
25	Bambu Lab	Cobalt Blue	#0056B8	PLA Basic	t	2026-11-15 06:09:30
26	Bambu Lab	Purple	#5E43B7	PLA Basic	t	2026-11-15 06:09:30
27	Bambu Lab	Indigo Purple	#482960	PLA Basic	t	2026-11-15 06:09:30
28	Bambu Lab	Brown	#9D432C	PLA Basic	t	2026-11-15 06:09:30
29	Bambu Lab	Cocoa Brown	#6F5034	PLA Basic	t	2026-11-15 06:09:30
30	Bambu Lab	Bronze	#847D48	PLA Basic	t	2026-11-15 06:09:30
31	Bambu Lab	Ivory White	#FFFFFF	PLA Matte	t	2026-11-15 06:09:30
32	Bambu Lab	Bone White	#CBC6B8	PLA Matte	t	2026-11-15 06:09:30
33	Bambu Lab	Desert Tan	#E8DBB7	PLA Matte	t	2026-11-15 06:09:30
34	Bambu Lab	Latte Brown	#D3B7A7	PLA Matte	t	2026-11-15 06:09:30
35	Bambu Lab	Caramel	#AE835B	PLA Matte	t	2026-11-15 06:09:30
36	Bambu Lab	Terracotta	#B15533	PLA Matte	t	2026-11-15 06:09:30
37	Bambu Lab	Dark Brown	#7D6556	PLA Matte	t	2026-11-15 06:09:30
38	Bambu Lab	Dark Chocolate	#4D3324	PLA Matte	t	2026-11-15 06:09:30
39	Bambu Lab	Lilac Purple	#AE96D4	PLA Matte	t	2026-11-15 06:09:30
40	Bambu Lab	Sakura Pink	#E8AFCF	PLA Matte	t	2026-11-15 06:09:30
41	Bambu Lab	Mandarin Orange	#F99963	PLA Matte	t	2026-11-15 06:09:30
42	Bambu Lab	Lemon Yellow	#F7D959	PLA Matte	t	2026-11-15 06:09:30
43	Bambu Lab	Plum	#950051	PLA Matte	t	2026-11-15 06:09:30
44	Bambu Lab	Scarlet Red	#DE4343	PLA Matte	t	2026-11-15 06:09:30
45	Bambu Lab	Dark Red	#BB3D43	PLA Matte	t	2026-11-15 06:09:30
46	Bambu Lab	Dark Green	#68724D	PLA Matte	t	2026-11-15 06:09:30
47	Bambu Lab	Grass Green	#61C680	PLA Matte	t	2026-11-15 06:09:30
48	Bambu Lab	Apple Green	#C2E189	PLA Matte	t	2026-11-15 06:09:30
49	Bambu Lab	Ice Blue	#A3D8E1	PLA Matte	t	2026-11-15 06:09:30
50	Bambu Lab	Sky Blue	#56B7E6	PLA Matte	t	2026-11-15 06:09:30
51	Bambu Lab	Marine Blue	#0078BF	PLA Matte	t	2026-11-15 06:09:30
52	Bambu Lab	Dark Blue	#042F56	PLA Matte	t	2026-11-15 06:09:30
53	Bambu Lab	Ash Gray	#9B9EA0	PLA Matte	t	2026-11-15 06:09:30
54	Bambu Lab	Nardo Gray	#757575	PLA Matte	t	2026-11-15 06:09:30
55	Bambu Lab	Charcoal	#000000	PLA Matte	t	2026-11-15 06:09:30
56	Bambu Lab	Gold	#F4A925	PLA Silk	t	2026-11-15 06:09:30
57	Bambu Lab	Silver	#C8C8C8	PLA Silk	t	2026-11-15 06:09:30
58	Bambu Lab	Titan Gray	#5F6367	PLA Silk	t	2026-11-15 06:09:30
59	Bambu Lab	Blue	#008BDA	PLA Silk	t	2026-11-15 06:09:30
60	Bambu Lab	Purple	#8671CB	PLA Silk	t	2026-11-15 06:09:30
61	Bambu Lab	Candy Red	#D02727	PLA Silk	t	2026-11-15 06:09:30
62	Bambu Lab	Candy Green	#018814	PLA Silk	t	2026-11-15 06:09:30
63	Bambu Lab	Rose Gold	#BA9594	PLA Silk	t	2026-11-15 06:09:30
64	Bambu Lab	Baby Blue	#A8C6EE	PLA Silk	t	2026-11-15 06:09:30
65	Bambu Lab	Pink	#F7ADA6	PLA Silk	t	2026-11-15 06:09:30
66	Bambu Lab	Mint	#96DCB9	PLA Silk	t	2026-11-15 06:09:30
67	Bambu Lab	Champagne	#F3CFB2	PLA Silk	t	2026-11-15 06:09:30
68	Bambu Lab	White	#FFFFFF	PLA Silk	t	2026-11-15 06:09:30
69	Bambu Lab	Classic Gold Sparkle	#CEA629	PLA Sparkle	t	2026-11-15 06:09:30
70	Bambu Lab	Slate Gray Sparkle	#8E9089	PLA Sparkle	t	2026-11-15 06:09:30
71	Bambu Lab	Crimson Red Sparkle	#792B36	PLA Sparkle	t	2026-11-15 06:09:30
72	Bambu Lab	Royal Purple Sparkle	#483D8B	PLA Sparkle	t	2026-11-15 06:09:30
73	Bambu Lab	Alpine Green Sparkle	#3F5443	PLA Sparkle	t	2026-11-15 06:09:30
74	Bambu Lab	Onyx Black Sparkle	#2D2B28	PLA Sparkle	t	2026-11-15 06:09:30
75	Bambu Lab	Teal	#009FA1	PLA Translucent	t	2026-11-15 06:09:30
76	Bambu Lab	Light Jade	#96D8AF	PLA Translucent	t	2026-11-15 06:09:30
77	Bambu Lab	Blue	#0047BB	PLA Translucent	t	2026-11-15 06:09:30
78	Bambu Lab	Mellow Yellow	#F5DBAB	PLA Translucent	t	2026-11-15 06:09:30
79	Bambu Lab	Purple	#8344B0	PLA Translucent	t	2026-11-15 06:09:30
80	Bambu Lab	Cherry Pink	#F5B6CD	PLA Translucent	t	2026-11-15 06:09:30
81	Bambu Lab	Orange	#F74E02	PLA Translucent	t	2026-11-15 06:09:30
82	Bambu Lab	Ice Blue	#B8CDE9	PLA Translucent	t	2026-11-15 06:09:30
83	Bambu Lab	Red	#B50011	PLA Translucent	t	2026-11-15 06:09:30
84	Bambu Lab	Lavender	#B8ACD6	PLA Translucent	t	2026-11-15 06:09:30
85	Bambu Lab	Glow Green	#A1FFAC	PLA Glow	t	2026-11-15 06:09:30
86	Bambu Lab	Glow Yellow	#F8FF80	PLA Glow	t	2026-11-15 06:09:30
87	Bambu Lab	Glow Pink	#F17B8F	PLA Glow	t	2026-11-15 06:09:30
88	Bambu Lab	Glow Blue	#7AC0E9	PLA Glow	t	2026-11-15 06:09:30
89	Bambu Lab	Glow Orange	#FF9D5B	PLA Glow	t	2026-11-15 06:09:30
90	Bambu Lab	Brown	#684A43	PLA Galaxy	t	2026-11-15 06:09:30
91	Bambu Lab	Green	#3B665E	PLA Galaxy	t	2026-11-15 06:09:30
92	Bambu Lab	Nebulae	#424379	PLA Galaxy	t	2026-11-15 06:09:30
93	Bambu Lab	Purple	#594177	PLA Galaxy	t	2026-11-15 06:09:30
94	Bambu Lab	Iridium Gold Metallic	#B39B84	PLA Metal	t	2026-11-15 06:09:30
95	Bambu Lab	Copper Brown Metallic	#AA6443	PLA Metal	t	2026-11-15 06:09:30
96	Bambu Lab	Oxide Green Metallic	#1D7C6A	PLA Metal	t	2026-11-15 06:09:30
97	Bambu Lab	Cobalt Blue Metallic	#39699E	PLA Metal	t	2026-11-15 06:09:30
415	Elegoo	Clear	#BEBBBF	PLA	t	2026-11-15 06:09:30
98	Bambu Lab	Iron Gray Metallic	#43403D	PLA Metal	t	2026-11-15 06:09:30
99	Bambu Lab	White Marble	#F7F3F0	PLA Marble	t	2026-11-15 06:09:30
100	Bambu Lab	Red Granite	#AD4E38	PLA Marble	t	2026-11-15 06:09:30
101	Bambu Lab	Black Walnut	#4F3F24	PLA Wood	t	2026-11-15 06:09:30
102	Bambu Lab	Rosewood	#4C241C	PLA Wood	t	2026-11-15 06:09:30
103	Bambu Lab	Clay Brown	#995F11	PLA Wood	t	2026-11-15 06:09:30
104	Bambu Lab	Classic Birch	#918669	PLA Wood	t	2026-11-15 06:09:30
105	Bambu Lab	White Oak	#D6CCA3	PLA Wood	t	2026-11-15 06:09:30
106	Bambu Lab	Ochre Yellow	#C98935	PLA Wood	t	2026-11-15 06:09:30
107	Bambu Lab	White	#FFFFFF	PLA Tough	t	2026-11-15 06:09:30
108	Bambu Lab	Gray	#AFB1AE	PLA Tough	t	2026-11-15 06:09:30
109	Bambu Lab	Black	#000000	PLA Tough	t	2026-11-15 06:09:30
110	Bambu Lab	Silver	#959698	PLA Tough	t	2026-11-15 06:09:30
111	Bambu Lab	Yellow	#F4D53F	PLA Tough	t	2026-11-15 06:09:30
112	Bambu Lab	Cyan	#009BD8	PLA Tough	t	2026-11-15 06:09:30
113	Bambu Lab	Orange	#DC3A27	PLA Tough	t	2026-11-15 06:09:30
114	Bambu Lab	Burgundy Red	#951E23	PLA-CF	t	2026-11-15 06:09:30
115	Bambu Lab	Iris Purple	#69398E	PLA-CF	t	2026-11-15 06:09:30
116	Bambu Lab	Matcha Green	#5C9748	PLA-CF	t	2026-11-15 06:09:30
117	Bambu Lab	Jeans Blue	#6E88BC	PLA-CF	t	2026-11-15 06:09:30
118	Bambu Lab	Royal Blue	#2842AD	PLA-CF	t	2026-11-15 06:09:30
119	Bambu Lab	Lava Gray	#4D5054	PLA-CF	t	2026-11-15 06:09:30
120	Bambu Lab	Black	#000000	PLA-CF	t	2026-11-15 06:09:30
121	Bambu Lab	White	#FFFFFF	ABS	t	2026-11-15 06:09:30
122	Bambu Lab	Desert Tan	#E8DBB7	ABS	t	2026-11-15 06:09:30
123	Bambu Lab	Olive	#789D4A	ABS	t	2026-11-15 06:09:30
124	Bambu Lab	Azure	#489FDF	ABS	t	2026-11-15 06:09:30
125	Bambu Lab	Navy Blue	#0C2340	ABS	t	2026-11-15 06:09:30
126	Bambu Lab	Blue	#0A2CA5	ABS	t	2026-11-15 06:09:30
127	Bambu Lab	Tangerine Yellow	#FFC72C	ABS	t	2026-11-15 06:09:30
128	Bambu Lab	Orange	#FF6A13	ABS	t	2026-11-15 06:09:30
129	Bambu Lab	Red	#D32941	ABS	t	2026-11-15 06:09:30
130	Bambu Lab	Purple	#AF1685	ABS	t	2026-11-15 06:09:30
131	Bambu Lab	Silver	#87909A	ABS	t	2026-11-15 06:09:30
132	Bambu Lab	Black	#000000	ABS	t	2026-11-15 06:09:30
133	Bambu Lab	White	#FFFAF2	ASA	t	2026-11-15 06:09:30
134	Bambu Lab	Gray	#8A949E	ASA	t	2026-11-15 06:09:30
135	Bambu Lab	Red	#E02928	ASA	t	2026-11-15 06:09:30
136	Bambu Lab	Green	#00A6A0	ASA	t	2026-11-15 06:09:30
137	Bambu Lab	Blue	#2140B4	ASA	t	2026-11-15 06:09:30
138	Bambu Lab	Black	#000000	ASA	t	2026-11-15 06:09:30
139	Bambu Lab	Yellow	#FFD00B	PETG HF	t	2026-11-15 06:09:30
140	Bambu Lab	Orange	#F75403	PETG HF	t	2026-11-15 06:09:30
141	Bambu Lab	Green	#00AE42	PETG HF	t	2026-11-15 06:09:30
142	Bambu Lab	Red	#EB3A3A	PETG HF	t	2026-11-15 06:09:30
143	Bambu Lab	Blue	#002E96	PETG HF	t	2026-11-15 06:09:30
144	Bambu Lab	Black	#000000	PETG HF	t	2026-11-15 06:09:30
145	Bambu Lab	White	#FFFFFF	PETG HF	t	2026-11-15 06:09:30
146	Bambu Lab	Cream	#F9DFB9	PETG HF	t	2026-11-15 06:09:30
147	Bambu Lab	Lime Green	#6EE53C	PETG HF	t	2026-11-15 06:09:30
148	Bambu Lab	Forest Green	#39541A	PETG HF	t	2026-11-15 06:09:30
149	Bambu Lab	Lake Blue	#1F79E5	PETG HF	t	2026-11-15 06:09:30
150	Bambu Lab	Peanut Brown	#875718	PETG HF	t	2026-11-15 06:09:30
151	Bambu Lab	Gray	#ADB1B2	PETG HF	t	2026-11-15 06:09:30
152	Bambu Lab	Dark Gray	#515151	PETG HF	t	2026-11-15 06:09:30
153	Bambu Lab	Translucent Gray	#8E8E8E	PETG Translucent	t	2026-11-15 06:09:30
154	Bambu Lab	Translucent Light Blue	#61B0FF	PETG Translucent	t	2026-11-15 06:09:30
155	Bambu Lab	Translucent Olive	#748C45	PETG Translucent	t	2026-11-15 06:09:30
156	Bambu Lab	Translucent Brown	#C9A381	PETG Translucent	t	2026-11-15 06:09:30
157	Bambu Lab	Translucent Teal	#77EDD7	PETG Translucent	t	2026-11-15 06:09:30
158	Bambu Lab	Translucent Orange	#FF911A	PETG Translucent	t	2026-11-15 06:09:30
159	Bambu Lab	Translucent Purple	#D6ABFF	PETG Translucent	t	2026-11-15 06:09:30
160	Bambu Lab	Translucent Pink	#F9C1BD	PETG Translucent	t	2026-11-15 06:09:30
161	Bambu Lab	Brick Red	#9F332A	PETG-CF	t	2026-11-15 06:09:30
162	Bambu Lab	Violet Purple	#583061	PETG-CF	t	2026-11-15 06:09:30
163	Bambu Lab	Indigo Blue	#324585	PETG-CF	t	2026-11-15 06:09:30
164	Bambu Lab	Malachite Green	#16B08E	PETG-CF	t	2026-11-15 06:09:30
165	Bambu Lab	Black	#000000	PETG-CF	t	2026-11-15 06:09:30
166	Bambu Lab	Titan Gray	#565656	PETG-CF	t	2026-11-15 06:09:30
167	Bambu Lab	White	#FFFFFF	TPU 95A	t	2026-11-15 06:09:30
168	Bambu Lab	Yellow	#F3E600	TPU 95A	t	2026-11-15 06:09:30
169	Bambu Lab	Blue	#0072CE	TPU 95A	t	2026-11-15 06:09:30
170	Bambu Lab	Red	#C8102E	TPU 95A	t	2026-11-15 06:09:30
171	Bambu Lab	Gray	#898D8D	TPU 95A	t	2026-11-15 06:09:30
172	Bambu Lab	Black	#101820	TPU 95A	t	2026-11-15 06:09:30
173	Bambu Lab	Black	#000000	TPU 90A	t	2026-11-15 06:09:30
174	Bambu Lab	White	#FFFFFF	TPU 90A	t	2026-11-15 06:09:30
175	Bambu Lab	Grape Jelly	#D6ABFF	TPU 90A	t	2026-11-15 06:09:30
176	Bambu Lab	Crystal Blue	#7EB4E1	TPU 90A	t	2026-11-15 06:09:30
177	Bambu Lab	Cocoa Brown	#5C4738	TPU 90A	t	2026-11-15 06:09:30
178	Bambu Lab	Black	#1A1A1A	PAHT-CF	t	2026-11-15 06:09:30
179	Bambu Lab	Natural	#F5F5DC	PLA Support	t	2026-11-15 06:09:30
180	Bambu Lab	Natural	#F5F5DC	PVA Support	t	2026-11-15 06:09:30
181	Polymaker	Cotton White	#F5F5F5	PolyTerra PLA	t	2026-11-15 06:09:30
182	Polymaker	Charcoal Black	#2B2B2B	PolyTerra PLA	t	2026-11-15 06:09:30
183	Polymaker	Marble White	#E8E8E8	PolyTerra PLA	t	2026-11-15 06:09:30
184	Polymaker	Fossil Grey	#6B6B6B	PolyTerra PLA	t	2026-11-15 06:09:30
185	Polymaker	Shadow Black	#1A1A1A	PolyTerra PLA	t	2026-11-15 06:09:30
186	Polymaker	Army Red	#8B0000	PolyTerra PLA	t	2026-11-15 06:09:30
187	Polymaker	Lava Red	#CF1020	PolyTerra PLA	t	2026-11-15 06:09:30
188	Polymaker	Sakura Pink	#FFB7C5	PolyTerra PLA	t	2026-11-15 06:09:30
189	Polymaker	Rose	#FF007F	PolyTerra PLA	t	2026-11-15 06:09:30
190	Polymaker	Peach	#FFCBA4	PolyTerra PLA	t	2026-11-15 06:09:30
191	Polymaker	Banana	#FFE135	PolyTerra PLA	t	2026-11-15 06:09:30
192	Polymaker	Savannah Yellow	#F4C430	PolyTerra PLA	t	2026-11-15 06:09:30
193	Polymaker	Sunrise Orange	#FF6600	PolyTerra PLA	t	2026-11-15 06:09:30
194	Polymaker	Muted Green	#4F7942	PolyTerra PLA	t	2026-11-15 06:09:30
195	Polymaker	Forest Green	#228B22	PolyTerra PLA	t	2026-11-15 06:09:30
196	Polymaker	Mint	#98FF98	PolyTerra PLA	t	2026-11-15 06:09:30
197	Polymaker	Lavender Purple	#B57EDC	PolyTerra PLA	t	2026-11-15 06:09:30
198	Polymaker	Sapphire Blue	#0F52BA	PolyTerra PLA	t	2026-11-15 06:09:30
199	Polymaker	Ice	#D6ECEF	PolyTerra PLA	t	2026-11-15 06:09:30
200	Prusament	Jet Black	#1A1A1A	PLA	t	2026-11-15 06:09:30
201	Prusament	Galaxy Black	#1F1F1F	PLA	t	2026-11-15 06:09:30
202	Prusament	Pristine White	#FFFFFF	PLA	t	2026-11-15 06:09:30
203	Prusament	Gentleman's Grey	#5A5A5A	PLA	t	2026-11-15 06:09:30
204	Prusament	Lipstick Red	#C21E1E	PLA	t	2026-11-15 06:09:30
205	Prusament	Orange	#FF6600	PLA	t	2026-11-15 06:09:30
206	Prusament	Pineapple Yellow	#FFD700	PLA	t	2026-11-15 06:09:30
207	Prusament	Jungle Green	#29AB87	PLA	t	2026-11-15 06:09:30
208	Prusament	Azure Blue	#007FFF	PLA	t	2026-11-15 06:09:30
209	Prusament	Royal Blue	#4169E1	PLA	t	2026-11-15 06:09:30
210	Prusament	Mystic Purple	#7B68EE	PLA	t	2026-11-15 06:09:30
211	eSUN	Beige	#ECCAB0	PLA+	t	2026-11-15 06:09:30
212	eSUN	Black	#373838	PLA+	t	2026-11-15 06:09:30
213	eSUN	Blue	#054795	PLA+	t	2026-11-15 06:09:30
214	eSUN	Bone White	#C2BAA7	PLA+	t	2026-11-15 06:09:30
215	eSUN	Brown	#6F513C	PLA+	t	2026-11-15 06:09:30
216	eSUN	Cool White	#E1E4E5	PLA+	t	2026-11-15 06:09:30
217	eSUN	Dark Blue	#2F314D	PLA+	t	2026-11-15 06:09:30
218	eSUN	Fire Engine Red	#91202B	PLA+	t	2026-11-15 06:09:30
219	eSUN	Gold	#C99B26	PLA+	t	2026-11-15 06:09:30
220	eSUN	Gray	#697480	PLA+	t	2026-11-15 06:09:30
221	eSUN	Green	#015E58	PLA+	t	2026-11-15 06:09:30
222	eSUN	Grey	#5F6574	PLA+	t	2026-11-15 06:09:30
223	eSUN	Light Blue	#48BFD5	PLA+	t	2026-11-15 06:09:30
224	eSUN	Light Brown	#A27556	PLA+	t	2026-11-15 06:09:30
225	eSUN	Luminous Blue	#C8CAC8	PLA+	t	2026-11-15 06:09:30
226	eSUN	Magenta	#DA3B6C	PLA+	t	2026-11-15 06:09:30
227	eSUN	Olive Green	#555B45	PLA+	t	2026-11-15 06:09:30
228	eSUN	Orange	#EF7749	PLA+	t	2026-11-15 06:09:30
229	eSUN	Peak Green	#A1DA7C	PLA+	t	2026-11-15 06:09:30
230	eSUN	Pink	#E78397	PLA+	t	2026-11-15 06:09:30
231	eSUN	Purple	#8350A4	PLA+	t	2026-11-15 06:09:30
232	eSUN	Red	#C4402A	PLA+	t	2026-11-15 06:09:30
233	eSUN	Silver	#8B8889	PLA+	t	2026-11-15 06:09:30
234	eSUN	Skin	#E3C7AF	PLA+	t	2026-11-15 06:09:30
235	eSUN	White	#E1E9E9	PLA+	t	2026-11-15 06:09:30
236	eSUN	Yellow	#FBCE2B	PLA+	t	2026-11-15 06:09:30
237	eSUN	Blue	#065AA1	Pro PLA+	t	2026-11-15 06:09:30
238	eSUN	Glow in the Dark	#C5C2AB	PLA	t	2026-11-15 06:09:30
239	eSUN	Marble White	#B5BCC0	PLA	t	2026-11-15 06:09:30
240	eSUN	Natural Wood	#EBCFA6	PLA	t	2026-11-15 06:09:30
241	eSUN	Pine Green	#375C49	PLA	t	2026-11-15 06:09:30
242	eSUN	UV Change Purple	#CABBA9	PLA	t	2026-11-15 06:09:30
243	eSUN	eTwinkling Blue	#115CAF	PLA	t	2026-11-15 06:09:30
244	eSUN	eStars Galaxy Black	#403936	PLA	t	2026-11-15 06:09:30
245	eSUN	Silk Blue	#2275AA	PLA Silk	t	2026-11-15 06:09:30
246	eSUN	Silk Bronze	#829172	PLA Silk	t	2026-11-15 06:09:30
247	eSUN	Silk Copper	#AE6B2F	PLA Silk	t	2026-11-15 06:09:30
248	eSUN	Silk Cyan	#34A7CF	PLA Silk	t	2026-11-15 06:09:30
249	eSUN	Silk Dark Yellow	#D4A62E	PLA Silk	t	2026-11-15 06:09:30
250	eSUN	Silk Gold	#C48E2F	PLA Silk	t	2026-11-15 06:09:30
251	eSUN	Silk Green	#7FCB43	PLA Silk	t	2026-11-15 06:09:30
252	eSUN	Silk Jacinth	#DA8061	PLA Silk	t	2026-11-15 06:09:30
253	eSUN	Silk Lime	#C1D762	PLA Silk	t	2026-11-15 06:09:30
254	eSUN	Silk Magic Green Blue	#508669	PLA Silk	t	2026-11-15 06:09:30
255	eSUN	Silk Purple	#905295	PLA Silk	t	2026-11-15 06:09:30
256	eSUN	Silk Red	#C94830	PLA Silk	t	2026-11-15 06:09:30
257	eSUN	Silk Rose Gold	#C7886B	PLA Silk	t	2026-11-15 06:09:30
258	eSUN	Silk Silver	#B5C1C5	PLA Silk	t	2026-11-15 06:09:30
259	eSUN	Silk Violet	#B93CA1	PLA Silk	t	2026-11-15 06:09:30
260	eSUN	Silk White	#E3E0DB	PLA Silk	t	2026-11-15 06:09:30
261	eSUN	Silk Yellow	#DED74B	PLA Silk	t	2026-11-15 06:09:30
262	eSUN	Bronze	#917F57	PLA Metal	t	2026-11-15 06:09:30
263	eSUN	Grey	#626C77	PLA-ST	t	2026-11-15 06:09:30
264	eSUN	Black	#353434	PETG	t	2026-11-15 06:09:30
265	eSUN	Magenta	#E03E76	PETG	t	2026-11-15 06:09:30
266	eSUN	Solid Blue	#1A6FB4	PETG	t	2026-11-15 06:09:30
267	eSUN	Solid Green	#008A58	PETG	t	2026-11-15 06:09:30
268	eSUN	Solid Purple	#7A4795	PETG	t	2026-11-15 06:09:30
269	eSUN	Solid White	#F4F1F1	PETG	t	2026-11-15 06:09:30
270	eSUN	Solid Yellow	#F0CA41	PETG	t	2026-11-15 06:09:30
271	eSUN	Translucent Green	#378041	PETG	t	2026-11-15 06:09:30
272	eSUN	Translucent Orange	#DD7135	PETG	t	2026-11-15 06:09:30
273	eSUN	White	#E7EDED	PETG	t	2026-11-15 06:09:30
274	eSUN	Black	#424445	PETG-HS	t	2026-11-15 06:09:30
275	eSUN	Solid Blue	#1A6FB4	PETG-HS	t	2026-11-15 06:09:30
276	eSUN	Black	#3F3A3F	ABS	t	2026-11-15 06:09:30
277	eSUN	Brown	#624741	ABS	t	2026-11-15 06:09:30
278	eSUN	Natural	#D9E3DD	ABS	t	2026-11-15 06:09:30
279	eSUN	Pine Green	#3C694E	ABS	t	2026-11-15 06:09:30
280	eSUN	Pink	#E86477	ABS	t	2026-11-15 06:09:30
281	eSUN	Red	#A74237	ABS	t	2026-11-15 06:09:30
282	eSUN	Silver	#838080	ABS	t	2026-11-15 06:09:30
283	eSUN	Gray	#616777	ABS+	t	2026-11-15 06:09:30
284	eSUN	Green	#018068	ABS+	t	2026-11-15 06:09:30
285	eSUN	Natural	#E4DEC9	ABS+	t	2026-11-15 06:09:30
286	eSUN	Orange	#EE7845	ABS+	t	2026-11-15 06:09:30
287	eSUN	Silver	#7F807E	ABS+	t	2026-11-15 06:09:30
288	eSUN	White	#E1E1DF	ABS+	t	2026-11-15 06:09:30
289	eSUN	Yellow	#D3BC0F	ABS+	t	2026-11-15 06:09:30
290	Hatchbox	White	#FFFFFF	PLA	t	2026-11-15 06:09:30
291	Hatchbox	Black	#000000	PLA	t	2026-11-15 06:09:30
292	Hatchbox	Gray	#808080	PLA	t	2026-11-15 06:09:30
293	Hatchbox	Red	#FF0000	PLA	t	2026-11-15 06:09:30
294	Hatchbox	Blue	#0000FF	PLA	t	2026-11-15 06:09:30
295	Hatchbox	Green	#00FF00	PLA	t	2026-11-15 06:09:30
296	Hatchbox	Yellow	#FFFF00	PLA	t	2026-11-15 06:09:30
297	Hatchbox	Orange	#FFA500	PLA	t	2026-11-15 06:09:30
298	Hatchbox	Purple	#800080	PLA	t	2026-11-15 06:09:30
299	Hatchbox	Pink	#FFC0CB	PLA	t	2026-11-15 06:09:30
300	Hatchbox	True Blue	#0073CF	PLA	t	2026-11-15 06:09:30
301	Hatchbox	True Green	#008000	PLA	t	2026-11-15 06:09:30
302	Overture	Black	#2B292E	PLA	t	2026-11-15 06:09:30
303	Overture	Blue	#034070	PLA	t	2026-11-15 06:09:30
304	Overture	Cement Gray	#48494A	PLA	t	2026-11-15 06:09:30
305	Overture	Dark Blue	#124775	PLA	t	2026-11-15 06:09:30
306	Overture	Fresh Red	#C01F1D	PLA	t	2026-11-15 06:09:30
307	Overture	Gray Blue	#6D8790	PLA	t	2026-11-15 06:09:30
308	Overture	Green	#318C49	PLA	t	2026-11-15 06:09:30
309	Overture	Highlight Yellow	#FBF93C	PLA	t	2026-11-15 06:09:30
310	Overture	Light Blue	#7CC4D5	PLA	t	2026-11-15 06:09:30
311	Overture	Light Gray	#8F9694	PLA	t	2026-11-15 06:09:30
312	Overture	Neon Green Air	#C5ED33	PLA	t	2026-11-15 06:09:30
313	Overture	Olive Green	#8F843D	PLA	t	2026-11-15 06:09:30
314	Overture	Pink	#DC99B4	PLA	t	2026-11-15 06:09:30
315	Overture	Red	#C9341A	PLA	t	2026-11-15 06:09:30
316	Overture	Royal Gold	#C58F31	PLA	t	2026-11-15 06:09:30
317	Overture	Space Grey	#797779	PLA	t	2026-11-15 06:09:30
318	Overture	White	#E7EBE3	PLA	t	2026-11-15 06:09:30
319	Overture	Black	#3F3E41	PLA Matte	t	2026-11-15 06:09:30
320	Overture	Blue	#277EAB	PLA Matte	t	2026-11-15 06:09:30
321	Overture	Brick Red	#AE4848	PLA Matte	t	2026-11-15 06:09:30
322	Overture	Green	#5EAE73	PLA Matte	t	2026-11-15 06:09:30
323	Overture	Light Grey	#919598	PLA Matte	t	2026-11-15 06:09:30
324	Overture	Light Brown	#BF9C80	PLA Matte	t	2026-11-15 06:09:30
325	Overture	Light Green	#A1C1A5	PLA Matte	t	2026-11-15 06:09:30
326	Overture	Olive Green	#B59837	PLA Matte	t	2026-11-15 06:09:30
327	Overture	Orange	#F59752	PLA Matte	t	2026-11-15 06:09:30
328	Overture	Pink	#EBBDCE	PLA Matte	t	2026-11-15 06:09:30
329	Overture	Purple	#978DC5	PLA Matte	t	2026-11-15 06:09:30
330	Overture	White	#E1E4DD	PLA Matte	t	2026-11-15 06:09:30
331	Overture	Yellow	#FFD359	PLA Matte	t	2026-11-15 06:09:30
332	Overture	Digital Blue	#008FBE	PLA Pro	t	2026-11-15 06:09:30
333	Overture	Light Blue	#68C8DB	PLA Pro	t	2026-11-15 06:09:30
334	Overture	Orange	#F27C1B	PLA Pro	t	2026-11-15 06:09:30
335	Overture	Purple	#7B5DB0	PLA Pro	t	2026-11-15 06:09:30
336	Overture	Red	#E62F18	PLA Pro	t	2026-11-15 06:09:30
337	Overture	Yellow	#DFB233	PLA Pro	t	2026-11-15 06:09:30
338	Overture	Black	#2F2821	PETG	t	2026-11-15 06:09:30
339	Overture	Blue	#225291	PETG	t	2026-11-15 06:09:30
340	Overture	Clear	#BEC3C5	PETG	t	2026-11-15 06:09:30
341	Overture	Pink	#E0A1BA	PETG	t	2026-11-15 06:09:30
342	Overture	Purple	#67518F	PETG	t	2026-11-15 06:09:30
343	Overture	Rock White	#C2C8C9	PETG	t	2026-11-15 06:09:30
344	Overture	Red	#AB291B	PETG	t	2026-11-15 06:09:30
345	Overture	Space Grey	#80817E	PETG	t	2026-11-15 06:09:30
346	Overture	Translucent Blue	#38487B	PETG	t	2026-11-15 06:09:30
347	Overture	White	#E7E9E7	PETG	t	2026-11-15 06:09:30
348	Overture	Yellow	#E6B93C	PETG	t	2026-11-15 06:09:30
349	Overture	Diamond Gray	#5D5F5F	ABS	t	2026-11-15 06:09:30
350	Overture	Diamond Purple	#6B649D	ABS	t	2026-11-15 06:09:30
351	Overture	Gold	#CA9B52	Silk PLA	t	2026-11-15 06:09:30
352	Overture	Neon Green	#C2D74D	Silk PLA	t	2026-11-15 06:09:30
353	Overture	Copper	#B27052	Silk PLA	t	2026-11-15 06:09:30
354	Overture	Glow Blue	#4EA2AA	Glow PLA	t	2026-11-15 06:09:30
355	Overture	Glow Orange	#C2895E	Glow PLA	t	2026-11-15 06:09:30
356	Overture	Glow Red	#C27B7D	Glow PLA	t	2026-11-15 06:09:30
357	Overture	Glow Yellow	#E3F079	Glow PLA	t	2026-11-15 06:09:30
358	Sunlu	Black	#3C3C3C	PLA	t	2026-11-15 06:09:30
359	Sunlu	Blue	#006AB8	PLA	t	2026-11-15 06:09:30
360	Sunlu	Cherry Red	#EA4A5D	PLA	t	2026-11-15 06:09:30
361	Sunlu	Glow in the Dark	#CBCAB8	PLA	t	2026-11-15 06:09:30
362	Sunlu	Green Mint	#4CCB9A	PLA	t	2026-11-15 06:09:30
363	Sunlu	Grey	#6B6E6E	PLA	t	2026-11-15 06:09:30
364	Sunlu	Orange	#E77932	PLA	t	2026-11-15 06:09:30
365	Sunlu	Red	#AC3637	PLA	t	2026-11-15 06:09:30
366	Sunlu	Sky Blue	#0CB7CC	PLA	t	2026-11-15 06:09:30
367	Sunlu	Sunny Orange	#FF7235	PLA	t	2026-11-15 06:09:30
368	Sunlu	Transparent	#C8C7BF	PLA	t	2026-11-15 06:09:30
369	Sunlu	Transparent Orange	#DB7F42	PLA	t	2026-11-15 06:09:30
370	Sunlu	White	#DEDFD9	PLA	t	2026-11-15 06:09:30
371	Sunlu	Wood	#D5BA95	PLA	t	2026-11-15 06:09:30
372	Sunlu	Silk Black	#737272	PLA Silk	t	2026-11-15 06:09:30
373	Sunlu	Silk Green	#34C0A5	PLA Silk	t	2026-11-15 06:09:30
374	Sunlu	Silk Red	#CD5C62	PLA Silk	t	2026-11-15 06:09:30
375	Sunlu	Silky Silver	#C6CBD0	PLA Silk	t	2026-11-15 06:09:30
376	Sunlu	Blue	#00B2CC	PLA Meta	t	2026-11-15 06:09:30
377	Sunlu	Mint Green	#03A490	PLA Meta	t	2026-11-15 06:09:30
378	Sunlu	Sakura Pink	#F5B5C2	PLA Meta	t	2026-11-15 06:09:30
379	Sunlu	Taro Purple	#A69ED0	PLA Meta	t	2026-11-15 06:09:30
380	Sunlu	Beige	#DDBCAC	PLA+	t	2026-11-15 06:09:30
381	Sunlu	Black	#3A3B3B	PLA+	t	2026-11-15 06:09:30
382	Sunlu	Blue	#0063A0	PLA+	t	2026-11-15 06:09:30
383	Sunlu	Green	#4EE349	PLA+	t	2026-11-15 06:09:30
384	Sunlu	Light Gold	#D3943D	PLA+	t	2026-11-15 06:09:30
385	Sunlu	Mint Green	#00B39A	PLA+	t	2026-11-15 06:09:30
386	Sunlu	Orange	#ED7432	PLA+	t	2026-11-15 06:09:30
387	Sunlu	Pure Yellow	#FFBD2C	PLA+	t	2026-11-15 06:09:30
388	Sunlu	Purple	#8887C5	PLA+	t	2026-11-15 06:09:30
389	Sunlu	Red	#B34044	PLA+	t	2026-11-15 06:09:30
390	Sunlu	Silk Blue	#33ACD4	PLA+	t	2026-11-15 06:09:30
391	Sunlu	Silk Brass	#F1A050	PLA+	t	2026-11-15 06:09:30
392	Sunlu	Silk Pink	#FFCAD9	PLA+	t	2026-11-15 06:09:30
393	Sunlu	Silk White	#EEEFE7	PLA+	t	2026-11-15 06:09:30
394	Sunlu	Skin	#F7BEA1	PLA+	t	2026-11-15 06:09:30
395	Sunlu	White	#E6E6E2	PLA+	t	2026-11-15 06:09:30
396	Sunlu	Black	#3F4141	PETG	t	2026-11-15 06:09:30
397	Sunlu	Blue	#0068AB	PETG	t	2026-11-15 06:09:30
398	Sunlu	Green	#67DB25	PETG	t	2026-11-15 06:09:30
399	Sunlu	Olive Green	#707D63	PETG	t	2026-11-15 06:09:30
400	Sunlu	Transparent	#BAB9B4	PETG	t	2026-11-15 06:09:30
401	Sunlu	White	#DBDDD9	PETG	t	2026-11-15 06:09:30
402	Sunlu	Black	#404142	ABS	t	2026-11-15 06:09:30
403	Creality	Black	#282C2C	Hyper PLA	t	2026-11-15 06:09:30
404	Creality	Blue	#0881BE	Hyper PLA	t	2026-11-15 06:09:30
405	Creality	Grey	#7A7C7C	Hyper PLA	t	2026-11-15 06:09:30
406	Creality	Purple	#B0347E	Hyper PLA	t	2026-11-15 06:09:30
407	Creality	Red	#C32E2F	Hyper PLA	t	2026-11-15 06:09:30
408	Creality	White	#DEE4E1	Hyper PLA	t	2026-11-15 06:09:30
409	Creality	Black	#322F2D	Hyper PLA-CF	t	2026-11-15 06:09:30
410	Creality	Gray	#8F9395	PLA	t	2026-11-15 06:09:30
411	Creality	White	#E1DFD0	PLA	t	2026-11-15 06:09:30
412	Creality	White	#E3E5E1	PETG	t	2026-11-15 06:09:30
413	Creality	Blue-Green	#479B7D	Silk PLA	t	2026-11-15 06:09:30
414	Elegoo	Black	#282929	PLA	t	2026-11-15 06:09:30
416	Elegoo	Galaxy Black	#32464E	PLA	t	2026-11-15 06:09:30
417	Elegoo	Galaxy Purple	#3A2F6F	PLA	t	2026-11-15 06:09:30
418	Elegoo	Grey	#B5B7B7	PLA	t	2026-11-15 06:09:30
419	Elegoo	Peacock Blue	#21606B	PLA	t	2026-11-15 06:09:30
420	Elegoo	Sky Blue	#46C8D4	PLA	t	2026-11-15 06:09:30
421	Elegoo	Black	#343132	PLA+	t	2026-11-15 06:09:30
422	Elegoo	Orange	#CC6A2F	PLA+	t	2026-11-15 06:09:30
423	Elegoo	Purple	#6E45A7	PLA+	t	2026-11-15 06:09:30
424	Elegoo	Coral Pink	#DB6E6D	Silk PLA	t	2026-11-15 06:09:30
425	Elegoo	Gold	#E2AC00	Silk PLA	t	2026-11-15 06:09:30
426	Elegoo	Silver	#93969B	Silk PLA	t	2026-11-15 06:09:30
427	Jayo	Black	#2F2E2D	PLA+	t	2026-11-15 06:09:30
428	Jayo	Cherry Red	#C43536	PLA+	t	2026-11-15 06:09:30
429	Jayo	White	#D9E0E7	PLA+	t	2026-11-15 06:09:30
430	Inland	Black	#27272C	PLA	t	2026-11-15 06:09:30
431	Inland	Blue	#044482	PLA	t	2026-11-15 06:09:30
432	Inland	Coral	#C16062	PLA	t	2026-11-15 06:09:30
433	Inland	Egyptian Blue	#075AAC	PLA	t	2026-11-15 06:09:30
434	Inland	Gold	#D7B536	PLA	t	2026-11-15 06:09:30
435	Inland	Green	#407166	PLA	t	2026-11-15 06:09:30
436	Inland	Grey	#6F7983	PLA	t	2026-11-15 06:09:30
437	Inland	Light Blue	#3CA4B8	PLA	t	2026-11-15 06:09:30
438	Inland	Military Green	#5B6D37	PLA	t	2026-11-15 06:09:30
439	Inland	Pink	#FC97AF	PLA	t	2026-11-15 06:09:30
440	Inland	Red	#C43220	PLA	t	2026-11-15 06:09:30
441	Inland	Silver	#8A8F92	PLA	t	2026-11-15 06:09:30
442	Inland	True Red	#B13137	PLA	t	2026-11-15 06:09:30
443	Inland	White	#E0E3E3	PLA	t	2026-11-15 06:09:30
444	Inland	Wood	#DEB98F	PLA	t	2026-11-15 06:09:30
445	Inland	Black	#2B272B	PLA+	t	2026-11-15 06:09:30
446	Inland	Blue	#054990	PLA+	t	2026-11-15 06:09:30
447	Inland	Bone White	#ABA18F	PLA+	t	2026-11-15 06:09:30
448	Inland	Dark Blue	#2C3353	PLA+	t	2026-11-15 06:09:30
449	Inland	Light Blue	#079FBF	PLA+	t	2026-11-15 06:09:30
450	Inland	Magenta	#DE2B60	PLA+	t	2026-11-15 06:09:30
451	Inland	Orange	#FB8B5A	PLA+	t	2026-11-15 06:09:30
452	Inland	Pink	#F291A4	PLA+	t	2026-11-15 06:09:30
453	Inland	Purple	#744FA0	PLA+	t	2026-11-15 06:09:30
454	Inland	Silver	#868A8B	PLA+	t	2026-11-15 06:09:30
455	Inland	White	#E3E5E5	PLA+	t	2026-11-15 06:09:30
456	Inland	Yellow	#F8D008	PLA+	t	2026-11-15 06:09:30
457	Inland	Blue	#084480	PETG	t	2026-11-15 06:09:30
458	Inland	Green	#2B783E	PETG	t	2026-11-15 06:09:30
459	Inland	Magenta	#E14170	PETG	t	2026-11-15 06:09:30
460	Inland	Transparent	#D1D6D1	PETG	t	2026-11-15 06:09:30
461	Inland	True Red	#97392B	PETG	t	2026-11-15 06:09:30
462	Inland	Grey	#8A97A2	ABS	t	2026-11-15 06:09:30
463	Inland	Light Blue	#6CBECF	ABS	t	2026-11-15 06:09:30
464	Inland	Orange	#E8712F	ABS	t	2026-11-15 06:09:30
465	Inland	Light Gray	#8D9497	Tough PLA	t	2026-11-15 06:09:30
466	Inland	Yellow	#FFBB3F	Tough PLA	t	2026-11-15 06:09:30
467	Eryone	Galaxy Purple	#60617B	PLA	t	2026-11-15 06:09:30
468	Eryone	Galaxy Red	#8E3332	PLA	t	2026-11-15 06:09:30
469	Eryone	Glow in the Dark	#C2C1AF	PLA	t	2026-11-15 06:09:30
470	Eryone	Ivory White	#DCDCD3	PLA	t	2026-11-15 06:09:30
471	Eryone	Silk Blue	#64A9D3	PLA	t	2026-11-15 06:09:30
472	Eryone	Silk Copper	#B36A50	PLA	t	2026-11-15 06:09:30
473	Eryone	Silk Gold	#D5983D	PLA	t	2026-11-15 06:09:30
474	Eryone	Silk Gold Copper	#D69366	PLA	t	2026-11-15 06:09:30
475	Eryone	Silk Gold Silver	#ABA787	PLA	t	2026-11-15 06:09:30
476	Eryone	Ultra Silk Black	#5B6264	PLA	t	2026-11-15 06:09:30
477	Eryone	Ultra Silk Copper	#B46A4D	PLA	t	2026-11-15 06:09:30
478	Eryone	Ultra Silk Silver	#999BA5	PLA	t	2026-11-15 06:09:30
479	Eryone	Army Green	#5D644D	PLA+	t	2026-11-15 06:09:30
480	Eryone	Black	#414446	ASA	t	2026-11-15 06:09:30
481	Eryone	Light Wood	#A5886E	PLA Wood	t	2026-11-15 06:09:30
482	ColorFabb	Stonefill Light Gray	#A9B2B7	PLA	t	2026-11-15 06:09:30
483	ColorFabb	WoodFill	#B89775	PLA	t	2026-11-15 06:09:30
484	ColorFabb	CopperFill	#9D7465	PLA/PHA	t	2026-11-15 06:09:30
485	ColorFabb	CorkFill	#7F6150	PLA/PHA	t	2026-11-15 06:09:30
486	ColorFabb	Natural	#CFCFC2	PLA/PHA	t	2026-11-15 06:09:30
487	ColorFabb	Light Gray	#BFC5BE	XT	t	2026-11-15 06:09:30
488	ColorFabb	Black	#3B3635	XT	t	2026-11-15 06:09:30
489	Fillamentum	Baby Blue	#B9D7DC	PLA Extrafill	t	2026-11-15 06:09:30
490	Fillamentum	Chocolate Brown	#5B4A45	PLA Extrafill	t	2026-11-15 06:09:30
491	Fillamentum	Cobalt Blue	#333D5C	PLA Extrafill	t	2026-11-15 06:09:30
492	Fillamentum	Crystal Clear Smaragd Green	#028D77	PLA Extrafill	t	2026-11-15 06:09:30
493	Fillamentum	Everybody's Magenta	#E1347D	PLA Extrafill	t	2026-11-15 06:09:30
494	Fillamentum	Gold Happens	#BC994D	PLA Extrafill	t	2026-11-15 06:09:30
495	Fillamentum	Mukha	#A88866	PLA Extrafill	t	2026-11-15 06:09:30
496	Fillamentum	Pearl Night Blue	#045589	PLA Extrafill	t	2026-11-15 06:09:30
497	Fillamentum	Pearl Ruby Red	#791F2A	PLA Extrafill	t	2026-11-15 06:09:30
498	Fillamentum	Rapunzel Silver	#AFAFB0	PLA Extrafill	t	2026-11-15 06:09:30
499	Fillamentum	Vertigo Cherry	#752F38	PLA Extrafill	t	2026-11-15 06:09:30
500	Fillamentum	Vertigo Galaxy	#333928	PLA Extrafill	t	2026-11-15 06:09:30
501	Fillamentum	Vertigo Grey	#5A5963	PLA Extrafill	t	2026-11-15 06:09:30
502	Fillamentum	Vertigo Starlight	#343A4F	PLA Extrafill	t	2026-11-15 06:09:30
503	Fillamentum	Wizard's Voodoo	#3F465E	PLA Extrafill	t	2026-11-15 06:09:30
504	Fillamentum	Crystal Clear	#EBECF2	PLA	t	2026-11-15 06:09:30
505	Fillamentum	Crystal Clear Amethyst Purple	#9F99BC	PLA	t	2026-11-15 06:09:30
506	Fillamentum	Crystal Clear Iceland Blue	#82BBCD	PLA	t	2026-11-15 06:09:30
507	Fillamentum	Crystal Clear Tangerine Orange	#ECD082	PLA	t	2026-11-15 06:09:30
508	Fillamentum	Lilac	#A99FCF	PLA	t	2026-11-15 06:09:30
509	Fillamentum	Timberfill Cinnamon	#AC7C67	PLA	t	2026-11-15 06:09:30
510	Fillamentum	Timberfill Rosewood	#6A564E	PLA	t	2026-11-15 06:09:30
511	Fillamentum	Vertigo Jade	#217F60	PLA	t	2026-11-15 06:09:30
512	Fillamentum	Anthracite Grey	#4B4F50	ASA Extrafill	t	2026-11-15 06:09:30
513	Fillamentum	Green Grass	#678653	ASA Extrafill	t	2026-11-15 06:09:30
514	Fillamentum	Grey Blue	#495965	ASA Extrafill	t	2026-11-15 06:09:30
515	Fillamentum	Metallic Grey	#878A8C	ASA Extrafill	t	2026-11-15 06:09:30
516	Fillamentum	Sky Blue	#0783B6	ASA Extrafill	t	2026-11-15 06:09:30
517	Fillamentum	Snow White	#F3F3EF	ASA Extrafill	t	2026-11-15 06:09:30
518	Fillamentum	Traffic Black	#3B3B3F	ASA Extrafill	t	2026-11-15 06:09:30
519	Fillamentum	Traffic White	#E9E7DA	ASA Extrafill	t	2026-11-15 06:09:30
520	Fillamentum	White Aluminium	#9CA1A2	ASA Extrafill	t	2026-11-15 06:09:30
521	Fillamentum	Black Soul	#292B27	CPE HG100	t	2026-11-15 06:09:30
522	Fillamentum	Ghost White	#E5E8E7	CPE HG100	t	2026-11-15 06:09:30
523	Fillamentum	Natural	#DCE4DF	CPE HG100	t	2026-11-15 06:09:30
524	Fillamentum	Blue Transparent	#047990	Flexfill TPU 98A	t	2026-11-15 06:09:30
525	Fillamentum	Carrot Orange	#EA6E21	Flexfill TPU 98A	t	2026-11-15 06:09:30
526	Fillamentum	Metallic Grey	#8F8E8F	Flexfill TPU 98A	t	2026-11-15 06:09:30
527	Fillamentum	Pistachio Green	#A7BE36	Flexfill TPU 98A	t	2026-11-15 06:09:30
528	Fillamentum	Signal Red	#9A2222	Flexfill TPU 98A	t	2026-11-15 06:09:30
529	Fillamentum	Traffic Black	#26262A	Flexfill TPU 98A	t	2026-11-15 06:09:30
530	Fillamentum	Vertigo Grey	#515150	Flexfill TPU 98A	t	2026-11-15 06:09:30
531	FormFutura	Basalt Grey	#5B5F61	PLA	t	2026-11-15 06:09:30
532	FormFutura	Dark Blue	#084B86	PLA	t	2026-11-15 06:09:30
533	FormFutura	Galaxy Champagne Gold	#AE9D83	PLA	t	2026-11-15 06:09:30
534	FormFutura	Gold High Gloss	#C89B4B	PLA	t	2026-11-15 06:09:30
535	FormFutura	High Gloss White	#D0D7D8	PLA	t	2026-11-15 06:09:30
536	FormFutura	Magenta High Gloss	#B94474	PLA	t	2026-11-15 06:09:30
537	FormFutura	Stonefil Terracotta	#BD634C	PLA	t	2026-11-15 06:09:30
538	FormFutura	Yellow Green	#7AA837	PLA	t	2026-11-15 06:09:30
539	FormFutura	Pure Orange	#FA9145	EasyFil PLA	t	2026-11-15 06:09:30
540	FormFutura	ReForm Black	#3A3B3B	ReForm rPLA	t	2026-11-15 06:09:30
541	FormFutura	ReForm White	#F3F3EC	ReForm rPLA	t	2026-11-15 06:09:30
542	Fiberlogy	Mineral White	#E2D9CD	PLA	t	2026-11-15 06:09:30
543	Fiberlogy	Aurora	#3C4452	Easy PLA	t	2026-11-15 06:09:30
544	Fiberlogy	Army Green	#535F4F	Impact PLA	t	2026-11-15 06:09:30
545	Fiberlogy	Olive Green	#61634B	ASA	t	2026-11-15 06:09:30
546	Fiberlogy	White	#F2F2EE	Easy PETG	t	2026-11-15 06:09:30
547	Fiberlogy	Green	#A2D780	FiberSilk Metallic	t	2026-11-15 06:09:30
548	MatterHackers	Blue	#044786	Build PLA	t	2026-11-15 06:09:30
549	MatterHackers	Magenta	#CD4263	Build PLA	t	2026-11-15 06:09:30
550	MatterHackers	Red	#C4351B	Build PLA	t	2026-11-15 06:09:30
551	MatterHackers	Shiny Gold	#DFAC1E	Build PLA	t	2026-11-15 06:09:30
552	MatterHackers	Silky Copper	#C76F35	Build PLA	t	2026-11-15 06:09:30
553	MatterHackers	Silky Silver	#BDBDB8	Build PLA	t	2026-11-15 06:09:30
554	MatterHackers	Silky Teal	#078EBC	Build PLA	t	2026-11-15 06:09:30
555	MatterHackers	Silky Yellow	#EDB554	Build PLA	t	2026-11-15 06:09:30
556	MatterHackers	Yellow	#EBC100	Build PLA	t	2026-11-15 06:09:30
557	MatterHackers	Gold	#E7AC37	PLA	t	2026-11-15 06:09:30
558	MatterHackers	Lime Green	#75BA52	PLA	t	2026-11-15 06:09:30
559	MatterHackers	Pearl White	#D4DCDD	PLA	t	2026-11-15 06:09:30
560	MatterHackers	Red	#E54931	PLA	t	2026-11-15 06:09:30
561	MatterHackers	Electric Pink	#F35886	Pro PLA	t	2026-11-15 06:09:30
562	MatterHackers	Jet Gray	#474B4C	Pro PLA	t	2026-11-15 06:09:30
563	MatterHackers	Clear	#D5DDDA	PETG	t	2026-11-15 06:09:30
564	MatterHackers	White	#E9EBEF	PETG	t	2026-11-15 06:09:30
565	MatterHackers	Black	#3D3C38	NylonX	t	2026-11-15 06:09:30
566	MatterHackers	White	#DCDED9	NylonG	t	2026-11-15 06:09:30
567	Protopasta	Atikam Teal	#135859	HTPLA	t	2026-11-15 06:09:30
568	Protopasta	Blood of My Enemies	#7A1A23	HTPLA	t	2026-11-15 06:09:30
569	Protopasta	Blue Opaque	#044A86	HTPLA	t	2026-11-15 06:09:30
570	Protopasta	Blue Wonder Glitter Flake	#20556F	HTPLA	t	2026-11-15 06:09:30
571	Protopasta	Bobbi's Purple Iris	#542B5C	HTPLA	t	2026-11-15 06:09:30
572	Protopasta	Brass Composite	#8C7A4F	HTPLA	t	2026-11-15 06:09:30
573	Protopasta	Bronze Composite	#635146	HTPLA	t	2026-11-15 06:09:30
574	Protopasta	Candy Apple Metallic Red	#A32423	HTPLA	t	2026-11-15 06:09:30
575	Protopasta	Cloverleaf Metallic Green	#245A3F	HTPLA	t	2026-11-15 06:09:30
576	Protopasta	Copper Composite	#976252	HTPLA	t	2026-11-15 06:09:30
577	Protopasta	Cupid's Crush Metallic Pink	#EA8699	HTPLA	t	2026-11-15 06:09:30
578	Protopasta	Double Espresso Metallic Brown	#6B473B	HTPLA	t	2026-11-15 06:09:30
579	Protopasta	Dragon Fruit Smoothie	#B3295F	HTPLA	t	2026-11-15 06:09:30
580	Protopasta	Dragon Scale Purple	#8A80AC	HTPLA	t	2026-11-15 06:09:30
581	Protopasta	Dusty Smoke	#8F9491	HTPLA	t	2026-11-15 06:09:30
582	Protopasta	Electric Lemonade Metallic Yellow	#E4CA6B	HTPLA	t	2026-11-15 06:09:30
583	Protopasta	Empire Strikes Metallic Black	#393B3B	HTPLA	t	2026-11-15 06:09:30
584	Protopasta	Fluorescent Yellow	#D4DC3A	HTPLA	t	2026-11-15 06:09:30
585	Protopasta	Galactic Empire Metallic Purple	#3B3F5D	HTPLA	t	2026-11-15 06:09:30
586	Protopasta	Glitter's Mane	#128C93	HTPLA	t	2026-11-15 06:09:30
587	Protopasta	Gold Dust Glitter Flake	#BFAE6D	HTPLA	t	2026-11-15 06:09:30
588	Protopasta	Good as Gold	#9A774B	HTPLA	t	2026-11-15 06:09:30
589	Protopasta	Good Old Gray	#6D737B	HTPLA	t	2026-11-15 06:09:30
590	Protopasta	Green Glowing Natural	#D4D3AD	HTPLA	t	2026-11-15 06:09:30
591	Protopasta	Heartthrob Red Metallic	#7E3030	HTPLA	t	2026-11-15 06:09:30
592	Protopasta	Joel's Highfive Blue	#056B9A	HTPLA	t	2026-11-15 06:09:30
593	Protopasta	Lootsef Green	#8FB841	HTPLA	t	2026-11-15 06:09:30
594	Protopasta	Luke's Proton Purple	#7D3F59	HTPLA	t	2026-11-15 06:09:30
595	Protopasta	Mahogany	#7F5D4F	HTPLA	t	2026-11-15 06:09:30
596	Protopasta	Matte Fiber Black	#3F3F3E	HTPLA	t	2026-11-15 06:09:30
597	Protopasta	Matte Fiber Daffodil	#B79868	HTPLA	t	2026-11-15 06:09:30
598	Protopasta	Matte Fiber Gray	#767A7D	HTPLA	t	2026-11-15 06:09:30
599	Protopasta	Matte Fiber Walnut	#6F5D4E	HTPLA	t	2026-11-15 06:09:30
600	Protopasta	Matte Fiber White	#F4EADB	HTPLA	t	2026-11-15 06:09:30
601	Protopasta	Mermaid's Tale Metallic Teal	#026768	HTPLA	t	2026-11-15 06:09:30
602	Protopasta	Moonstruck White Satin	#DCE4DD	HTPLA	t	2026-11-15 06:09:30
603	Protopasta	Obsidian	#474743	HTPLA	t	2026-11-15 06:09:30
604	Protopasta	Opaque Black	#312F30	HTPLA	t	2026-11-15 06:09:30
605	Protopasta	Opaque Natural	#CBD0D0	HTPLA	t	2026-11-15 06:09:30
606	Protopasta	Opaque White	#DFE4E2	HTPLA	t	2026-11-15 06:09:30
607	Protopasta	Orange Papaya Smoothie	#C57231	HTPLA	t	2026-11-15 06:09:30
608	Protopasta	Out of Darts Orange	#E58429	HTPLA	t	2026-11-15 06:09:30
609	Protopasta	Pineapple Banana Smoothie	#D0A645	HTPLA	t	2026-11-15 06:09:30
610	Protopasta	Pretty in Pink Pearl	#CE95AE	HTPLA	t	2026-11-15 06:09:30
611	Protopasta	Red Hot Cinnamon	#7C4448	HTPLA	t	2026-11-15 06:09:30
612	Protopasta	Red Opaque	#972425	HTPLA	t	2026-11-15 06:09:30
613	Protopasta	Second to None Silver	#B4B6B6	HTPLA	t	2026-11-15 06:09:30
614	Protopasta	Sparkling Spruce	#47614C	HTPLA	t	2026-11-15 06:09:30
615	Protopasta	Stardust Glitter Flake	#AAB1AE	HTPLA	t	2026-11-15 06:09:30
616	Protopasta	Summertime Green	#89A78A	HTPLA	t	2026-11-15 06:09:30
617	Protopasta	Tangerine Orange Metallic Gold	#C05834	HTPLA	t	2026-11-15 06:09:30
618	Protopasta	Translucent Iridescent Ice	#C4CBC8	HTPLA	t	2026-11-15 06:09:30
619	Protopasta	Translucent Silver Smoke	#A5ACA9	HTPLA	t	2026-11-15 06:09:30
620	Protopasta	Unicorn Tears White Glitter	#D7DEDE	HTPLA	t	2026-11-15 06:09:30
621	Protopasta	What Karat? Smooth Gold	#CD974B	HTPLA	t	2026-11-15 06:09:30
622	Protopasta	White	#F6F5F0	HTPLA	t	2026-11-15 06:09:30
623	Protopasta	White Marble	#C6CECF	HTPLA	t	2026-11-15 06:09:30
624	Protopasta	Winter Blue Glitter Flake	#056F9D	HTPLA	t	2026-11-15 06:09:30
625	Protopasta	Black	#323132	PLA	t	2026-11-15 06:09:30
626	Protopasta	Conductive	#373838	PLA	t	2026-11-15 06:09:30
627	Protopasta	Iron Composite	#555451	PLA	t	2026-11-15 06:09:30
628	Protopasta	Natural	#E1DFD6	PLA	t	2026-11-15 06:09:30
629	Protopasta	Steel Composite	#676561	PLA	t	2026-11-15 06:09:30
630	Protopasta	Black	#424140	Carbon Fiber PLA	t	2026-11-15 06:09:30
631	3DXTECH	Natural	#DED7C6	ASA	t	2026-11-15 06:09:30
632	3DXTECH	Black	#444342	Carbon Fiber PLA	t	2026-11-15 06:09:30
633	3DXTECH	Venom	#CACC19	ECOMAX PLA	t	2026-11-15 06:09:30
634	3DXTECH	Simubone	#EAE0CB	PLA	t	2026-11-15 06:09:30
635	3DXTECH	Blue Frost	#B1C1C5	rPETG	t	2026-11-15 06:09:30
636	Sakata3D	Red	#B63A32	PLA	t	2026-11-15 06:09:30
637	Sakata3D	Silk Sunset	#F49545	PLA	t	2026-11-15 06:09:30
638	Sakata3D	Surf Green	#00C1A8	PLA	t	2026-11-15 06:09:30
\.


--
-- Data for Name: external_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_links (id, name, url, icon, custom_icon, open_in_new_tab, sort_order, created_at, updated_at, nav_group) FROM stdin;
\.


--
-- Data for Name: filament_calibration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filament_calibration (id, filament_id, filament_setting_id, nozzle_diameter, nozzle_volume_type, extruder_id, pa_k_value, pa_n_coef, flow_ratio, confidence, cali_mode, source, is_active, cali_idx, name, notes, nozzle_id, calibrated_by_user_id, created_at, printer_id, tower_result) FROM stdin;
\.


--
-- Data for Name: filament_shopping_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filament_shopping_list (id, material, subtype, brand, quantity_spools, note, status, purchased_at, added_at) FROM stdin;
\.


--
-- Data for Name: filament_sku_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filament_sku_settings (id, material, subtype, brand, lead_time_days, safety_margin_value, safety_margin_unit, alerts_snoozed, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: git_backup_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_backup_config (id, provider, repository_url, access_token, branch, api_base_url, schedule_enabled, schedule_type, schedule_cron, backup_kprofiles, backup_cloud_profiles, backup_settings, backup_spools, backup_archives, enabled, last_backup_at, last_backup_status, last_backup_message, last_backup_commit_sha, next_scheduled_run, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: git_backup_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_backup_logs (id, config_id, started_at, completed_at, status, trigger, commit_sha, files_changed, error_message) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, name, description, permissions, is_system, created_at, updated_at) FROM stdin;
1	Administrators	Full access to all features and settings	["printers:read", "printers:create", "printers:update", "printers:delete", "printers:control", "printers:files", "printers:ams_rfid", "printers:clear_plate", "archives:read", "archives:create", "archives:update_own", "archives:update_all", "archives:delete_own", "archives:delete_all", "archives:reprint_own", "archives:reprint_all", "archives:purge", "queue:read", "queue:create", "queue:update_own", "queue:update_all", "queue:delete_own", "queue:delete_all", "queue:reorder", "library:read", "library:upload", "library:update_own", "library:update_all", "library:delete_own", "library:delete_all", "library:purge", "library:notes_write", "makerworld:view", "makerworld:import", "projects:read", "projects:create", "projects:update", "projects:delete", "inventory:read", "inventory:create", "inventory:update", "inventory:delete", "inventory:view_assignments", "smart_plugs:read", "smart_plugs:create", "smart_plugs:update", "smart_plugs:delete", "smart_plugs:control", "camera:view", "maintenance:read", "maintenance:create", "maintenance:update", "maintenance:delete", "kprofiles:read", "kprofiles:create", "kprofiles:update", "kprofiles:delete", "notifications:read", "notifications:create", "notifications:update", "notifications:delete", "notifications:user_email", "notification_templates:read", "notification_templates:update", "external_links:read", "external_links:create", "external_links:update", "external_links:delete", "discovery:scan", "firmware:read", "firmware:update", "ams_history:read", "stats:read", "stats:filter_by_user", "system:read", "settings:read", "settings:update", "settings:backup", "settings:restore", "git:backup", "git:restore", "cloud:auth", "api_keys:read", "api_keys:create", "api_keys:update", "api_keys:delete", "users:read", "users:create", "users:update", "users:delete", "groups:read", "groups:create", "groups:update", "groups:delete", "websocket:connect", "inventory:forecast_read", "inventory:forecast_write"]	t	2026-11-15 06:09:29	2026-11-15 06:12:57.300617
2	Operators	Can control printers, manage queue and archives, view settings	["printers:read", "printers:create", "printers:update", "printers:delete", "printers:control", "printers:files", "printers:ams_rfid", "printers:clear_plate", "archives:read", "archives:create", "archives:update_own", "archives:delete_own", "archives:reprint_own", "queue:read", "queue:create", "queue:update_own", "queue:delete_own", "queue:reorder", "library:read", "library:upload", "library:update_own", "library:delete_own", "library:notes_write", "makerworld:view", "makerworld:import", "projects:read", "projects:create", "projects:update", "projects:delete", "inventory:read", "inventory:create", "inventory:update", "inventory:delete", "inventory:view_assignments", "smart_plugs:read", "smart_plugs:create", "smart_plugs:update", "smart_plugs:delete", "smart_plugs:control", "camera:view", "maintenance:read", "maintenance:create", "maintenance:update", "maintenance:delete", "kprofiles:read", "kprofiles:create", "kprofiles:update", "kprofiles:delete", "notifications:read", "notifications:create", "notifications:update", "notifications:delete", "notifications:user_email", "notification_templates:read", "notification_templates:update", "external_links:read", "external_links:create", "external_links:update", "external_links:delete", "discovery:scan", "firmware:read", "ams_history:read", "stats:read", "stats:filter_by_user", "system:read", "settings:read", "websocket:connect", "inventory:forecast_read", "inventory:forecast_write"]	t	2026-11-15 06:09:29	2026-11-15 06:12:57.300617
3	Viewers	Read-only access to printers, archives, and queue	["printers:read", "archives:read", "queue:read", "library:read", "library:notes_write", "makerworld:view", "projects:read", "inventory:read", "inventory:view_assignments", "smart_plugs:read", "camera:view", "maintenance:read", "kprofiles:read", "notifications:read", "notification_templates:read", "external_links:read", "firmware:read", "ams_history:read", "stats:read", "system:read", "settings:read", "websocket:connect", "inventory:forecast_read"]	t	2026-11-15 06:09:29	2026-11-15 06:12:57.300617
\.


--
-- Data for Name: kprofile_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kprofile_notes (id, filament_calibration_id, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: library_file_makerworld_meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_file_makerworld_meta (id, library_file_id, title, description, author_name, author_profile_url, license, original_design_id, variant_title, variant_description, variant_url, profile_id, cover_path, variant_cover_path, sliced_for, compatible_models, needs_ams, material_count, materials, model_id_alphanumeric, raw_payload, imported_at) FROM stdin;
\.


--
-- Data for Name: library_file_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_file_notes (id, library_file_id, user_id, body, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: library_file_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_file_projects (file_id, project_id) FROM stdin;
\.


--
-- Data for Name: library_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_files (id, folder_id, is_external, filename, file_path, file_type, file_size, file_hash, thumbnail_path, file_metadata, last_printed_at, notes, created_by_id, swap_compatible, created_at, updated_at, print_count, deleted_at, source_type, source_url, file_tags) FROM stdin;
\.


--
-- Data for Name: library_folder_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_folder_projects (folder_id, project_id) FROM stdin;
\.


--
-- Data for Name: library_folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_folders (id, name, parent_id, is_external, external_readonly, external_show_hidden, external_path, archive_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: local_presets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.local_presets (id, name, preset_type, source, filament_type, filament_vendor, nozzle_temp_min, nozzle_temp_max, pressure_advance, default_filament_colour, filament_cost, filament_density, compatible_printers, setting, inherits, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: long_lived_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.long_lived_tokens (id, user_id, name, lookup_prefix, secret_hash, scope, expires_at, last_used_at, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: macros; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.macros (id, name, description, printer_models, swap_mode_only, swap_profile, event, action_type, mqtt_action, delay_seconds, gcode, is_custom, enabled, created_at, updated_at) FROM stdin;
1	A1 Mini. Kit Edition. Start Sequence	\N	["A1 Mini"]	t	a1mini_kit	swap_mode_start	gcode	\N	0	;swap ini code\nG91 ;\nG0 Z50 F1000;\nG0 Z-20;\nG90;\nG28 XY;\nG0 Y-4 F5000; grab\nG0 Y145; pull and fix the plate\nG0 Y115 F1000; rehook\nG0 Y180 F5000; pull\nG4 P500; wait\nG0 Y186.5 F200; fix the plate\nG4 P500; wait\nG0 Y3 F15000; back\nG0 Y-5 F200; snap\nG4 P500; wait\nG0 Y10 F1000; load\nG0 Y20 F15000; ready	f	t	2026-11-15 06:09:30	2026-11-15 06:09:30
2	A1 Mini. Kit Edition. Change Table	\N	["A1 Mini"]	t	a1mini_kit	swap_mode_change_table	gcode	\N	0	;swap\nG0 X-10 F5000;\nG0 Z175;\nG0 Y-5 F2000;\nG0 Y186.5 F2000;\nG0 Y182 F10000;\nG0 Z186;\nG0 Y120 F500;\nG0 Y-4 Z175 F5000;\nG0 Y145;\nG0 Y115 F1000;\nG0 Y25 F500;\nG0 Y85 F1000;\nG0 Y180 F2000;\nG4 P500; wait\nG0 Y186.5 F200;\nG4 P500; wait\nG0 Y3 F3000;\nG0 Y-5 F200;\nG4 P500; wait\nG0 Y10 F1000;\nG0 Z100 Y186 F2000;\nG0 Y150;\nG4 P1000; wait	f	t	2026-11-15 06:09:30	2026-11-15 06:09:30
3	A1 Mini. STL Edition. Start Sequence	swapmod-stl-a1m / swap-sequence_v05_20260312 - initial plate seating before the first print.	["A1 Mini"]	t	a1mini_stl	swap_mode_start	gcode	\N	0	;ini swapmod-stl-a1m start / swap-sequence_v05_20260312\nG90;\nG28;\nG0 Z30 F5000;\nG0 X-10;\nG0 Y-6 F2000;\nG0 Y150;\nG0 Y100;\nG0 Y186.5;\nG0 Y-6;\nG4 S1;\nG0 Y5 F500;\nG0 Y100 F5000;	f	t	2026-11-15 06:09:31	2026-11-15 06:09:31
4	A1 Mini. STL Edition. Change Table	swapmod-stl-a1m / swap-sequence_v05_20260312 - swaps the finished plate out for a fresh one between prints.	["A1 Mini"]	t	a1mini_stl	swap_mode_change_table	gcode	\N	0	;swap swapmod-stl-a1m start / swap-sequence_v05_20260312\nG0 X170 F5000;\nG0 Z180 F2000;\nG0 Y186.5 F3000;\nG0 Z186 F2000;\nG0 X188 F5000;\nG0 Z180;\nG4 S1;\nG0 Y150 F200;\nG0 Y-6 F2000;\nG0 Z186 F5000;\nG0 X170;\nG0 Z180 F5000;\nG0 Y150 F2000;\nG0 Y15 F3000;\nG0 Y180 F2000;\nG0 Y186.5 F500;\nG0 Y5 F5000;\nG0 Y-6 F200;\nG4 S1;\nG0 Y5 F500;\nG0 Y100 F5000;	f	t	2026-11-15 06:09:31	2026-11-15 06:09:31
5	JobOx A1. Start Sequence	Extracted from A1-clone test file (Y=266 full-size overflow). Review before first run on real hardware.	["A1"]	t	jobox-a1	swap_mode_start	gcode	\N	0	;========start plate change=================\nG91;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG1 Z5 F1200;\nG90;\nG28 Y;\nG90;\nG1 Y266 F2000;\nG4 P1000;\nG91;\nG380 S2 Z30 F1200;\nG90;\nM211 Y0 Z0;\nG91;\nG90;\nG1 Y50 F1000;\nG1 Y0 F2500;\nG91;\nG380 S3 Z-20 F1200;\nG90;\nG1 Y266 F2000;\nG1 Y43 F2000;\nG1 Y266 F2000;\nG1 Y250 F8000;\nG1 Y266 F8000;\nG1 Y43 F5000;\nG1 Y266 F2000;\nG1 Y250 F8000;\nG1 Y266 F8000;\nG1 Y-2 F7000;\nG1 Y150 F2000;	f	t	2026-11-15 06:09:31	2026-11-15 06:09:31
6	JobOx A1. Change Table	Extracted from A1-clone test file (Y=266 full-size overflow). Same sequence as start until real JobOx gcode is confirmed.	["A1"]	t	jobox-a1	swap_mode_change_table	gcode	\N	0	;========start plate change=================\nG91;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG1 Z5 F1200;\nG90;\nG28 Y;\nG90;\nG1 Y266 F2000;\nG4 P1000;\nG91;\nG380 S2 Z30 F1200;\nG90;\nM211 Y0 Z0;\nG91;\nG90;\nG1 Y50 F1000;\nG1 Y0 F2500;\nG91;\nG380 S3 Z-20 F1200;\nG90;\nG1 Y266 F2000;\nG1 Y43 F2000;\nG1 Y266 F2000;\nG1 Y250 F8000;\nG1 Y266 F8000;\nG1 Y43 F5000;\nG1 Y266 F2000;\nG1 Y250 F8000;\nG1 Y266 F8000;\nG1 Y-2 F7000;\nG1 Y150 F2000;	f	t	2026-11-15 06:09:31	2026-11-15 06:09:31
\.


--
-- Data for Name: maintenance_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_history (id, printer_maintenance_id, performed_at, hours_at_maintenance, notes, performed_by_user_id, performed_by_chat_id) FROM stdin;
\.


--
-- Data for Name: maintenance_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_types (id, name, description, default_interval_hours, interval_type, icon, wiki_url, printer_models, type_code, is_system, is_deleted, created_at) FROM stdin;
1	Clean Carbon Rods	Wipe carbon rods with a dry cloth	100	hours	Sparkles	\N	["X1C", "X1", "X1E", "P1P", "P1S"]	clean_carbon_rods	t	f	2026-11-15 06:09:30
2	Lubricate Steel Rods	Apply lubricant to steel rods for smooth motion	50	hours	Droplet	\N	["P2S", "X2D"]	lubricate_steel_rods	t	f	2026-11-15 06:09:30
3	Clean Steel Rods	Wipe steel rods with a dry cloth	100	hours	Sparkles	\N	["P2S", "X2D"]	clean_steel_rods	t	f	2026-11-15 06:09:30
4	Lubricate Linear Rails	Apply lubricant to linear rails for smooth motion	50	hours	Droplet	\N	["A1", "A1 Mini", "H2D", "H2D Pro", "H2C", "H2S"]	lubricate_linear_rails	t	f	2026-11-15 06:09:30
5	Clean Linear Rails	Wipe linear rails with a dry cloth to remove dust and debris	100	hours	Sparkles	\N	["A1", "A1 Mini", "H2D", "H2D Pro", "H2C", "H2S"]	clean_linear_rails	t	f	2026-11-15 06:09:30
6	Clean Nozzle/Hotend	Clean nozzle exterior and perform cold pull if needed	100	hours	Flame	\N	["*"]	clean_nozzle	t	f	2026-11-15 06:09:30
7	Check Belt Tension	Verify and adjust belt tension for X/Y axes	200	hours	Ruler	\N	["*"]	check_belt_tension	t	f	2026-11-15 06:09:30
8	Clean Build Plate	Deep clean build plate with IPA or soap	25	hours	Square	\N	["*"]	clean_build_plate	t	f	2026-11-15 06:09:30
9	Check PTFE Tube	Inspect PTFE tube for wear or discoloration	500	hours	Cable	\N	["*"]	check_ptfe_tube	t	f	2026-11-15 06:09:30
\.


--
-- Data for Name: notification_digest_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_digest_queue (id, provider_id, event_type, title, message, printer_id, printer_name, created_at) FROM stdin;
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_logs (id, provider_id, event_type, title, message, success, error_message, printer_id, printer_name, created_at) FROM stdin;
\.


--
-- Data for Name: notification_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_providers (id, name, provider_type, enabled, config, on_print_start, on_print_complete, on_print_failed, on_print_stopped, on_print_progress, on_print_missing_spool_assignment, on_printer_offline, on_printer_error, on_filament_low, on_maintenance_due, on_ams_humidity_high, on_ams_temperature_high, on_ams_ht_humidity_high, on_ams_ht_temperature_high, on_plate_not_empty, on_bed_cooled, on_first_layer_complete, on_queue_job_added, on_queue_job_started, on_queue_job_waiting, on_queue_job_skipped, on_queue_job_failed, on_queue_completed, quiet_hours_enabled, quiet_hours_start, quiet_hours_end, daily_digest_enabled, daily_digest_time, printer_id, last_success, last_error, last_error_at, created_at, updated_at, on_print_paused, on_print_resumed, on_stock_reorder_alert, on_stock_break_alert, on_printer_queue_completed) FROM stdin;
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_templates (id, event_type, name, title_template, body_template, is_default, created_at, updated_at) FROM stdin;
1	print_start	Print Started	Print Started	{printer}: {filename}\nEstimated: {estimated_time}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
2	print_complete	Print Completed	Print Completed	{printer}: {filename}\nTime: {duration}\nFilament: {filament_grams}g	t	2026-11-15 06:09:29	2026-11-15 06:09:29
3	print_failed	Print Failed	Print Failed	{printer}: {filename}\nTime: {duration}\nReason: {reason}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
4	print_stopped	Print Stopped	Print Stopped	{printer}: {filename}\nTime: {duration}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
5	print_progress	Print Progress	Print {progress}% Complete	{printer}: {filename}\nRemaining: {remaining_time}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
6	print_missing_spool_assignment	Missing Spool Assignment	Missing Spool Assignment	{printer}: print started with missing spool assignments\nSlots: {missing_slots}\nExpected profile:\n{missing_slot_details}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
7	printer_offline	Printer Offline	Printer Offline	{printer} has disconnected	t	2026-11-15 06:09:29	2026-11-15 06:09:29
8	printer_error	Printer Error	Printer Error: {error_type}	{printer}\n{error_detail}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
9	plate_not_empty	Plate Not Empty	Plate Not Empty - Print Paused	{printer}: Objects detected on build plate. Print has been paused. Clear plate and resume.	t	2026-11-15 06:09:29	2026-11-15 06:09:29
10	filament_low	Filament Low	Filament Low	{printer}: Slot {slot} at {remaining_percent}%	t	2026-11-15 06:09:29	2026-11-15 06:09:29
11	maintenance_due	Maintenance Due	Maintenance Due	{printer}:\n{items}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
12	ams_humidity_high	AMS Humidity High	AMS Humidity Alert	{printer} {ams_label}: Humidity {humidity}% exceeds {threshold}% threshold	t	2026-11-15 06:09:29	2026-11-15 06:09:29
13	ams_temperature_high	AMS Temperature High	AMS Temperature Alert	{printer} {ams_label}: Temperature {temperature}°C exceeds {threshold}°C threshold	t	2026-11-15 06:09:29	2026-11-15 06:09:29
14	bed_cooled	Bed Cooled	Bed Cooled	{printer}: Bed cooled to {bed_temp}°C (threshold: {threshold}°C)	t	2026-11-15 06:09:29	2026-11-15 06:09:29
15	first_layer_complete	First Layer Complete	First Layer Complete	{printer}: {filename}\nLayer 1/{total_layers} done	t	2026-11-15 06:09:29	2026-11-15 06:09:29
16	test	Test Notification	Bambuddy Test	This is a test notification. If you see this, notifications are working!	t	2026-11-15 06:09:29	2026-11-15 06:09:29
17	queue_job_added	Queue Job Added	Job Queued	{job_name} added to queue for {target}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
18	queue_job_started	Queue Job Started	Queue Job Started	{printer}: {job_name}\nEstimated: {estimated_time}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
19	queue_job_waiting	Queue Job Waiting	Queue Job Waiting	{job_name} waiting for {target_model}\n{waiting_reason}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
20	queue_job_skipped	Queue Job Skipped	Job Skipped	{printer}: {job_name}\nReason: {reason}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
21	queue_job_failed	Queue Job Failed	Job Failed to Start	{printer}: {job_name}\nReason: {reason}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
22	queue_completed	Queue Completed	Queue Complete	All {completed_count} queued jobs have finished	t	2026-11-15 06:09:29	2026-11-15 06:09:29
23	user_created	Welcome Email	Welcome to {app_name}	Welcome {username}!\n\nYour account has been created.\nUsername: {username}\nPassword: {password}\n\nLogin at: {login_url}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
24	password_reset	Password Reset	{app_name} - Password Reset	Hello {username},\n\nYour password has been reset.\nNew Password: {password}\n\nLogin at: {login_url}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
25	user_print_start	User Print Started	Your Print Has Started	Hello {username},\n\nYour print job has started on {printer}.\n\nFile: {filename}\n\nYou will be notified when it completes.	t	2026-11-15 06:09:29	2026-11-15 06:09:29
26	user_print_complete	User Print Completed	Your Print Is Complete	Hello {username},\n\nYour print job has completed on {printer}.\n\nFile: {filename}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
27	user_print_failed	User Print Failed	Your Print Has Failed	Hello {username},\n\nYour print job has failed on {printer}.\n\nFile: {filename}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
28	user_print_stopped	User Print Stopped	Your Print Has Been Stopped	Hello {username},\n\nYour print job was stopped on {printer}.\n\nFile: {filename}	t	2026-11-15 06:09:29	2026-11-15 06:09:29
29	print_paused	Print Paused	Print Paused	{printer}: {filename}\nReason: {reason}	t	2026-11-15 06:12:56.478036	2026-11-15 06:12:56.478036
30	print_resumed	Print Resumed	Print Resumed	{printer}: {filename}\nPaused for: {paused_for}	t	2026-11-15 06:12:56.478036	2026-11-15 06:12:56.478036
31	printer_queue_completed	Printer Queue Completed	Queue Complete	{printer}: queue finished — all jobs done	t	2026-11-15 06:12:57.977249	2026-11-15 06:12:57.977249
\.


--
-- Data for Name: oidc_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oidc_providers (id, name, issuer_url, client_id, client_secret, scopes, is_enabled, auto_create_users, auto_link_existing_accounts, email_claim, require_email_verified, icon_url, created_at, updated_at, default_group_id) FROM stdin;
\.


--
-- Data for Name: orca_base_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orca_base_profiles (id, name, profile_type, setting, fetched_at) FROM stdin;
\.


--
-- Data for Name: print_archives; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.print_archives (id, printer_id, project_id, library_file_id, queue_id, batch_id, error_message, filename, file_path, file_size, content_hash, source_content_hash, applied_patches, subtask_id, thumbnail_path, timelapse_path, source_3mf_path, f3d_path, print_name, print_time_seconds, filament_used_grams, filament_type, filament_color, layer_height, total_layers, nozzle_diameter, bed_temperature, nozzle_temperature, sliced_for_model, plate_index, status, started_at, completed_at, extra_data, makerworld_url, designer, external_url, is_favorite, tags, notes, cost, photos, failure_reason, quantity, energy_kwh, energy_cost, energy_start_kwh, swap_compatible, created_at, deleted_at, created_by_id, bed_type, is_calibration, calibration_session_id, from_auto_queue) FROM stdin;
\.


--
-- Data for Name: print_options_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.print_options_preferences (id, user_id, printer_model, options, updated_at) FROM stdin;
\.


--
-- Data for Name: print_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.print_queue (id, queue_id, waiting_reason, archive_id, library_file_id, project_id, "position", scheduled_time, manual_start, auto_off_after, ams_mapping, plate_id, bed_levelling, flow_cali, layer_inspect, timelapse, use_ams, mesh_mode_fast_check, status, execute_swap_macros, swap_macro_events, batch_id, started_at, completed_at, error_message, created_at, created_by_id, source_auto_item_id, gcode_injection, is_calibration, calibration_session_id) FROM stdin;
\.


--
-- Data for Name: printer_maintenance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_maintenance (id, printer_id, maintenance_type_id, custom_interval_hours, custom_interval_type, enabled, last_performed_at, last_performed_hours, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: printer_queues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_queues (id, printer_id, status, last_activity_at, current_item_id, pending_count, skipped_count, created_at, updated_at, auto_distribute_eligible, is_paused) FROM stdin;
\.


--
-- Data for Name: printer_setting_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_setting_audit (id, printer_id, user_id, tab, action, payload_json, sequence_id, result, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: printers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printers (id, name, serial_number, ip_address, access_code, model, location, nozzle_count, is_active, auto_archive, cleanup_after_print, mqtt_connection_timeout, print_hours_offset, runtime_seconds, last_runtime_update, external_camera_url, external_camera_type, external_camera_enabled, camera_rotation, plate_detection_enabled, plate_detection_roi_x, plate_detection_roi_y, plate_detection_roi_w, plate_detection_roi_h, stagger_interval_minutes, swap_mode_enabled, swap_profile, require_plate_clear, awaiting_plate_clear, created_at, updated_at, external_camera_snapshot_url) FROM stdin;
\.


--
-- Data for Name: project_bom_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_bom_items (id, project_id, name, quantity_needed, quantity_acquired, unit_price, sourcing_url, archive_id, stl_filename, remarks, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_print_plan_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_print_plan_items (id, project_id, library_file_id, copies, order_index, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, name, description, color, status, target_count, target_parts_count, notes, attachments, tags, due_date, priority, budget, is_template, template_source_id, parent_id, url, cover_image_filename, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, key, value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: slot_preset_mappings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.slot_preset_mappings (id, printer_id, ams_id, tray_id, preset_id, preset_name, preset_source, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: smart_plug_energy_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_plug_energy_snapshots (id, plug_id, recorded_at, lifetime_kwh) FROM stdin;
\.


--
-- Data for Name: smart_plugs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_plugs (id, name, ip_address, plug_type, ha_entity_id, ha_power_entity, ha_energy_today_entity, ha_energy_total_entity, mqtt_topic, mqtt_power_topic, mqtt_power_path, mqtt_power_multiplier, mqtt_energy_topic, mqtt_energy_path, mqtt_energy_multiplier, mqtt_state_topic, mqtt_state_path, mqtt_state_on_value, mqtt_multiplier, rest_on_url, rest_on_body, rest_off_url, rest_off_body, rest_method, rest_headers, rest_status_url, rest_status_path, rest_status_on_value, rest_power_url, rest_power_path, rest_power_multiplier, rest_energy_url, rest_energy_path, rest_energy_multiplier, printer_id, enabled, auto_on, auto_off, auto_off_persistent, off_delay_mode, off_delay_minutes, off_temp_threshold, username, password, power_alert_enabled, power_alert_high, power_alert_low, power_alert_last_triggered, schedule_enabled, schedule_on_time, schedule_off_time, show_in_switchbar, show_on_printer_card, last_state, last_checked, auto_off_executed, auto_off_pending, auto_off_pending_since, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: spool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spool (id, material, subtype, color_name, rgba, brand, label_weight, core_weight, core_weight_catalog_id, weight_used, weight_locked, last_scale_weight, last_weighed_at, slicer_filament, slicer_filament_name, nozzle_temp_min, nozzle_temp_max, note, added_full, cost_per_kg, last_used, encode_time, purchase_date, filament_diameter, lot, tag_uid, tray_uuid, data_origin, tag_type, archived_at, extra_colors, effect_type, category, low_stock_threshold_pct, created_at, updated_at, storage_location) FROM stdin;
\.


--
-- Data for Name: spool_assignment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spool_assignment (id, spool_id, printer_id, ams_id, tray_id, fingerprint_color, fingerprint_type, created_at) FROM stdin;
\.


--
-- Data for Name: spool_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spool_catalog (id, name, weight, is_default, created_at) FROM stdin;
1	3D FilaPrint - Cardboard	210	t	2026-11-15 06:09:30
2	3D FilaPrint - Plastic	238	t	2026-11-15 06:09:30
3	3D Fuel - Plastic	264	t	2026-11-15 06:09:30
4	3D Power - Plastic	220	t	2026-11-15 06:09:30
5	3D Solutech - Plastic	173	t	2026-11-15 06:09:30
6	3DE - Cardboard	136	t	2026-11-15 06:09:30
7	3DE - Plastic	181	t	2026-11-15 06:09:30
8	3DHOJOR - Cardboard	157	t	2026-11-15 06:09:30
9	3DJake - Cardboard	209	t	2026-11-15 06:09:30
10	3DJake - Plastic	232	t	2026-11-15 06:09:30
11	3DJake 250g - Plastic	91	t	2026-11-15 06:09:30
12	3DJake ecoPLA - Plastic	210	t	2026-11-15 06:09:30
13	3DXTech - Plastic	258	t	2026-11-15 06:09:30
14	Acccreate - Plastic	161	t	2026-11-15 06:09:30
15	Amazon Basics - Plastic	234	t	2026-11-15 06:09:30
16	Amolen - Plastic	150	t	2026-11-15 06:09:30
17	AMZ3D - Plastic	233	t	2026-11-15 06:09:30
18	Anycubic - Cardboard	125	t	2026-11-15 06:09:30
19	Anycubic - Plastic	127	t	2026-11-15 06:09:30
20	Atomic Filament - Plastic	272	t	2026-11-15 06:09:30
21	Aurapol - Plastic	220	t	2026-11-15 06:09:30
22	Azure Film - Plastic	163	t	2026-11-15 06:09:30
23	Bambu Lab - Plastic High Temp	216	t	2026-11-15 06:09:30
24	Bambu Lab - Plastic Low Temp	250	t	2026-11-15 06:09:30
25	Bambu Lab - Plastic White	253	t	2026-11-15 06:09:30
26	BQ - Plastic	218	t	2026-11-15 06:09:30
27	Colorfabb - Plastic	236	t	2026-11-15 06:09:30
28	Colorfabb 750g - Cardboard	152	t	2026-11-15 06:09:30
29	Colorfabb 750g - Plastic	254	t	2026-11-15 06:09:30
30	Comgrow - Cardboard	166	t	2026-11-15 06:09:30
31	Creality - Cardboard	180	t	2026-11-15 06:09:30
32	Creality - Plastic	135	t	2026-11-15 06:09:30
33	Das Filament - Plastic	211	t	2026-11-15 06:09:30
34	Devil Design - Plastic	256	t	2026-11-15 06:09:30
35	Duramic 3D - Cardboard	136	t	2026-11-15 06:09:30
36	Elegoo - Cardboard	153	t	2026-11-15 06:09:30
37	Elegoo - Plastic	111	t	2026-11-15 06:09:30
38	Eryone - Cardboard	156	t	2026-11-15 06:09:30
39	Eryone - Plastic	187	t	2026-11-15 06:09:30
40	eSUN - Cardboard	147	t	2026-11-15 06:09:30
41	eSUN - Plastic	240	t	2026-11-15 06:09:30
42	eSUN 2.5kg - Plastic	634	t	2026-11-15 06:09:30
43	Extrudr - Plastic	244	t	2026-11-15 06:09:30
44	Fiberlogy - Plastic	260	t	2026-11-15 06:09:30
45	Filament PM - Plastic	224	t	2026-11-15 06:09:30
46	Fillamentum - Plastic	230	t	2026-11-15 06:09:30
47	Flashforge - Plastic	167	t	2026-11-15 06:09:30
48	FormFutura - Cardboard	155	t	2026-11-15 06:09:30
49	FormFutura 750g - Plastic	212	t	2026-11-15 06:09:30
50	Geeetech - Plastic	178	t	2026-11-15 06:09:30
51	Gembird - Cardboard	143	t	2026-11-15 06:09:30
52	Hatchbox - Plastic	225	t	2026-11-15 06:09:30
53	Inland - Cardboard	142	t	2026-11-15 06:09:30
54	Inland - Plastic	210	t	2026-11-15 06:09:30
55	Jayo - Cardboard	120	t	2026-11-15 06:09:30
56	Jayo - Plastic	126	t	2026-11-15 06:09:30
57	Jayo 250g - Plastic	58	t	2026-11-15 06:09:30
58	Kingroon - Cardboard	155	t	2026-11-15 06:09:30
59	Kingroon - Plastic	156	t	2026-11-15 06:09:30
60	KVP - Plastic	263	t	2026-11-15 06:09:30
61	Matter Hackers - Plastic	215	t	2026-11-15 06:09:30
62	MG Chemicals - Cardboard	150	t	2026-11-15 06:09:30
63	MG Chemicals - Plastic	239	t	2026-11-15 06:09:30
64	Mika3D - Plastic	175	t	2026-11-15 06:09:30
65	MonoPrice - Plastic	221	t	2026-11-15 06:09:30
66	Overture - Cardboard	150	t	2026-11-15 06:09:30
67	Overture - Plastic	237	t	2026-11-15 06:09:30
68	PolyMaker - Cardboard	137	t	2026-11-15 06:09:30
69	PolyMaker - Plastic	220	t	2026-11-15 06:09:30
70	PolyMaker 3kg - Cardboard	418	t	2026-11-15 06:09:30
71	PolyTerra PLA - Cardboard	147	t	2026-11-15 06:09:30
72	PrimaSelect - Plastic	222	t	2026-11-15 06:09:30
73	ProtoPasta - Cardboard	80	t	2026-11-15 06:09:30
74	Prusament - Plastic	201	t	2026-11-15 06:09:30
75	Prusament - Plastic w/ Cardboard Core	196	t	2026-11-15 06:09:30
76	Rosa3D - Plastic	245	t	2026-11-15 06:09:30
77	Sakata3D - Plastic	205	t	2026-11-15 06:09:30
78	Snapmaker - Cardboard	148	t	2026-11-15 06:09:30
79	Sovol - Cardboard	145	t	2026-11-15 06:09:30
80	Spectrum - Cardboard	180	t	2026-11-15 06:09:30
81	Spectrum - Plastic	257	t	2026-11-15 06:09:30
82	Sunlu - Plastic	117	t	2026-11-15 06:09:30
83	Sunlu - Plastic V2	165	t	2026-11-15 06:09:30
84	Sunlu - Plastic V3	179	t	2026-11-15 06:09:30
85	Sunlu 250g - Plastic	55	t	2026-11-15 06:09:30
86	UltiMaker - Plastic	235	t	2026-11-15 06:09:30
87	Voolt3D - Plastic	190	t	2026-11-15 06:09:30
88	Voxelab - Plastic	171	t	2026-11-15 06:09:30
89	Wanhao - Plastic	267	t	2026-11-15 06:09:30
90	Ziro - Plastic	166	t	2026-11-15 06:09:30
91	ZYLtech - Plastic	179	t	2026-11-15 06:09:30
\.


--
-- Data for Name: spool_k_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spool_k_profile (id, spool_id, printer_id, extruder, created_at, filament_calibration_id) FROM stdin;
\.


--
-- Data for Name: spool_usage_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spool_usage_history (id, spool_id, printer_id, print_name, archive_id, weight_used, percent_used, status, cost, created_at) FROM stdin;
\.


--
-- Data for Name: spoolman_k_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spoolman_k_profile (id, spoolman_spool_id, printer_id, extruder, created_at, filament_calibration_id) FROM stdin;
\.


--
-- Data for Name: spoolman_slot_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spoolman_slot_assignments (id, printer_id, ams_id, tray_id, spoolman_spool_id, assigned_at) FROM stdin;
\.


--
-- Data for Name: telegram_chats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.telegram_chats (id, chat_id, label, group_id, user_id, is_active, notify_events, daily_digest, quiet_hours_enabled, quiet_hours_start, quiet_hours_end, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_email_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_email_preferences (id, user_id, notify_print_start, notify_print_complete, notify_print_failed, notify_print_stopped, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_groups (user_id, group_id) FROM stdin;
\.


--
-- Data for Name: user_oidc_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_oidc_links (id, user_id, provider_id, provider_user_id, provider_email, created_at) FROM stdin;
\.


--
-- Data for Name: user_otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_otp_codes (id, user_id, code_hash, attempts, used, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_totp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_totp (id, user_id, secret, is_enabled, backup_codes_json, last_totp_counter, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, role, auth_source, is_active, password_changed_at, created_at, updated_at, cloud_token, cloud_email, cloud_region) FROM stdin;
\.


--
-- Data for Name: virtual_printers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.virtual_printers (id, name, enabled, mode, auto_dispatch, model, access_code, target_printer_id, target_folder_id, bind_ip, remote_interface_ip, serial_suffix, tailscale_disabled, "position", created_at, updated_at, queue_force_color_match) FROM stdin;
\.


--
-- Name: _migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public._migrations_id_seq', 71, true);


--
-- Name: active_print_spoolman_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.active_print_spoolman_id_seq', 1, false);


--
-- Name: ams_labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ams_labels_id_seq', 1, false);


--
-- Name: ams_sensor_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ams_sensor_history_id_seq', 1, false);


--
-- Name: ams_setting_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ams_setting_audit_id_seq', 1, false);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 1, false);


--
-- Name: auth_ephemeral_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_ephemeral_tokens_id_seq', 1, false);


--
-- Name: auth_rate_limit_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_rate_limit_events_id_seq', 1, false);


--
-- Name: auto_queue_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auto_queue_items_id_seq', 1, false);


--
-- Name: bug_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bug_reports_id_seq', 1, false);


--
-- Name: calibration_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.calibration_audit_id_seq', 1, false);


--
-- Name: calibration_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.calibration_session_id_seq', 1, false);


--
-- Name: color_catalog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.color_catalog_id_seq', 638, true);


--
-- Name: external_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.external_links_id_seq', 1, false);


--
-- Name: filament_calibration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filament_calibration_id_seq', 1, false);


--
-- Name: filament_shopping_list_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filament_shopping_list_id_seq', 1, false);


--
-- Name: filament_sku_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filament_sku_settings_id_seq', 1, false);


--
-- Name: git_backup_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.git_backup_config_id_seq', 1, false);


--
-- Name: git_backup_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.git_backup_logs_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.groups_id_seq', 3, true);


--
-- Name: kprofile_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kprofile_notes_id_seq', 1, false);


--
-- Name: library_file_makerworld_meta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_file_makerworld_meta_id_seq', 1, false);


--
-- Name: library_file_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_file_notes_id_seq', 1, false);


--
-- Name: library_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_files_id_seq', 1, false);


--
-- Name: library_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_folders_id_seq', 1, false);


--
-- Name: local_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.local_presets_id_seq', 1, false);


--
-- Name: long_lived_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.long_lived_tokens_id_seq', 1, false);


--
-- Name: macros_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.macros_id_seq', 6, true);


--
-- Name: maintenance_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenance_history_id_seq', 1, false);


--
-- Name: maintenance_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenance_types_id_seq', 9, true);


--
-- Name: notification_digest_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_digest_queue_id_seq', 1, false);


--
-- Name: notification_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_logs_id_seq', 1, false);


--
-- Name: notification_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_providers_id_seq', 1, false);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_templates_id_seq', 31, true);


--
-- Name: oidc_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oidc_providers_id_seq', 1, false);


--
-- Name: orca_base_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orca_base_profiles_id_seq', 1, false);


--
-- Name: print_archives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.print_archives_id_seq', 1, false);


--
-- Name: print_options_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.print_options_preferences_id_seq', 1, false);


--
-- Name: print_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.print_queue_id_seq', 1, false);


--
-- Name: printer_maintenance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printer_maintenance_id_seq', 1, false);


--
-- Name: printer_queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printer_queues_id_seq', 1, false);


--
-- Name: printer_setting_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printer_setting_audit_id_seq', 1, false);


--
-- Name: printers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printers_id_seq', 1, false);


--
-- Name: project_bom_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_bom_items_id_seq', 1, false);


--
-- Name: project_print_plan_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_print_plan_items_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, false);


--
-- Name: slot_preset_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.slot_preset_mappings_id_seq', 1, false);


--
-- Name: smart_plug_energy_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_plug_energy_snapshots_id_seq', 1, false);


--
-- Name: smart_plugs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_plugs_id_seq', 1, false);


--
-- Name: spool_assignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spool_assignment_id_seq', 1, false);


--
-- Name: spool_catalog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spool_catalog_id_seq', 91, true);


--
-- Name: spool_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spool_id_seq', 1, false);


--
-- Name: spool_k_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spool_k_profile_id_seq', 1, false);


--
-- Name: spool_usage_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spool_usage_history_id_seq', 1, false);


--
-- Name: spoolman_k_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spoolman_k_profile_id_seq', 1, false);


--
-- Name: spoolman_slot_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spoolman_slot_assignments_id_seq', 1, false);


--
-- Name: telegram_chats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.telegram_chats_id_seq', 1, false);


--
-- Name: user_email_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_email_preferences_id_seq', 1, false);


--
-- Name: user_oidc_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_oidc_links_id_seq', 1, false);


--
-- Name: user_otp_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_otp_codes_id_seq', 1, false);


--
-- Name: user_totp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_totp_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: virtual_printers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.virtual_printers_id_seq', 1, false);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (id);


--
-- Name: _migrations _migrations_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_version_key UNIQUE (version);


--
-- Name: active_print_spoolman active_print_spoolman_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_print_spoolman
    ADD CONSTRAINT active_print_spoolman_pkey PRIMARY KEY (id);


--
-- Name: ams_labels ams_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_labels
    ADD CONSTRAINT ams_labels_pkey PRIMARY KEY (id);


--
-- Name: ams_sensor_history ams_sensor_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_sensor_history
    ADD CONSTRAINT ams_sensor_history_pkey PRIMARY KEY (id);


--
-- Name: ams_setting_audit ams_setting_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_setting_audit
    ADD CONSTRAINT ams_setting_audit_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: auth_ephemeral_tokens auth_ephemeral_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_ephemeral_tokens
    ADD CONSTRAINT auth_ephemeral_tokens_pkey PRIMARY KEY (id);


--
-- Name: auth_rate_limit_events auth_rate_limit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_rate_limit_events
    ADD CONSTRAINT auth_rate_limit_events_pkey PRIMARY KEY (id);


--
-- Name: auto_queue_items auto_queue_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_pkey PRIMARY KEY (id);


--
-- Name: bug_reports bug_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bug_reports
    ADD CONSTRAINT bug_reports_pkey PRIMARY KEY (id);


--
-- Name: calibration_audit calibration_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit
    ADD CONSTRAINT calibration_audit_pkey PRIMARY KEY (id);


--
-- Name: calibration_session calibration_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session
    ADD CONSTRAINT calibration_session_pkey PRIMARY KEY (id);


--
-- Name: color_catalog color_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.color_catalog
    ADD CONSTRAINT color_catalog_pkey PRIMARY KEY (id);


--
-- Name: external_links external_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_links
    ADD CONSTRAINT external_links_pkey PRIMARY KEY (id);


--
-- Name: filament_calibration filament_calibration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_calibration
    ADD CONSTRAINT filament_calibration_pkey PRIMARY KEY (id);


--
-- Name: filament_shopping_list filament_shopping_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_shopping_list
    ADD CONSTRAINT filament_shopping_list_pkey PRIMARY KEY (id);


--
-- Name: filament_sku_settings filament_sku_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_sku_settings
    ADD CONSTRAINT filament_sku_settings_pkey PRIMARY KEY (id);


--
-- Name: git_backup_config git_backup_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_backup_config
    ADD CONSTRAINT git_backup_config_pkey PRIMARY KEY (id);


--
-- Name: git_backup_logs git_backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_backup_logs
    ADD CONSTRAINT git_backup_logs_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: kprofile_notes kprofile_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kprofile_notes
    ADD CONSTRAINT kprofile_notes_pkey PRIMARY KEY (id);


--
-- Name: library_file_makerworld_meta library_file_makerworld_meta_library_file_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_makerworld_meta
    ADD CONSTRAINT library_file_makerworld_meta_library_file_id_key UNIQUE (library_file_id);


--
-- Name: library_file_makerworld_meta library_file_makerworld_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_makerworld_meta
    ADD CONSTRAINT library_file_makerworld_meta_pkey PRIMARY KEY (id);


--
-- Name: library_file_notes library_file_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_notes
    ADD CONSTRAINT library_file_notes_pkey PRIMARY KEY (id);


--
-- Name: library_file_projects library_file_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_projects
    ADD CONSTRAINT library_file_projects_pkey PRIMARY KEY (file_id, project_id);


--
-- Name: library_files library_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_files
    ADD CONSTRAINT library_files_pkey PRIMARY KEY (id);


--
-- Name: library_folder_projects library_folder_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folder_projects
    ADD CONSTRAINT library_folder_projects_pkey PRIMARY KEY (folder_id, project_id);


--
-- Name: library_folders library_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folders
    ADD CONSTRAINT library_folders_pkey PRIMARY KEY (id);


--
-- Name: local_presets local_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_presets
    ADD CONSTRAINT local_presets_pkey PRIMARY KEY (id);


--
-- Name: long_lived_tokens long_lived_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.long_lived_tokens
    ADD CONSTRAINT long_lived_tokens_pkey PRIMARY KEY (id);


--
-- Name: macros macros_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.macros
    ADD CONSTRAINT macros_pkey PRIMARY KEY (id);


--
-- Name: maintenance_history maintenance_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_pkey PRIMARY KEY (id);


--
-- Name: maintenance_types maintenance_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_types
    ADD CONSTRAINT maintenance_types_pkey PRIMARY KEY (id);


--
-- Name: notification_digest_queue notification_digest_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_digest_queue
    ADD CONSTRAINT notification_digest_queue_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_providers notification_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_providers
    ADD CONSTRAINT notification_providers_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_event_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_event_type_key UNIQUE (event_type);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: oidc_providers oidc_providers_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_name_key UNIQUE (name);


--
-- Name: oidc_providers oidc_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_pkey PRIMARY KEY (id);


--
-- Name: orca_base_profiles orca_base_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orca_base_profiles
    ADD CONSTRAINT orca_base_profiles_pkey PRIMARY KEY (id);


--
-- Name: print_archives print_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_pkey PRIMARY KEY (id);


--
-- Name: print_options_preferences print_options_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_options_preferences
    ADD CONSTRAINT print_options_preferences_pkey PRIMARY KEY (id);


--
-- Name: print_queue print_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_pkey PRIMARY KEY (id);


--
-- Name: printer_maintenance printer_maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_maintenance
    ADD CONSTRAINT printer_maintenance_pkey PRIMARY KEY (id);


--
-- Name: printer_queues printer_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_queues
    ADD CONSTRAINT printer_queues_pkey PRIMARY KEY (id);


--
-- Name: printer_queues printer_queues_printer_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_queues
    ADD CONSTRAINT printer_queues_printer_id_key UNIQUE (printer_id);


--
-- Name: printer_setting_audit printer_setting_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_setting_audit
    ADD CONSTRAINT printer_setting_audit_pkey PRIMARY KEY (id);


--
-- Name: printers printers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printers
    ADD CONSTRAINT printers_pkey PRIMARY KEY (id);


--
-- Name: project_bom_items project_bom_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_bom_items
    ADD CONSTRAINT project_bom_items_pkey PRIMARY KEY (id);


--
-- Name: project_print_plan_items project_print_plan_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_print_plan_items
    ADD CONSTRAINT project_print_plan_items_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: slot_preset_mappings slot_preset_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slot_preset_mappings
    ADD CONSTRAINT slot_preset_mappings_pkey PRIMARY KEY (id);


--
-- Name: smart_plug_energy_snapshots smart_plug_energy_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_energy_snapshots
    ADD CONSTRAINT smart_plug_energy_snapshots_pkey PRIMARY KEY (id);


--
-- Name: smart_plugs smart_plugs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plugs
    ADD CONSTRAINT smart_plugs_pkey PRIMARY KEY (id);


--
-- Name: spool_assignment spool_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_assignment
    ADD CONSTRAINT spool_assignment_pkey PRIMARY KEY (id);


--
-- Name: spool_assignment spool_assignment_printer_id_ams_id_tray_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_assignment
    ADD CONSTRAINT spool_assignment_printer_id_ams_id_tray_id_key UNIQUE (printer_id, ams_id, tray_id);


--
-- Name: spool_catalog spool_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_catalog
    ADD CONSTRAINT spool_catalog_pkey PRIMARY KEY (id);


--
-- Name: spool_k_profile spool_k_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_k_profile
    ADD CONSTRAINT spool_k_profile_pkey PRIMARY KEY (id);


--
-- Name: spool spool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool
    ADD CONSTRAINT spool_pkey PRIMARY KEY (id);


--
-- Name: spool_usage_history spool_usage_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_usage_history
    ADD CONSTRAINT spool_usage_history_pkey PRIMARY KEY (id);


--
-- Name: spoolman_k_profile spoolman_k_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_k_profile
    ADD CONSTRAINT spoolman_k_profile_pkey PRIMARY KEY (id);


--
-- Name: spoolman_slot_assignments spoolman_slot_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_slot_assignments
    ADD CONSTRAINT spoolman_slot_assignments_pkey PRIMARY KEY (id);


--
-- Name: telegram_chats telegram_chats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_pkey PRIMARY KEY (id);


--
-- Name: ams_labels uq_ams_label_serial; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_labels
    ADD CONSTRAINT uq_ams_label_serial UNIQUE (ams_serial_number);


--
-- Name: filament_sku_settings uq_filament_sku; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_sku_settings
    ADD CONSTRAINT uq_filament_sku UNIQUE (material, subtype, brand);


--
-- Name: user_oidc_links uq_oidc_link_provider_sub; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT uq_oidc_link_provider_sub UNIQUE (provider_id, provider_user_id);


--
-- Name: user_oidc_links uq_oidc_link_user_provider; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT uq_oidc_link_user_provider UNIQUE (user_id, provider_id);


--
-- Name: project_print_plan_items uq_plan_project_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_print_plan_items
    ADD CONSTRAINT uq_plan_project_file UNIQUE (project_id, library_file_id);


--
-- Name: print_options_preferences uq_print_options_pref_user_model; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_options_preferences
    ADD CONSTRAINT uq_print_options_pref_user_model UNIQUE (user_id, printer_model);


--
-- Name: active_print_spoolman uq_printer_archive; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_print_spoolman
    ADD CONSTRAINT uq_printer_archive UNIQUE (printer_id, archive_id);


--
-- Name: slot_preset_mappings uq_slot_preset; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slot_preset_mappings
    ADD CONSTRAINT uq_slot_preset UNIQUE (printer_id, ams_id, tray_id);


--
-- Name: spoolman_k_profile uq_spoolman_kp; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_k_profile
    ADD CONSTRAINT uq_spoolman_kp UNIQUE (spoolman_spool_id, printer_id, extruder, filament_calibration_id);


--
-- Name: spoolman_slot_assignments uq_spoolman_slot_assignment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_slot_assignments
    ADD CONSTRAINT uq_spoolman_slot_assignment UNIQUE (printer_id, ams_id, tray_id);


--
-- Name: user_email_preferences user_email_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_email_preferences
    ADD CONSTRAINT user_email_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_groups user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_pkey PRIMARY KEY (user_id, group_id);


--
-- Name: user_oidc_links user_oidc_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT user_oidc_links_pkey PRIMARY KEY (id);


--
-- Name: user_otp_codes user_otp_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_otp_codes
    ADD CONSTRAINT user_otp_codes_pkey PRIMARY KEY (id);


--
-- Name: user_totp user_totp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_totp
    ADD CONSTRAINT user_totp_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: virtual_printers virtual_printers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtual_printers
    ADD CONSTRAINT virtual_printers_pkey PRIMARY KEY (id);


--
-- Name: ix_ams_history_printer_ams_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ams_history_printer_ams_time ON public.ams_sensor_history USING btree (printer_id, ams_id, recorded_at);


--
-- Name: ix_ams_sensor_history_recorded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ams_sensor_history_recorded_at ON public.ams_sensor_history USING btree (recorded_at);


--
-- Name: ix_ams_setting_audit_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ams_setting_audit_printer ON public.ams_setting_audit USING btree (printer_id, created_at DESC);


--
-- Name: ix_api_keys_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_api_keys_user_id ON public.api_keys USING btree (user_id);


--
-- Name: ix_auth_eph_type_exp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_eph_type_exp ON public.auth_ephemeral_tokens USING btree (token_type, expires_at);


--
-- Name: ix_auth_ephemeral_tokens_family_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_ephemeral_tokens_family_id ON public.auth_ephemeral_tokens USING btree (family_id);


--
-- Name: ix_auth_ephemeral_tokens_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_auth_ephemeral_tokens_token ON public.auth_ephemeral_tokens USING btree (token);


--
-- Name: ix_auth_rate_limit_events_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_rate_limit_events_username ON public.auth_rate_limit_events USING btree (username);


--
-- Name: ix_auth_rl_type_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_rl_type_time ON public.auth_rate_limit_events USING btree (event_type, occurred_at);


--
-- Name: ix_auto_queue_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auto_queue_batch_id ON public.auto_queue_items USING btree (batch_id);


--
-- Name: ix_auto_queue_items_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auto_queue_items_batch_id ON public.auto_queue_items USING btree (batch_id);


--
-- Name: ix_auto_queue_status_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auto_queue_status_position ON public.auto_queue_items USING btree (status, "position");


--
-- Name: ix_calibration_audit_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calibration_audit_printer ON public.calibration_audit USING btree (printer_id, created_at DESC);


--
-- Name: ix_calibration_session_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calibration_session_printer ON public.calibration_session USING btree (printer_id, status, created_at DESC);


--
-- Name: ix_filament_cali_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_filament_cali_lookup ON public.filament_calibration USING btree (printer_id, filament_id, nozzle_diameter, nozzle_volume_type, extruder_id);


--
-- Name: ix_groups_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_groups_name ON public.groups USING btree (name);


--
-- Name: ix_lfop_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lfop_project_id ON public.library_folder_projects USING btree (project_id);


--
-- Name: ix_lfp_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lfp_project_id ON public.library_file_projects USING btree (project_id);


--
-- Name: ix_library_file_makerworld_meta_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_file_makerworld_meta_profile_id ON public.library_file_makerworld_meta USING btree (profile_id);


--
-- Name: ix_library_file_notes_file; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_file_notes_file ON public.library_file_notes USING btree (library_file_id);


--
-- Name: ix_library_files_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_files_deleted_at ON public.library_files USING btree (deleted_at);


--
-- Name: ix_library_files_source_url; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_files_source_url ON public.library_files USING btree (source_url);


--
-- Name: ix_long_lived_tokens_lookup_prefix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_long_lived_tokens_lookup_prefix ON public.long_lived_tokens USING btree (lookup_prefix);


--
-- Name: ix_long_lived_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_long_lived_tokens_user_id ON public.long_lived_tokens USING btree (user_id);


--
-- Name: ix_maintenance_types_type_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_maintenance_types_type_code ON public.maintenance_types USING btree (type_code);


--
-- Name: ix_notification_digest_queue_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_digest_queue_created_at ON public.notification_digest_queue USING btree (created_at);


--
-- Name: ix_notification_digest_queue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_digest_queue_id ON public.notification_digest_queue USING btree (id);


--
-- Name: ix_notification_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_logs_created_at ON public.notification_logs USING btree (created_at);


--
-- Name: ix_notification_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_logs_id ON public.notification_logs USING btree (id);


--
-- Name: ix_notification_providers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_providers_id ON public.notification_providers USING btree (id);


--
-- Name: ix_notification_templates_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_templates_id ON public.notification_templates USING btree (id);


--
-- Name: ix_oidc_providers_default_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_oidc_providers_default_group_id ON public.oidc_providers USING btree (default_group_id);


--
-- Name: ix_orca_base_profiles_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_orca_base_profiles_name ON public.orca_base_profiles USING btree (name);


--
-- Name: ix_plug_energy_snapshots_plug_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plug_energy_snapshots_plug_time ON public.smart_plug_energy_snapshots USING btree (plug_id, recorded_at);


--
-- Name: ix_print_archives_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_batch_id ON public.print_archives USING btree (batch_id);


--
-- Name: ix_print_archives_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_deleted_at ON public.print_archives USING btree (deleted_at);


--
-- Name: ix_print_archives_library_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_library_file_id ON public.print_archives USING btree (library_file_id);


--
-- Name: ix_print_archives_plate_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_plate_index ON public.print_archives USING btree (plate_index);


--
-- Name: ix_print_archives_queue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_queue_id ON public.print_archives USING btree (queue_id);


--
-- Name: ix_print_archives_subtask_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_subtask_id ON public.print_archives USING btree (subtask_id);


--
-- Name: ix_print_options_preferences_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_options_preferences_user_id ON public.print_options_preferences USING btree (user_id);


--
-- Name: ix_print_queue_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_queue_batch_id ON public.print_queue USING btree (batch_id);


--
-- Name: ix_printer_setting_audit_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_printer_setting_audit_printer ON public.printer_setting_audit USING btree (printer_id, created_at DESC);


--
-- Name: ix_project_print_plan_items_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_print_plan_items_project_id ON public.project_print_plan_items USING btree (project_id);


--
-- Name: ix_settings_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_settings_key ON public.settings USING btree (key);


--
-- Name: ix_telegram_chats_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_telegram_chats_chat_id ON public.telegram_chats USING btree (chat_id);


--
-- Name: ix_user_email_preferences_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_email_preferences_id ON public.user_email_preferences USING btree (id);


--
-- Name: ix_user_email_preferences_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_user_email_preferences_user_id ON public.user_email_preferences USING btree (user_id);


--
-- Name: ix_user_oidc_links_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_oidc_links_provider_id ON public.user_oidc_links USING btree (provider_id);


--
-- Name: ix_user_oidc_links_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_oidc_links_user_id ON public.user_oidc_links USING btree (user_id);


--
-- Name: ix_user_otp_codes_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_otp_codes_user_id ON public.user_otp_codes USING btree (user_id);


--
-- Name: ix_user_totp_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_user_totp_user_id ON public.user_totp USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: uq_kprofile_notes_fc; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_kprofile_notes_fc ON public.kprofile_notes USING btree (filament_calibration_id);


--
-- Name: ux_filament_cali_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_filament_cali_active ON public.filament_calibration USING btree (printer_id, filament_id, nozzle_diameter, nozzle_volume_type, extruder_id) WHERE (is_active = true);


--
-- Name: active_print_spoolman active_print_spoolman_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_print_spoolman
    ADD CONSTRAINT active_print_spoolman_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE CASCADE;


--
-- Name: active_print_spoolman active_print_spoolman_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_print_spoolman
    ADD CONSTRAINT active_print_spoolman_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: ams_sensor_history ams_sensor_history_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_sensor_history
    ADD CONSTRAINT ams_sensor_history_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: ams_setting_audit ams_setting_audit_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_setting_audit
    ADD CONSTRAINT ams_setting_audit_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: ams_setting_audit ams_setting_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_setting_audit
    ADD CONSTRAINT ams_setting_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auto_queue_items auto_queue_items_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE CASCADE;


--
-- Name: auto_queue_items auto_queue_items_assigned_to_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_assigned_to_item_id_fkey FOREIGN KEY (assigned_to_item_id) REFERENCES public.print_queue(id) ON DELETE SET NULL;


--
-- Name: auto_queue_items auto_queue_items_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: auto_queue_items auto_queue_items_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE SET NULL;


--
-- Name: auto_queue_items auto_queue_items_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: calibration_audit calibration_audit_filament_calibration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit
    ADD CONSTRAINT calibration_audit_filament_calibration_id_fkey FOREIGN KEY (filament_calibration_id) REFERENCES public.filament_calibration(id) ON DELETE SET NULL;


--
-- Name: calibration_audit calibration_audit_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit
    ADD CONSTRAINT calibration_audit_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: calibration_audit calibration_audit_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit
    ADD CONSTRAINT calibration_audit_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.calibration_session(id) ON DELETE SET NULL;


--
-- Name: calibration_audit calibration_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit
    ADD CONSTRAINT calibration_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: calibration_session calibration_session_parent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session
    ADD CONSTRAINT calibration_session_parent_session_id_fkey FOREIGN KEY (parent_session_id) REFERENCES public.calibration_session(id) ON DELETE SET NULL;


--
-- Name: calibration_session calibration_session_print_queue_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session
    ADD CONSTRAINT calibration_session_print_queue_item_id_fkey FOREIGN KEY (print_queue_item_id) REFERENCES public.print_queue(id) ON DELETE SET NULL;


--
-- Name: calibration_session calibration_session_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session
    ADD CONSTRAINT calibration_session_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: calibration_session calibration_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session
    ADD CONSTRAINT calibration_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: filament_calibration filament_calibration_calibrated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_calibration
    ADD CONSTRAINT filament_calibration_calibrated_by_user_id_fkey FOREIGN KEY (calibrated_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: filament_calibration filament_calibration_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_calibration
    ADD CONSTRAINT filament_calibration_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: git_backup_logs git_backup_logs_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_backup_logs
    ADD CONSTRAINT git_backup_logs_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.git_backup_config(id) ON DELETE CASCADE;


--
-- Name: kprofile_notes kprofile_notes_filament_calibration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kprofile_notes
    ADD CONSTRAINT kprofile_notes_filament_calibration_id_fkey FOREIGN KEY (filament_calibration_id) REFERENCES public.filament_calibration(id) ON DELETE CASCADE;


--
-- Name: library_file_makerworld_meta library_file_makerworld_meta_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_makerworld_meta
    ADD CONSTRAINT library_file_makerworld_meta_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE CASCADE;


--
-- Name: library_file_notes library_file_notes_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_notes
    ADD CONSTRAINT library_file_notes_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE CASCADE;


--
-- Name: library_file_notes library_file_notes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_notes
    ADD CONSTRAINT library_file_notes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: library_file_projects library_file_projects_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_projects
    ADD CONSTRAINT library_file_projects_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.library_files(id) ON DELETE CASCADE;


--
-- Name: library_file_projects library_file_projects_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_projects
    ADD CONSTRAINT library_file_projects_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: library_files library_files_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_files
    ADD CONSTRAINT library_files_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: library_files library_files_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_files
    ADD CONSTRAINT library_files_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.library_folders(id);


--
-- Name: library_folder_projects library_folder_projects_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folder_projects
    ADD CONSTRAINT library_folder_projects_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.library_folders(id) ON DELETE CASCADE;


--
-- Name: library_folder_projects library_folder_projects_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folder_projects
    ADD CONSTRAINT library_folder_projects_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: library_folders library_folders_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folders
    ADD CONSTRAINT library_folders_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE SET NULL;


--
-- Name: library_folders library_folders_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folders
    ADD CONSTRAINT library_folders_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.library_folders(id) ON DELETE CASCADE;


--
-- Name: long_lived_tokens long_lived_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.long_lived_tokens
    ADD CONSTRAINT long_lived_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maintenance_history maintenance_history_performed_by_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_performed_by_chat_id_fkey FOREIGN KEY (performed_by_chat_id) REFERENCES public.telegram_chats(id) ON DELETE SET NULL;


--
-- Name: maintenance_history maintenance_history_performed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_performed_by_user_id_fkey FOREIGN KEY (performed_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: maintenance_history maintenance_history_printer_maintenance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_printer_maintenance_id_fkey FOREIGN KEY (printer_maintenance_id) REFERENCES public.printer_maintenance(id) ON DELETE CASCADE;


--
-- Name: notification_digest_queue notification_digest_queue_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_digest_queue
    ADD CONSTRAINT notification_digest_queue_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- Name: notification_digest_queue notification_digest_queue_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_digest_queue
    ADD CONSTRAINT notification_digest_queue_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.notification_providers(id) ON DELETE CASCADE;


--
-- Name: notification_logs notification_logs_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- Name: notification_logs notification_logs_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.notification_providers(id) ON DELETE CASCADE;


--
-- Name: notification_providers notification_providers_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_providers
    ADD CONSTRAINT notification_providers_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- Name: oidc_providers oidc_providers_default_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_default_group_id_fkey FOREIGN KEY (default_group_id) REFERENCES public.groups(id) ON DELETE SET NULL;


--
-- Name: print_archives print_archives_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: print_archives print_archives_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE SET NULL;


--
-- Name: print_archives print_archives_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id);


--
-- Name: print_archives print_archives_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: print_archives print_archives_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.printer_queues(id) ON DELETE SET NULL;


--
-- Name: print_options_preferences print_options_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_options_preferences
    ADD CONSTRAINT print_options_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: print_queue print_queue_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id);


--
-- Name: print_queue print_queue_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: print_queue print_queue_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id);


--
-- Name: print_queue print_queue_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: print_queue print_queue_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.printer_queues(id);


--
-- Name: print_queue print_queue_source_auto_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_source_auto_item_id_fkey FOREIGN KEY (source_auto_item_id) REFERENCES public.auto_queue_items(id);


--
-- Name: printer_maintenance printer_maintenance_maintenance_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_maintenance
    ADD CONSTRAINT printer_maintenance_maintenance_type_id_fkey FOREIGN KEY (maintenance_type_id) REFERENCES public.maintenance_types(id) ON DELETE CASCADE;


--
-- Name: printer_maintenance printer_maintenance_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_maintenance
    ADD CONSTRAINT printer_maintenance_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: printer_queues printer_queues_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_queues
    ADD CONSTRAINT printer_queues_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id);


--
-- Name: printer_setting_audit printer_setting_audit_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_setting_audit
    ADD CONSTRAINT printer_setting_audit_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: printer_setting_audit printer_setting_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_setting_audit
    ADD CONSTRAINT printer_setting_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: project_bom_items project_bom_items_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_bom_items
    ADD CONSTRAINT project_bom_items_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE SET NULL;


--
-- Name: project_bom_items project_bom_items_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_bom_items
    ADD CONSTRAINT project_bom_items_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_print_plan_items project_print_plan_items_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_print_plan_items
    ADD CONSTRAINT project_print_plan_items_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE CASCADE;


--
-- Name: project_print_plan_items project_print_plan_items_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_print_plan_items
    ADD CONSTRAINT project_print_plan_items_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: projects projects_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.projects(id);


--
-- Name: slot_preset_mappings slot_preset_mappings_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slot_preset_mappings
    ADD CONSTRAINT slot_preset_mappings_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: smart_plug_energy_snapshots smart_plug_energy_snapshots_plug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_energy_snapshots
    ADD CONSTRAINT smart_plug_energy_snapshots_plug_id_fkey FOREIGN KEY (plug_id) REFERENCES public.smart_plugs(id) ON DELETE CASCADE;


--
-- Name: smart_plugs smart_plugs_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plugs
    ADD CONSTRAINT smart_plugs_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- Name: spool_assignment spool_assignment_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_assignment
    ADD CONSTRAINT spool_assignment_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: spool_assignment spool_assignment_spool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_assignment
    ADD CONSTRAINT spool_assignment_spool_id_fkey FOREIGN KEY (spool_id) REFERENCES public.spool(id) ON DELETE CASCADE;


--
-- Name: spool_k_profile spool_k_profile_filament_calibration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_k_profile
    ADD CONSTRAINT spool_k_profile_filament_calibration_id_fkey FOREIGN KEY (filament_calibration_id) REFERENCES public.filament_calibration(id) ON DELETE CASCADE;


--
-- Name: spool_k_profile spool_k_profile_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_k_profile
    ADD CONSTRAINT spool_k_profile_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: spool_k_profile spool_k_profile_spool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_k_profile
    ADD CONSTRAINT spool_k_profile_spool_id_fkey FOREIGN KEY (spool_id) REFERENCES public.spool(id) ON DELETE CASCADE;


--
-- Name: spool_usage_history spool_usage_history_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_usage_history
    ADD CONSTRAINT spool_usage_history_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id);


--
-- Name: spool_usage_history spool_usage_history_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_usage_history
    ADD CONSTRAINT spool_usage_history_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- Name: spool_usage_history spool_usage_history_spool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_usage_history
    ADD CONSTRAINT spool_usage_history_spool_id_fkey FOREIGN KEY (spool_id) REFERENCES public.spool(id) ON DELETE CASCADE;


--
-- Name: spoolman_k_profile spoolman_k_profile_filament_calibration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_k_profile
    ADD CONSTRAINT spoolman_k_profile_filament_calibration_id_fkey FOREIGN KEY (filament_calibration_id) REFERENCES public.filament_calibration(id) ON DELETE CASCADE;


--
-- Name: spoolman_k_profile spoolman_k_profile_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_k_profile
    ADD CONSTRAINT spoolman_k_profile_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: spoolman_slot_assignments spoolman_slot_assignments_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_slot_assignments
    ADD CONSTRAINT spoolman_slot_assignments_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: telegram_chats telegram_chats_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE RESTRICT;


--
-- Name: telegram_chats telegram_chats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_email_preferences user_email_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_email_preferences
    ADD CONSTRAINT user_email_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_oidc_links user_oidc_links_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT user_oidc_links_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.oidc_providers(id) ON DELETE CASCADE;


--
-- Name: user_oidc_links user_oidc_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT user_oidc_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_otp_codes user_otp_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_otp_codes
    ADD CONSTRAINT user_otp_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_totp user_totp_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_totp
    ADD CONSTRAINT user_totp_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: virtual_printers virtual_printers_target_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtual_printers
    ADD CONSTRAINT virtual_printers_target_folder_id_fkey FOREIGN KEY (target_folder_id) REFERENCES public.library_folders(id) ON DELETE SET NULL;


--
-- Name: virtual_printers virtual_printers_target_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtual_printers
    ADD CONSTRAINT virtual_printers_target_printer_id_fkey FOREIGN KEY (target_printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 25VSQ2HK8jjOaAO2jIB5TaZbvuKIuBHhwAvm70S9ierSBgknBp5XX0y5UQ7DFNQ

