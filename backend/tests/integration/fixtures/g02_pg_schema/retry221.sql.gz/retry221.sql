--
-- PostgreSQL database dump
--

\restrict Z3ReL7sHyee4FqwFsxVoRGgIcwVImpR1gTchStKKhHkh7eaJW4NbSaSIFp99eKd

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    id integer NOT NULL,
    version integer NOT NULL,
    name character varying(100) NOT NULL,
    applied_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: _migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public._migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: _migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public._migrations_id_seq OWNED BY public._migrations.id;


--
-- Name: active_print_spoolman; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.active_print_spoolman (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    archive_id integer NOT NULL,
    filament_usage json NOT NULL,
    ams_trays json NOT NULL,
    slot_to_tray json,
    layer_usage json,
    filament_properties json,
    tray_remain_start json
);


--
-- Name: active_print_spoolman_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.active_print_spoolman_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: active_print_spoolman_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.active_print_spoolman_id_seq OWNED BY public.active_print_spoolman.id;


--
-- Name: ams_labels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ams_labels (
    id integer NOT NULL,
    ams_serial_number character varying(50) NOT NULL,
    ams_id integer,
    label character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ams_labels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ams_labels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ams_labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ams_labels_id_seq OWNED BY public.ams_labels.id;


--
-- Name: ams_sensor_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ams_sensor_history (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    ams_id integer NOT NULL,
    humidity double precision,
    humidity_raw double precision,
    temperature double precision,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ams_sensor_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ams_sensor_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ams_sensor_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ams_sensor_history_id_seq OWNED BY public.ams_sensor_history.id;


--
-- Name: ams_setting_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ams_setting_audit (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    user_id integer,
    action character varying(50) NOT NULL,
    payload_json text NOT NULL,
    sequence_id character varying(50),
    result character varying(20) NOT NULL,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ams_setting_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ams_setting_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ams_setting_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ams_setting_audit_id_seq OWNED BY public.ams_setting_audit.id;


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(16) NOT NULL,
    user_id integer,
    can_queue boolean NOT NULL,
    can_control_printer boolean NOT NULL,
    can_read_status boolean NOT NULL,
    can_access_cloud boolean NOT NULL,
    can_update_energy_cost boolean NOT NULL,
    can_manage_library boolean NOT NULL,
    can_manage_inventory boolean NOT NULL,
    can_manage_maintenance boolean NOT NULL,
    can_manage_archives boolean NOT NULL,
    can_manage_projects boolean NOT NULL,
    printer_ids json,
    enabled boolean NOT NULL,
    last_used timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp without time zone,
    can_print_labels boolean DEFAULT false NOT NULL,
    can_access_mcp boolean DEFAULT false NOT NULL,
    can_read_mcp_logs boolean DEFAULT false NOT NULL,
    connector_identity character varying(36) NOT NULL
);


--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: auth_ephemeral_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_ephemeral_tokens (
    id integer NOT NULL,
    token character varying(128) NOT NULL,
    token_type character varying(20) NOT NULL,
    username character varying(150),
    provider_id integer,
    nonce character varying(128),
    code_verifier character varying(128),
    challenge_id character varying(128),
    used_at timestamp without time zone,
    family_id character varying(32),
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone NOT NULL,
    remember_me boolean
);


--
-- Name: auth_ephemeral_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_ephemeral_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_ephemeral_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_ephemeral_tokens_id_seq OWNED BY public.auth_ephemeral_tokens.id;


--
-- Name: auth_rate_limit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_rate_limit_events (
    id integer NOT NULL,
    username character varying(150) NOT NULL,
    event_type character varying(20) NOT NULL,
    occurred_at timestamp without time zone NOT NULL
);


--
-- Name: auth_rate_limit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_rate_limit_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_rate_limit_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_rate_limit_events_id_seq OWNED BY public.auth_rate_limit_events.id;


--
-- Name: auto_queue_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auto_queue_items (
    id integer NOT NULL,
    archive_id integer,
    library_file_id integer,
    project_id integer,
    target_model character varying(50),
    required_filament_types text,
    filament_overrides text,
    force_color_match boolean NOT NULL,
    plate_id integer,
    bed_levelling boolean NOT NULL,
    flow_cali boolean NOT NULL,
    layer_inspect boolean NOT NULL,
    timelapse boolean NOT NULL,
    use_ams boolean NOT NULL,
    mesh_mode_fast_check boolean NOT NULL,
    gcode_injection boolean DEFAULT false NOT NULL,
    execute_swap_macros boolean NOT NULL,
    swap_macro_events text,
    "position" integer NOT NULL,
    scheduled_time timestamp without time zone,
    manual_start boolean NOT NULL,
    auto_off_after boolean NOT NULL,
    require_previous_success boolean NOT NULL,
    status character varying(20) NOT NULL,
    waiting_reason text,
    assigned_to_item_id integer,
    assigned_at timestamp without time zone,
    cancelled_at timestamp without time zone,
    print_time_seconds integer,
    been_jumped boolean NOT NULL,
    batch_id character varying(36),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by_id integer,
    target_location_id integer,
    selected_macro_ids text,
    timelapse_storage text,
    nozzle_mapping text,
    project_line_id integer,
    feed_policy character varying(20) DEFAULT 'auto'::character varying NOT NULL,
    rebalanced_at timestamp without time zone,
    rebalanced_from_model character varying(64),
    queue_source_id integer,
    source_snapshot json,
    allow_base_material_match boolean DEFAULT true NOT NULL,
    auto_eject boolean DEFAULT false NOT NULL,
    auto_eject_settings json,
    order_print_options json,
    swap_declaration_identity character varying(36),
    recovery_identity character varying(36)
);


--
-- Name: auto_queue_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auto_queue_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auto_queue_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auto_queue_items_id_seq OWNED BY public.auto_queue_items.id;


--
-- Name: bug_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bug_reports (
    id integer NOT NULL,
    description text NOT NULL,
    reporter_email character varying(255),
    github_issue_number integer,
    github_issue_url character varying(500),
    status character varying(20) NOT NULL,
    error_message text,
    email_sent boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bug_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bug_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bug_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bug_reports_id_seq OWNED BY public.bug_reports.id;


--
-- Name: calibration_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calibration_audit (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    session_id integer,
    filament_calibration_id integer,
    user_id integer,
    action character varying(40) NOT NULL,
    payload_json text NOT NULL,
    sequence_id character varying(50),
    result character varying(20) NOT NULL,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: calibration_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.calibration_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: calibration_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.calibration_audit_id_seq OWNED BY public.calibration_audit.id;


--
-- Name: calibration_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calibration_session (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    user_id integer,
    cali_mode character varying(30) NOT NULL,
    method character varying(20) NOT NULL,
    nozzle_diameter double precision NOT NULL,
    nozzle_volume_type character varying(20) NOT NULL,
    extruder_id integer NOT NULL,
    filaments_json text NOT NULL,
    status character varying(30) NOT NULL,
    mqtt_sequence_id character varying(50),
    print_queue_item_id integer,
    parent_session_id integer,
    stage integer NOT NULL,
    coarse_ratio double precision,
    dispatch_args_json text,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: calibration_session_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.calibration_session_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: calibration_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.calibration_session_id_seq OWNED BY public.calibration_session.id;


--
-- Name: cameras; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cameras (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    camera_type character varying(20) NOT NULL,
    url character varying(500) NOT NULL,
    snapshot_url character varying(500),
    rotation integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    location_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: cameras_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cameras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cameras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cameras_id_seq OWNED BY public.cameras.id;


--
-- Name: cloud_link; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cloud_link (
    id integer NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    portal_url character varying(500) DEFAULT 'https://cloud.bamdude.top'::character varying NOT NULL,
    instance_id character varying(64),
    instance_secret_encrypted text,
    last_connected_at timestamp without time zone,
    last_error text,
    revoked boolean DEFAULT false NOT NULL
);


--
-- Name: cloud_link_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cloud_link_audit (
    id integer NOT NULL,
    ts timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    direction character varying(8) NOT NULL,
    kind character varying(32) NOT NULL,
    summary text NOT NULL,
    ok boolean DEFAULT true NOT NULL
);


--
-- Name: cloud_link_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cloud_link_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cloud_link_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cloud_link_audit_id_seq OWNED BY public.cloud_link_audit.id;


--
-- Name: cloud_link_printers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cloud_link_printers (
    printer_id integer NOT NULL
);


--
-- Name: color_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.color_catalog (
    id integer NOT NULL,
    manufacturer character varying(200) NOT NULL,
    color_name character varying(200) NOT NULL,
    hex_color character varying(7) NOT NULL,
    material character varying(100),
    is_default boolean NOT NULL,
    extra_colors character varying(255),
    effect_type character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: color_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.color_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: color_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.color_catalog_id_seq OWNED BY public.color_catalog.id;


--
-- Name: connector_submission_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_submission_entries (
    id integer NOT NULL,
    submission_id integer NOT NULL,
    entry_id character varying(36) NOT NULL,
    ordinal integer NOT NULL,
    intent_hash character varying(64) NOT NULL,
    state character varying(20) NOT NULL,
    published_receipt json,
    error_code character varying(64),
    error_message character varying(500),
    attempt_generation integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: connector_submission_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.connector_submission_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: connector_submission_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.connector_submission_entries_id_seq OWNED BY public.connector_submission_entries.id;


--
-- Name: connector_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_submissions (
    id integer NOT NULL,
    operation_id character varying(36) NOT NULL,
    api_key_identity character varying(36) NOT NULL,
    owner_id integer,
    server_id character varying(36) NOT NULL,
    storage_epoch character varying(36) NOT NULL,
    manifest json NOT NULL,
    manifest_hash character varying(64) NOT NULL,
    state character varying(16) NOT NULL,
    cancel_requested boolean NOT NULL,
    compacted_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: connector_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.connector_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: connector_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.connector_submissions_id_seq OWNED BY public.connector_submissions.id;


--
-- Name: customer_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_contacts (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    name character varying(255),
    role character varying(255),
    phone character varying(255),
    email character varying(255),
    city character varying(255),
    delivery_method_id integer,
    delivery_details character varying(255),
    note text
);


--
-- Name: customer_contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_contacts_id_seq OWNED BY public.customer_contacts.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    kind character varying(16) DEFAULT 'company'::character varying NOT NULL
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: delivery_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_methods (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_key character varying(255) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: delivery_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delivery_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delivery_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delivery_methods_id_seq OWNED BY public.delivery_methods.id;


--
-- Name: drying_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drying_schedules (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    ams_id integer NOT NULL,
    temp integer NOT NULL,
    duration_hours integer NOT NULL,
    filament character varying(50) DEFAULT ''::character varying NOT NULL,
    rotate_tray boolean DEFAULT false NOT NULL,
    start_time character varying(5) NOT NULL,
    weekdays integer DEFAULT 127 NOT NULL,
    latest_start character varying(5),
    enabled boolean DEFAULT true NOT NULL,
    created_by_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: drying_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.drying_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: drying_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.drying_schedules_id_seq OWNED BY public.drying_schedules.id;


--
-- Name: external_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_links (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    url character varying(500) NOT NULL,
    icon character varying(50) NOT NULL,
    custom_icon character varying(255),
    open_in_new_tab boolean NOT NULL,
    nav_group character varying(20) NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: external_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.external_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: external_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.external_links_id_seq OWNED BY public.external_links.id;


--
-- Name: filament_calibration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filament_calibration (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    filament_id character varying(50) NOT NULL,
    filament_setting_id character varying(100),
    nozzle_diameter double precision NOT NULL,
    nozzle_volume_type character varying(20) NOT NULL,
    extruder_id integer DEFAULT 0 NOT NULL,
    pa_k_value double precision,
    pa_n_coef double precision,
    flow_ratio double precision,
    confidence integer,
    cali_mode character varying(30) NOT NULL,
    source character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    cali_idx integer,
    name character varying(120) NOT NULL,
    notes text,
    nozzle_id character varying(20),
    calibrated_by_user_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tower_result double precision
);


--
-- Name: filament_calibration_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filament_calibration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filament_calibration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filament_calibration_id_seq OWNED BY public.filament_calibration.id;


--
-- Name: filament_shopping_list; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filament_shopping_list (
    id integer NOT NULL,
    material character varying(50) NOT NULL,
    subtype character varying(50),
    brand character varying(100),
    color_name character varying(100),
    quantity_spools integer NOT NULL,
    note character varying(500),
    status character varying(20) NOT NULL,
    purchased_at timestamp without time zone,
    added_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: filament_shopping_list_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filament_shopping_list_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filament_shopping_list_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filament_shopping_list_id_seq OWNED BY public.filament_shopping_list.id;


--
-- Name: filament_sku_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filament_sku_settings (
    id integer NOT NULL,
    material character varying(50) NOT NULL,
    subtype character varying(50),
    brand character varying(100),
    color_name character varying(100),
    lead_time_days integer NOT NULL,
    safety_margin_value integer NOT NULL,
    safety_margin_unit character varying(10) NOT NULL,
    alerts_snoozed boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    stock_break_notified_at timestamp without time zone,
    stock_reorder_notified_at timestamp without time zone
);


--
-- Name: filament_sku_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filament_sku_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filament_sku_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filament_sku_settings_id_seq OWNED BY public.filament_sku_settings.id;


--
-- Name: firmware_batch_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.firmware_batch_items (
    id integer NOT NULL,
    run_id integer NOT NULL,
    printer_id integer NOT NULL,
    model character varying(64) NOT NULL,
    from_version character varying(64),
    to_version character varying(64) NOT NULL,
    action character varying(16) NOT NULL,
    status character varying(16) NOT NULL,
    message text,
    error text,
    started_at timestamp without time zone,
    finished_at timestamp without time zone
);


--
-- Name: firmware_batch_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.firmware_batch_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: firmware_batch_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.firmware_batch_items_id_seq OWNED BY public.firmware_batch_items.id;


--
-- Name: firmware_batch_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.firmware_batch_runs (
    id integer NOT NULL,
    created_by_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source character varying(16) NOT NULL,
    status character varying(16) NOT NULL,
    total integer NOT NULL,
    succeeded integer NOT NULL,
    skipped integer NOT NULL,
    failed integer NOT NULL
);


--
-- Name: firmware_batch_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.firmware_batch_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: firmware_batch_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.firmware_batch_runs_id_seq OWNED BY public.firmware_batch_runs.id;


--
-- Name: firmware_cache_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.firmware_cache_entries (
    id integer NOT NULL,
    model character varying(64) NOT NULL,
    version character varying(64) NOT NULL,
    filename character varying(255) NOT NULL,
    sha256 character varying(64) NOT NULL,
    size_bytes integer NOT NULL,
    source_url text,
    release_notes text,
    downloaded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: firmware_cache_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.firmware_cache_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: firmware_cache_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.firmware_cache_entries_id_seq OWNED BY public.firmware_cache_entries.id;


--
-- Name: git_backup_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_backup_config (
    id integer NOT NULL,
    provider character varying(20) NOT NULL,
    repository_url character varying(500) NOT NULL,
    access_token text NOT NULL,
    branch character varying(100) NOT NULL,
    api_base_url character varying(500),
    schedule_enabled boolean NOT NULL,
    schedule_type character varying(20) NOT NULL,
    schedule_cron character varying(100),
    backup_kprofiles boolean NOT NULL,
    backup_cloud_profiles boolean NOT NULL,
    backup_settings boolean NOT NULL,
    backup_spools boolean NOT NULL,
    backup_archives boolean NOT NULL,
    enabled boolean NOT NULL,
    last_backup_at timestamp without time zone,
    last_backup_status character varying(20),
    last_backup_message text,
    last_backup_commit_sha character varying(40),
    next_scheduled_run timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: git_backup_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.git_backup_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: git_backup_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.git_backup_config_id_seq OWNED BY public.git_backup_config.id;


--
-- Name: git_backup_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.git_backup_logs (
    id integer NOT NULL,
    config_id integer NOT NULL,
    started_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp without time zone,
    status character varying(20) NOT NULL,
    trigger character varying(20) NOT NULL,
    commit_sha character varying(40),
    files_changed integer NOT NULL,
    error_message text
);


--
-- Name: git_backup_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.git_backup_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: git_backup_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.git_backup_logs_id_seq OWNED BY public.git_backup_logs.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500),
    permissions json NOT NULL,
    is_system boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: ha_sensor_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ha_sensor_history (
    id bigint NOT NULL,
    printer_sensor_id integer,
    location_sensor_id integer,
    revision integer NOT NULL,
    entity_id character varying(255) NOT NULL,
    kind character varying(16) NOT NULL,
    unit character varying(16),
    state character varying(64) NOT NULL,
    value double precision,
    observed_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_ha_history_one_owner CHECK (((printer_sensor_id IS NULL) <> (location_sensor_id IS NULL)))
);


--
-- Name: ha_sensor_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ha_sensor_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ha_sensor_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ha_sensor_history_id_seq OWNED BY public.ha_sensor_history.id;


--
-- Name: hms_muted_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hms_muted_entries (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    full_code character varying(16) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: hms_muted_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hms_muted_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hms_muted_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hms_muted_entries_id_seq OWNED BY public.hms_muted_entries.id;


--
-- Name: kprofile_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kprofile_notes (
    id integer NOT NULL,
    filament_calibration_id integer NOT NULL,
    note text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: kprofile_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kprofile_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kprofile_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kprofile_notes_id_seq OWNED BY public.kprofile_notes.id;


--
-- Name: label_cassettes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.label_cassettes (
    id integer NOT NULL,
    barcode character varying(64) NOT NULL,
    width_mm double precision NOT NULL,
    height_mm double precision NOT NULL,
    name character varying(128),
    created_at timestamp without time zone
);


--
-- Name: label_cassettes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.label_cassettes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: label_cassettes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.label_cassettes_id_seq OWNED BY public.label_cassettes.id;


--
-- Name: label_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.label_devices (
    id integer NOT NULL,
    installation_id character varying(64) NOT NULL,
    driver character varying(32) DEFAULT 'niimbot'::character varying NOT NULL,
    model character varying(64),
    protocol_version integer,
    transport character varying(16),
    address character varying(128),
    name character varying(128),
    enabled boolean DEFAULT false NOT NULL,
    density integer DEFAULT 3 NOT NULL,
    app_version character varying(32),
    last_seen_at timestamp without time zone,
    cassette_barcode character varying(64),
    cassette_width_mm double precision,
    cassette_height_mm double precision,
    paper_state integer,
    power_level integer,
    printer_reachable boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: label_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.label_devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: label_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.label_devices_id_seq OWNED BY public.label_devices.id;


--
-- Name: label_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.label_jobs (
    id integer NOT NULL,
    device_id integer NOT NULL,
    spool_id integer,
    template_id integer,
    width_mm double precision NOT NULL,
    height_mm double precision NOT NULL,
    copies integer DEFAULT 1 NOT NULL,
    image_png bytea NOT NULL,
    status character varying(16) DEFAULT 'queued'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    error text,
    claimed_at timestamp without time zone,
    created_by integer,
    created_at timestamp without time zone
);


--
-- Name: label_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.label_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: label_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.label_jobs_id_seq OWNED BY public.label_jobs.id;


--
-- Name: label_sheets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.label_sheets (
    id integer NOT NULL,
    name character varying(120) NOT NULL,
    builtin_key character varying(64),
    page_size character varying(16) DEFAULT 'A4'::character varying NOT NULL,
    cell_width_mm double precision NOT NULL,
    cell_height_mm double precision NOT NULL,
    cols integer NOT NULL,
    rows integer NOT NULL,
    margin_top_mm double precision DEFAULT 0 NOT NULL,
    margin_left_mm double precision DEFAULT 0 NOT NULL,
    gap_x_mm double precision DEFAULT 0 NOT NULL,
    gap_y_mm double precision DEFAULT 0 NOT NULL,
    created_at timestamp without time zone
);


--
-- Name: label_sheets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.label_sheets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: label_sheets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.label_sheets_id_seq OWNED BY public.label_sheets.id;


--
-- Name: label_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.label_templates (
    id integer NOT NULL,
    name character varying(120) NOT NULL,
    width_mm double precision NOT NULL,
    height_mm double precision NOT NULL,
    shape character varying(16) DEFAULT 'rect'::character varying NOT NULL,
    target character varying(16) DEFAULT 'driver'::character varying NOT NULL,
    description character varying(300) DEFAULT ''::character varying NOT NULL,
    elements jsonb NOT NULL,
    builtin_key character varying(64),
    created_by integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: label_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.label_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: label_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.label_templates_id_seq OWNED BY public.label_templates.id;


--
-- Name: library_file_makerworld_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_file_makerworld_meta (
    id integer NOT NULL,
    library_file_id integer NOT NULL,
    title character varying(500),
    description text,
    author_name character varying(255),
    author_profile_url character varying(500),
    license character varying(64),
    original_design_id integer,
    variant_title character varying(500),
    variant_description text,
    variant_url character varying(500),
    profile_id integer,
    cover_path character varying(500),
    variant_cover_path character varying(500),
    sliced_for character varying(64),
    compatible_models json,
    needs_ams boolean,
    material_count integer,
    materials json,
    model_id_alphanumeric character varying(64),
    raw_payload json,
    imported_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: library_file_makerworld_meta_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_file_makerworld_meta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_file_makerworld_meta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_file_makerworld_meta_id_seq OWNED BY public.library_file_makerworld_meta.id;


--
-- Name: library_file_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_file_notes (
    id integer NOT NULL,
    library_file_id integer NOT NULL,
    user_id integer,
    body character varying(1000) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: library_file_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_file_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_file_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_file_notes_id_seq OWNED BY public.library_file_notes.id;


--
-- Name: library_file_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_file_tags (
    file_id integer NOT NULL,
    tag_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: library_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_files (
    id integer NOT NULL,
    folder_id integer,
    is_external boolean NOT NULL,
    filename character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_type character varying(10) NOT NULL,
    file_tags json DEFAULT '[]'::json NOT NULL,
    file_size integer NOT NULL,
    file_hash character varying(64),
    thumbnail_path character varying(500),
    file_metadata json,
    print_count integer DEFAULT 0 NOT NULL,
    last_printed_at timestamp without time zone,
    notes text,
    source_type character varying(32),
    source_url character varying(512),
    created_by_id integer,
    swap_compatible boolean NOT NULL,
    skip_objects_supported boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp without time zone,
    fs_modified_at timestamp without time zone,
    swap_source_declaration json
);


--
-- Name: library_files_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_files_id_seq OWNED BY public.library_files.id;


--
-- Name: library_folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_folders (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    parent_id integer,
    is_external boolean NOT NULL,
    external_readonly boolean NOT NULL,
    external_show_hidden boolean NOT NULL,
    external_path character varying(500),
    archive_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    fs_modified_at timestamp without time zone
);


--
-- Name: library_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_folders_id_seq OWNED BY public.library_folders.id;


--
-- Name: library_scan_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_scan_jobs (
    id integer NOT NULL,
    folder_id integer NOT NULL,
    status character varying(16) DEFAULT 'queued'::character varying NOT NULL,
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    files_total integer DEFAULT 0 NOT NULL,
    files_seen integer DEFAULT 0 NOT NULL,
    files_added integer DEFAULT 0 NOT NULL,
    files_updated integer DEFAULT 0 NOT NULL,
    files_removed integer DEFAULT 0 NOT NULL,
    folders_added integer DEFAULT 0 NOT NULL,
    folders_removed integer DEFAULT 0 NOT NULL,
    skipped_deletions boolean DEFAULT false NOT NULL,
    error text,
    created_by integer,
    created_at timestamp without time zone
);


--
-- Name: library_scan_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_scan_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_scan_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_scan_jobs_id_seq OWNED BY public.library_scan_jobs.id;


--
-- Name: library_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_tags (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    name_key character varying(64) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    code character varying(32)
);


--
-- Name: library_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_tags_id_seq OWNED BY public.library_tags.id;


--
-- Name: local_presets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.local_presets (
    id integer NOT NULL,
    name character varying(300) NOT NULL,
    preset_type character varying(20) NOT NULL,
    source character varying(50) NOT NULL,
    filament_type character varying(50),
    filament_vendor character varying(200),
    nozzle_temp_min integer,
    nozzle_temp_max integer,
    pressure_advance character varying(50),
    default_filament_colour character varying(50),
    filament_cost character varying(50),
    filament_density character varying(50),
    compatible_printers text,
    setting text NOT NULL,
    inherits character varying(300),
    version character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: local_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.local_presets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: local_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.local_presets_id_seq OWNED BY public.local_presets.id;


--
-- Name: location_ha_sensors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_ha_sensors (
    id integer NOT NULL,
    location_id integer NOT NULL,
    name character varying(100) NOT NULL,
    entity_id character varying(255) NOT NULL,
    kind character varying(16) NOT NULL,
    device_class character varying(32),
    unit character varying(16),
    alert_state character varying(8),
    alert_above double precision,
    alert_below double precision,
    notify_on_alert boolean DEFAULT false NOT NULL,
    show_on_card boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    history_revision integer DEFAULT 1 NOT NULL,
    last_state character varying(64),
    last_changed timestamp without time zone,
    last_checked timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: location_ha_sensors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.location_ha_sensors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: location_ha_sensors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.location_ha_sensors_id_seq OWNED BY public.location_ha_sensors.id;


--
-- Name: location_sensor_primary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_sensor_primary (
    location_id integer NOT NULL,
    category character varying(16) NOT NULL,
    source character varying(16) NOT NULL,
    binding_id integer NOT NULL
);


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_key character varying(255) NOT NULL,
    identifier character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: long_lived_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.long_lived_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(100) NOT NULL,
    lookup_prefix character varying(8) NOT NULL,
    secret_hash character varying(255) NOT NULL,
    scope character varying(32) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    last_used_at timestamp without time zone,
    revoked_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: long_lived_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.long_lived_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: long_lived_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.long_lived_tokens_id_seq OWNED BY public.long_lived_tokens.id;


--
-- Name: macros; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.macros (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    printer_models text NOT NULL,
    swap_mode_only boolean NOT NULL,
    swap_profile character varying(50),
    event character varying(50) NOT NULL,
    action_type character varying(20) DEFAULT 'gcode'::character varying NOT NULL,
    mqtt_action character varying(50),
    delay_seconds integer DEFAULT 0 NOT NULL,
    gcode text NOT NULL,
    is_custom boolean NOT NULL,
    enabled boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    mqtt_action_param character varying(50),
    trigger_layer integer
);


--
-- Name: macros_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.macros_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: macros_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.macros_id_seq OWNED BY public.macros.id;


--
-- Name: maintenance_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_history (
    id integer NOT NULL,
    printer_maintenance_id integer NOT NULL,
    performed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    hours_at_maintenance double precision NOT NULL,
    notes text,
    performed_by_user_id integer,
    performed_by_chat_id integer
);


--
-- Name: maintenance_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.maintenance_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maintenance_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.maintenance_history_id_seq OWNED BY public.maintenance_history.id;


--
-- Name: maintenance_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_types (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    default_interval_hours double precision NOT NULL,
    interval_type character varying(20) NOT NULL,
    icon character varying(50),
    wiki_url character varying(500),
    printer_models text NOT NULL,
    type_code character varying(50),
    is_system boolean NOT NULL,
    is_deleted boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: maintenance_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.maintenance_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maintenance_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.maintenance_types_id_seq OWNED BY public.maintenance_types.id;


--
-- Name: notification_digest_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_digest_queue (
    id integer NOT NULL,
    provider_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    printer_id integer,
    printer_name character varying(100),
    created_at timestamp without time zone
);


--
-- Name: notification_digest_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_digest_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_digest_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_digest_queue_id_seq OWNED BY public.notification_digest_queue.id;


--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_logs (
    id integer NOT NULL,
    provider_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    success boolean,
    error_message text,
    printer_id integer,
    printer_name character varying(100),
    created_at timestamp without time zone
);


--
-- Name: notification_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_logs_id_seq OWNED BY public.notification_logs.id;


--
-- Name: notification_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_providers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    provider_type character varying(50) NOT NULL,
    enabled boolean,
    config text NOT NULL,
    quiet_hours_enabled boolean,
    quiet_hours_start character varying(5),
    quiet_hours_end character varying(5),
    daily_digest_enabled boolean,
    daily_digest_time character varying(5),
    last_success timestamp without time zone,
    last_error text,
    last_error_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    progress_min_duration_minutes integer,
    printer_ids json,
    subscribed_events json
);


--
-- Name: notification_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_providers_id_seq OWNED BY public.notification_providers.id;


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_templates (
    id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    title_template text NOT NULL,
    body_template text NOT NULL,
    is_default boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_templates_id_seq OWNED BY public.notification_templates.id;


--
-- Name: obico_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.obico_events (
    id character varying(36) NOT NULL,
    printer_id integer NOT NULL,
    observed_at timestamp without time zone NOT NULL,
    verdict character varying(8) NOT NULL,
    state character varying(16) NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 character varying(64) NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    facts json NOT NULL,
    raw_boxes json NOT NULL,
    invalid_boxes integer NOT NULL
);


--
-- Name: oidc_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oidc_providers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    issuer_url character varying(500) NOT NULL,
    client_id character varying(255) NOT NULL,
    client_secret character varying(512) NOT NULL,
    scopes character varying(500) NOT NULL,
    is_enabled boolean NOT NULL,
    auto_create_users boolean NOT NULL,
    auto_link_existing_accounts boolean NOT NULL,
    email_claim character varying(64) DEFAULT 'email'::character varying NOT NULL,
    require_email_verified boolean DEFAULT true NOT NULL,
    default_group_id integer,
    icon_url text,
    icon_data bytea,
    icon_content_type character varying(20),
    icon_etag character varying(64),
    is_autologin boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_env_managed boolean DEFAULT false,
    CONSTRAINT ck_auto_link_requires_verified_email_claim CHECK (((NOT auto_link_existing_accounts) OR ((email_claim)::text <> 'email'::text) OR require_email_verified)),
    CONSTRAINT ck_oidc_icon_triplet_co_null CHECK ((((icon_data IS NULL) = (icon_content_type IS NULL)) AND ((icon_content_type IS NULL) = (icon_etag IS NULL))))
);


--
-- Name: oidc_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oidc_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oidc_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oidc_providers_id_seq OWNED BY public.oidc_providers.id;


--
-- Name: orca_base_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orca_base_profiles (
    id integer NOT NULL,
    name character varying(300) NOT NULL,
    profile_type character varying(20) NOT NULL,
    setting text NOT NULL,
    fetched_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: orca_base_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orca_base_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orca_base_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orca_base_profiles_id_seq OWNED BY public.orca_base_profiles.id;


--
-- Name: order_plan_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_plan_receipts (
    id character varying(210) NOT NULL,
    operation_id character varying(100) NOT NULL,
    entry_id character varying(100) NOT NULL,
    count integer NOT NULL,
    outcome json NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: order_plan_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_plan_submissions (
    id character varying(100) NOT NULL,
    plan_id integer NOT NULL,
    actor character varying(128) NOT NULL,
    request_digest character varying(64) NOT NULL,
    request json NOT NULL,
    status character varying(20) NOT NULL,
    epoch_advanced boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: order_working_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_working_plans (
    id integer NOT NULL,
    revision integer NOT NULL,
    schema_version integer NOT NULL,
    entries json NOT NULL,
    facts json NOT NULL,
    saved_revision integer NOT NULL,
    saved_entries json,
    saved_facts json,
    saved_epoch integer,
    saved_at timestamp without time zone,
    saved_by character varying(128),
    epoch integer NOT NULL,
    active_operation character varying(100),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by character varying(128),
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: plate_render_objects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plate_render_objects (
    id integer NOT NULL,
    render_id integer NOT NULL,
    identify_id bigint NOT NULL,
    method character varying(16) NOT NULL,
    reason character varying(32),
    width integer,
    height integer,
    tools json NOT NULL,
    CONSTRAINT ck_plate_render_objects_method CHECK (((method)::text = ANY ((ARRAY['toolpath'::character varying, 'model'::character varying, 'top_mask'::character varying, 'missing'::character varying, 'skipped'::character varying])::text[])))
);


--
-- Name: plate_render_objects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plate_render_objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plate_render_objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plate_render_objects_id_seq OWNED BY public.plate_render_objects.id;


--
-- Name: plate_renders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plate_renders (
    id integer NOT NULL,
    file_sha256 character varying(64) NOT NULL,
    plate_index integer NOT NULL,
    renderer_version integer NOT NULL,
    status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    phase character varying(16) DEFAULT 'render'::character varying NOT NULL,
    reason character varying(32),
    result_dir character varying(36),
    manifest_sha256 character varying(64),
    runtime_version character varying(32),
    priority integer DEFAULT 0 NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp without time zone NOT NULL,
    last_error character varying(64),
    requested_at timestamp without time zone NOT NULL,
    finished_at timestamp without time zone,
    elapsed_ms integer,
    orphaned_at timestamp without time zone,
    CONSTRAINT ck_plate_renders_phase CHECK (((phase)::text = ANY ((ARRAY['render'::character varying, 'fallback'::character varying])::text[]))),
    CONSTRAINT ck_plate_renders_sha256 CHECK ((length((file_sha256)::text) = 64)),
    CONSTRAINT ck_plate_renders_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'ready'::character varying, 'failed'::character varying, 'unavailable'::character varying])::text[])))
);


--
-- Name: plate_renders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plate_renders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plate_renders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plate_renders_id_seq OWNED BY public.plate_renders.id;


--
-- Name: print_archive_parts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_archive_parts (
    id integer NOT NULL,
    archive_id integer NOT NULL,
    name character varying(512) NOT NULL,
    name_key character varying(512) NOT NULL,
    identify_ids json,
    quantity integer DEFAULT 1 NOT NULL,
    defective integer DEFAULT 0 NOT NULL
);


--
-- Name: print_archive_parts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.print_archive_parts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: print_archive_parts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.print_archive_parts_id_seq OWNED BY public.print_archive_parts.id;


--
-- Name: print_archives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_archives (
    id integer NOT NULL,
    printer_id integer,
    project_id integer,
    library_file_id integer,
    queue_id integer,
    batch_id character varying(36),
    error_message text,
    filename character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer NOT NULL,
    content_hash character varying(64),
    source_content_hash character varying(64),
    applied_patches text,
    subtask_id character varying(64),
    thumbnail_path character varying(500),
    timelapse_path character varying(500),
    bamdude_forced_timelapse boolean DEFAULT false NOT NULL,
    source_3mf_path character varying(500),
    f3d_path character varying(500),
    print_name character varying(255),
    print_time_seconds integer,
    filament_used_grams double precision,
    filament_type character varying(50),
    filament_color character varying(50),
    layer_height double precision,
    total_layers integer,
    nozzle_diameter double precision,
    bed_temperature integer,
    bed_type character varying(64),
    nozzle_temperature integer,
    sliced_for_model character varying(50),
    plate_index integer,
    status character varying(20) NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    actual_time_seconds integer,
    time_accuracy double precision,
    extra_data json,
    makerworld_url character varying(500),
    designer character varying(255),
    external_url character varying(500),
    is_favorite boolean NOT NULL,
    tags text,
    notes text,
    cost double precision,
    photos json,
    failure_reason character varying(100),
    quantity integer NOT NULL,
    energy_kwh double precision,
    energy_cost double precision,
    energy_start_kwh double precision,
    swap_compatible boolean NOT NULL,
    skip_objects_supported boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp without time zone,
    created_by_id integer,
    is_calibration boolean NOT NULL,
    calibration_session_id integer,
    from_auto_queue boolean NOT NULL,
    defective_count integer DEFAULT 0 NOT NULL,
    project_line_id integer,
    swap_source_declaration json,
    recovery_identity character varying(36),
    dispatch_phase character varying(16),
    dispatch_boot_id character varying(36),
    queue_item_identity character varying(36),
    source_auto_identity character varying(36)
);


--
-- Name: print_archives_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.print_archives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: print_archives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.print_archives_id_seq OWNED BY public.print_archives.id;


--
-- Name: print_completion_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_completion_receipts (
    id integer NOT NULL,
    archive_id integer NOT NULL,
    assessment json,
    assessment_at timestamp without time zone,
    assessment_actor_id integer,
    plate_action character varying(16),
    plate_action_at timestamp without time zone,
    plate_action_actor_id integer,
    gate_token character varying(64),
    rearmed_queue_item_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: print_completion_receipts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.print_completion_receipts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: print_completion_receipts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.print_completion_receipts_id_seq OWNED BY public.print_completion_receipts.id;


--
-- Name: print_options_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_options_preferences (
    id integer NOT NULL,
    user_id integer,
    printer_model character varying(64) NOT NULL,
    options json NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: print_options_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.print_options_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: print_options_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.print_options_preferences_id_seq OWNED BY public.print_options_preferences.id;


--
-- Name: print_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_queue (
    id integer NOT NULL,
    queue_id integer NOT NULL,
    waiting_reason text,
    archive_id integer,
    library_file_id integer,
    project_id integer,
    "position" integer DEFAULT 0 NOT NULL,
    scheduled_time timestamp without time zone,
    manual_start boolean DEFAULT false NOT NULL,
    auto_off_after boolean DEFAULT false NOT NULL,
    ams_mapping text,
    plate_id integer,
    bed_levelling boolean DEFAULT true NOT NULL,
    flow_cali boolean DEFAULT true NOT NULL,
    layer_inspect boolean DEFAULT false NOT NULL,
    timelapse boolean DEFAULT false NOT NULL,
    use_ams boolean DEFAULT true NOT NULL,
    mesh_mode_fast_check boolean DEFAULT true NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    execute_swap_macros boolean DEFAULT true,
    swap_macro_events text,
    batch_id character varying(36),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by_id integer,
    source_auto_item_id integer,
    gcode_injection boolean DEFAULT false NOT NULL,
    is_calibration boolean DEFAULT false NOT NULL,
    calibration_session_id integer,
    nozzle_offset_cali boolean DEFAULT true NOT NULL,
    nozzle_mapping text,
    preheat_override character varying(20) DEFAULT 'inherit'::character varying NOT NULL,
    preheat_chamber_target_override integer,
    bed_levelling_mode character varying(8),
    flow_cali_mode character varying(8),
    nozzle_offset_cali_mode character varying(8),
    dispatch_attempts integer DEFAULT 0 NOT NULL,
    require_previous_success boolean DEFAULT false NOT NULL,
    gate_acknowledged boolean DEFAULT false NOT NULL,
    selected_macro_ids text,
    timelapse_storage text,
    project_line_id integer,
    origin character varying(16) DEFAULT 'queue'::character varying,
    filament_routing text,
    waiting_reason_code character varying(40),
    waiting_reason_checked_at timestamp without time zone,
    queue_source_id integer,
    source_snapshot json,
    nozzle_rack_choice text,
    auto_eject boolean DEFAULT false NOT NULL,
    auto_eject_settings json,
    swap_declaration_identity character varying(36),
    recovery_identity character varying(36),
    error_code character varying(40),
    source_auto_identity character varying(36)
);


--
-- Name: print_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.print_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: print_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.print_queue_id_seq OWNED BY public.print_queue.id;


--
-- Name: print_state_recovery_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_state_recovery_actions (
    id character varying(36) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    actor character varying(100) NOT NULL,
    actor_label character varying(100) NOT NULL,
    printer_id integer NOT NULL,
    queue_id integer NOT NULL,
    item_id integer,
    archive_id integer,
    action character varying(40) NOT NULL,
    input_hash character varying(64) NOT NULL,
    result json NOT NULL
);


--
-- Name: print_usage_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.print_usage_events (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    archive_id integer NOT NULL,
    layer_num integer NOT NULL,
    event character varying(24) NOT NULL,
    kind character varying(24),
    global_tray_id integer,
    spool_id integer,
    spoolman_spool_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    slot_occupied boolean
);


--
-- Name: print_usage_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.print_usage_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: print_usage_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.print_usage_events_id_seq OWNED BY public.print_usage_events.id;


--
-- Name: printer_ha_sensors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_ha_sensors (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    name character varying(100) NOT NULL,
    entity_id character varying(255) NOT NULL,
    kind character varying(16) NOT NULL,
    device_class character varying(32),
    unit character varying(16),
    alert_state character varying(8),
    alert_above double precision,
    alert_below double precision,
    block_print boolean DEFAULT false NOT NULL,
    notify_on_alert boolean DEFAULT false NOT NULL,
    show_on_printer_card boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    history_revision integer DEFAULT 1 NOT NULL,
    last_state character varying(64),
    last_changed timestamp without time zone,
    last_checked timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: printer_ha_sensors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printer_ha_sensors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_ha_sensors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printer_ha_sensors_id_seq OWNED BY public.printer_ha_sensors.id;


--
-- Name: printer_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_locations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    name_key character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    parent_id integer
);


--
-- Name: printer_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printer_locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printer_locations_id_seq OWNED BY public.printer_locations.id;


--
-- Name: printer_maintenance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_maintenance (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    maintenance_type_id integer NOT NULL,
    custom_interval_hours double precision,
    custom_interval_type character varying(20),
    enabled boolean NOT NULL,
    last_performed_at timestamp without time zone,
    last_performed_hours double precision NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: printer_maintenance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printer_maintenance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_maintenance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printer_maintenance_id_seq OWNED BY public.printer_maintenance.id;


--
-- Name: printer_queues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_queues (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    status character varying(20) DEFAULT 'idle'::character varying NOT NULL,
    last_activity_at timestamp without time zone,
    current_item_id integer,
    pending_count integer DEFAULT 0 NOT NULL,
    skipped_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    auto_distribute_eligible boolean DEFAULT true NOT NULL,
    is_paused boolean DEFAULT false NOT NULL,
    recovery_identity character varying(36)
);


--
-- Name: printer_queues_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printer_queues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_queues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printer_queues_id_seq OWNED BY public.printer_queues.id;


--
-- Name: printer_sensor_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_sensor_history (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    sensor_kind character varying(32) NOT NULL,
    value double precision,
    target double precision,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: printer_sensor_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printer_sensor_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_sensor_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printer_sensor_history_id_seq OWNED BY public.printer_sensor_history.id;


--
-- Name: printer_setting_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_setting_audit (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    user_id integer,
    tab character varying(30) NOT NULL,
    action character varying(50) NOT NULL,
    payload_json text NOT NULL,
    sequence_id character varying(50),
    result character varying(20) NOT NULL,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: printer_setting_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printer_setting_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_setting_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printer_setting_audit_id_seq OWNED BY public.printer_setting_audit.id;


--
-- Name: printer_tag_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_tag_links (
    printer_id integer NOT NULL,
    tag_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: printer_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printer_tags (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    name_key character varying(128) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    color character varying(7)
);


--
-- Name: printer_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printer_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printer_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printer_tags_id_seq OWNED BY public.printer_tags.id;


--
-- Name: printers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.printers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    serial_number character varying(50) NOT NULL,
    ip_address character varying(253) NOT NULL,
    access_code character varying(20) NOT NULL,
    model character varying(50),
    nozzle_count integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    auto_archive boolean DEFAULT true NOT NULL,
    cleanup_after_print boolean DEFAULT false NOT NULL,
    mqtt_connection_timeout integer DEFAULT 900 NOT NULL,
    print_hours_offset double precision DEFAULT 0.0 NOT NULL,
    runtime_seconds integer DEFAULT 0 NOT NULL,
    last_runtime_update timestamp without time zone,
    external_camera_url character varying(500),
    external_camera_type character varying(20),
    external_camera_enabled boolean DEFAULT false NOT NULL,
    camera_rotation integer DEFAULT 0 NOT NULL,
    plate_detection_enabled boolean DEFAULT false NOT NULL,
    plate_detection_roi_x double precision,
    plate_detection_roi_y double precision,
    plate_detection_roi_w double precision,
    plate_detection_roi_h double precision,
    stagger_interval_minutes integer DEFAULT 0 NOT NULL,
    swap_mode_enabled boolean DEFAULT false NOT NULL,
    swap_profile character varying(50),
    require_plate_clear boolean DEFAULT true NOT NULL,
    awaiting_plate_clear boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    external_camera_snapshot_url character varying(500),
    archived boolean DEFAULT false NOT NULL,
    archived_at timestamp without time zone,
    location_id integer,
    mqtt_recording boolean DEFAULT false NOT NULL,
    mqtt_recording_started_at timestamp without time zone,
    ams_policies json DEFAULT '{}'::json NOT NULL,
    camera_light_auto character varying(8) DEFAULT 'inherit'::character varying NOT NULL,
    awaiting_plate_clear_archive_id integer,
    awaiting_plate_clear_token character varying(64),
    plate_detection_polygon json,
    connector_identity character varying(36) NOT NULL
);


--
-- Name: printers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.printers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.printers_id_seq OWNED BY public.printers.id;


--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_categories (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    name_key character varying(512) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: product_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_categories_id_seq OWNED BY public.product_categories.id;


--
-- Name: product_facets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_facets (
    product_id integer NOT NULL,
    library_file_id integer NOT NULL,
    kind character varying(16) NOT NULL,
    value character varying(64) NOT NULL
);


--
-- Name: product_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_files (
    product_id integer NOT NULL,
    library_file_id integer NOT NULL
);


--
-- Name: product_folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_folders (
    product_id integer NOT NULL,
    library_folder_id integer NOT NULL
);


--
-- Name: product_part_stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_part_stock_movements (
    id integer NOT NULL,
    product_part_id integer NOT NULL,
    delta integer NOT NULL,
    reason character varying(32) NOT NULL,
    project_line_id integer,
    archive_id integer,
    note text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    stock_item_id integer,
    stock_issue_id integer
);


--
-- Name: product_part_stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_part_stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_part_stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_part_stock_movements_id_seq OWNED BY public.product_part_stock_movements.id;


--
-- Name: product_parts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_parts (
    id integer NOT NULL,
    product_id integer NOT NULL,
    kind character varying(16) DEFAULT 'printed'::character varying NOT NULL,
    name character varying(512) NOT NULL,
    name_key character varying(512) NOT NULL,
    qty_per_unit integer DEFAULT 1 NOT NULL,
    aliases json,
    auto boolean DEFAULT false NOT NULL,
    unit_price double precision,
    sourcing_url character varying(512),
    remarks text,
    sort_order integer DEFAULT 0 NOT NULL,
    variant_option_id integer,
    ignored boolean DEFAULT false NOT NULL,
    extra_percent double precision DEFAULT 0 NOT NULL,
    image_source character varying(16) DEFAULT 'auto'::character varying NOT NULL,
    image_file_id integer,
    image_plate_index integer,
    image_identify_id bigint,
    image_photo character varying(64)
);


--
-- Name: product_parts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_parts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_parts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_parts_id_seq OWNED BY public.product_parts.id;


--
-- Name: product_plates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_plates (
    id integer NOT NULL,
    product_id integer NOT NULL,
    library_file_id integer NOT NULL,
    plate_index integer DEFAULT 0 NOT NULL
);


--
-- Name: product_plates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_plates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_plates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_plates_id_seq OWNED BY public.product_plates.id;


--
-- Name: product_variant_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variant_groups (
    id integer NOT NULL,
    product_id integer NOT NULL,
    name character varying(128) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    default_option_id integer
);


--
-- Name: product_variant_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_variant_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_variant_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_variant_groups_id_seq OWNED BY public.product_variant_groups.id;


--
-- Name: product_variant_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_variant_options (
    id integer NOT NULL,
    group_id integer NOT NULL,
    name character varying(128) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: product_variant_options_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_variant_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_variant_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_variant_options_id_seq OWNED BY public.product_variant_options.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    notes text,
    designer character varying(255),
    license character varying(255),
    source_url character varying(2048),
    design_id character varying(64),
    cover_image_filename character varying(255),
    attachments json,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    origin character varying(16) DEFAULT 'catalog'::character varying NOT NULL,
    origin_file_id integer,
    origin_plate_index integer,
    sku character varying(64),
    sku_key character varying(255),
    version character varying(64),
    category_id integer,
    status character varying(16) DEFAULT 'draft'::character varying NOT NULL
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: project_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_events (
    id integer NOT NULL,
    project_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_id integer,
    user_name character varying(100),
    kind character varying(40) NOT NULL,
    payload json NOT NULL
);


--
-- Name: project_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_events_id_seq OWNED BY public.project_events.id;


--
-- Name: project_line_choices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_line_choices (
    line_id integer NOT NULL,
    group_id integer NOT NULL,
    option_id integer NOT NULL
);


--
-- Name: project_line_part_counts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_line_part_counts (
    line_id integer NOT NULL,
    part_id integer NOT NULL,
    qty integer NOT NULL
);


--
-- Name: project_line_part_stock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_line_part_stock (
    line_id integer NOT NULL,
    part_id integer NOT NULL,
    received integer DEFAULT 0 NOT NULL,
    issued integer DEFAULT 0 NOT NULL,
    returned integer DEFAULT 0 NOT NULL,
    written_off integer DEFAULT 0 NOT NULL,
    CONSTRAINT ck_project_line_part_stock_issued CHECK ((issued >= 0)),
    CONSTRAINT ck_project_line_part_stock_received CHECK ((received >= 0)),
    CONSTRAINT ck_project_line_part_stock_returned CHECK ((returned >= 0)),
    CONSTRAINT ck_project_line_part_stock_written_off CHECK ((written_off >= 0))
);


--
-- Name: project_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_lines (
    id integer NOT NULL,
    project_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    material character varying(50),
    color character varying(64),
    note text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    mode character varying(8) DEFAULT 'product'::character varying NOT NULL,
    config_key character varying(512) DEFAULT ''::character varying NOT NULL,
    from_finished integer DEFAULT 0 NOT NULL,
    assembled integer DEFAULT 0 NOT NULL,
    received integer DEFAULT 0 NOT NULL,
    issued integer DEFAULT 0 NOT NULL,
    returned integer DEFAULT 0 NOT NULL,
    written_off integer DEFAULT 0 NOT NULL,
    extra_percentages json DEFAULT '{}'::json NOT NULL,
    plan_identity character varying(36),
    part_count_adjustments json,
    CONSTRAINT ck_project_lines_assembled CHECK ((assembled >= 0)),
    CONSTRAINT ck_project_lines_from_finished CHECK ((from_finished >= 0)),
    CONSTRAINT ck_project_lines_issued CHECK ((issued >= 0)),
    CONSTRAINT ck_project_lines_received CHECK ((received >= 0)),
    CONSTRAINT ck_project_lines_returned CHECK ((returned >= 0)),
    CONSTRAINT ck_project_lines_written_off CHECK ((written_off >= 0))
);


--
-- Name: project_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_lines_id_seq OWNED BY public.project_lines.id;


--
-- Name: project_procurement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_procurement (
    project_id integer NOT NULL,
    product_part_id integer NOT NULL,
    quantity_acquired integer DEFAULT 0 NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    color character varying(20),
    status character varying(20) NOT NULL,
    notes text,
    attachments json,
    tags text,
    due_date timestamp without time zone,
    priority character varying(20) NOT NULL,
    url character varying(2048),
    cover_image_filename character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    customer_id integer,
    price double precision,
    contact_id integer,
    stage character varying(16) DEFAULT 'prep'::character varying NOT NULL,
    responsible_id integer,
    auto_eject_enabled boolean DEFAULT false NOT NULL,
    auto_eject_settings json,
    order_print_options json,
    printer_resources json
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: queue_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.queue_sources (
    id integer NOT NULL,
    sha256 character varying(64) NOT NULL,
    size_bytes integer NOT NULL,
    relative_path character varying(512) NOT NULL,
    format character varying(8) NOT NULL,
    state character varying(16) DEFAULT 'ready'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    unreferenced_at timestamp without time zone,
    CONSTRAINT ck_queue_sources_format CHECK (((format)::text = ANY ((ARRAY['3mf'::character varying, 'gcode'::character varying])::text[]))),
    CONSTRAINT ck_queue_sources_sha256_length CHECK ((length((sha256)::text) = 64)),
    CONSTRAINT ck_queue_sources_size_bytes_non_negative CHECK ((size_bytes >= 0)),
    CONSTRAINT ck_queue_sources_state CHECK (((state)::text = ANY ((ARRAY['ready'::character varying, 'deleting'::character varying, 'broken'::character varying])::text[])))
);


--
-- Name: queue_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.queue_sources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: queue_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.queue_sources_id_seq OWNED BY public.queue_sources.id;


--
-- Name: scheduled_dryings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_dryings (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    ams_id integer NOT NULL,
    temp integer NOT NULL,
    duration_hours integer NOT NULL,
    filament character varying(50) DEFAULT ''::character varying NOT NULL,
    rotate_tray boolean DEFAULT false NOT NULL,
    schedule_id integer,
    start_after timestamp without time zone,
    latest_start timestamp without time zone,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    reason character varying(40),
    detail text,
    created_by_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


--
-- Name: scheduled_dryings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scheduled_dryings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scheduled_dryings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scheduled_dryings_id_seq OWNED BY public.scheduled_dryings.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: slicer_pipelines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slicer_pipelines (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description character varying(1000),
    printer_preset_source character varying(20) NOT NULL,
    printer_preset_id character varying(200) NOT NULL,
    process_preset_source character varying(20) NOT NULL,
    process_preset_id character varying(200) NOT NULL,
    filament_presets_json text NOT NULL,
    bed_type character varying(64),
    created_by integer,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: slicer_pipelines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.slicer_pipelines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: slicer_pipelines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.slicer_pipelines_id_seq OWNED BY public.slicer_pipelines.id;


--
-- Name: smart_plug_energy_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_plug_energy_snapshots (
    id integer NOT NULL,
    plug_id integer NOT NULL,
    recorded_at timestamp without time zone NOT NULL,
    lifetime_kwh double precision NOT NULL
);


--
-- Name: smart_plug_energy_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_plug_energy_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_plug_energy_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_plug_energy_snapshots_id_seq OWNED BY public.smart_plug_energy_snapshots.id;


--
-- Name: smart_plug_meter_incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_plug_meter_incidents (
    id integer NOT NULL,
    plug_id integer NOT NULL,
    source_id character varying(32) NOT NULL,
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    opened_at timestamp without time zone NOT NULL,
    flat_since timestamp without time zone NOT NULL,
    flat_until timestamp without time zone NOT NULL,
    total_kwh double precision NOT NULL,
    evidence json,
    notified boolean DEFAULT false NOT NULL,
    closed_at timestamp without time zone,
    close_reason character varying(32),
    CONSTRAINT ck_meter_incidents_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: smart_plug_meter_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_plug_meter_incidents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_plug_meter_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_plug_meter_incidents_id_seq OWNED BY public.smart_plug_meter_incidents.id;


--
-- Name: smart_plug_power_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_plug_power_history (
    id bigint NOT NULL,
    plug_id integer NOT NULL,
    power double precision NOT NULL,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    unusable_reason character varying(32)
);


--
-- Name: smart_plug_power_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_plug_power_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_plug_power_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_plug_power_history_id_seq OWNED BY public.smart_plug_power_history.id;


--
-- Name: smart_plugs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_plugs (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    ip_address character varying(45),
    plug_type character varying(20) NOT NULL,
    ha_entity_id character varying(100),
    ha_power_entity character varying(100),
    ha_energy_today_entity character varying(100),
    ha_energy_total_entity character varying(100),
    mqtt_topic character varying(200),
    mqtt_power_topic character varying(200),
    mqtt_power_path character varying(100),
    mqtt_power_multiplier double precision NOT NULL,
    mqtt_energy_topic character varying(200),
    mqtt_energy_path character varying(100),
    mqtt_energy_multiplier double precision NOT NULL,
    mqtt_state_topic character varying(200),
    mqtt_state_path character varying(100),
    mqtt_state_on_value character varying(50),
    mqtt_energy_total_topic character varying(200),
    mqtt_energy_total_path character varying(100),
    mqtt_energy_total_multiplier double precision DEFAULT '1'::double precision NOT NULL,
    mqtt_command_topic character varying(200),
    mqtt_command_on text,
    mqtt_command_off text,
    mqtt_multiplier double precision NOT NULL,
    rest_on_url character varying(500),
    rest_on_body text,
    rest_off_url character varying(500),
    rest_off_body text,
    rest_method character varying(10),
    rest_headers text,
    rest_status_url character varying(500),
    rest_status_path character varying(200),
    rest_status_on_value character varying(50),
    rest_power_url character varying(500),
    rest_power_path character varying(200),
    rest_power_multiplier double precision NOT NULL,
    rest_energy_url character varying(500),
    rest_energy_path character varying(200),
    rest_energy_multiplier double precision NOT NULL,
    rest_energy_total_path character varying(200),
    rest_energy_total_multiplier double precision DEFAULT '1'::double precision NOT NULL,
    printer_id integer,
    controls_printer_power boolean DEFAULT true NOT NULL,
    enabled boolean NOT NULL,
    auto_on boolean NOT NULL,
    auto_off boolean NOT NULL,
    auto_off_persistent boolean NOT NULL,
    off_delay_mode character varying(20) NOT NULL,
    off_delay_minutes integer NOT NULL,
    off_temp_threshold integer NOT NULL,
    auto_off_after_drying boolean DEFAULT false NOT NULL,
    off_delay_after_drying_minutes integer DEFAULT 10 NOT NULL,
    username character varying(50),
    password character varying(100),
    power_alert_enabled boolean NOT NULL,
    power_alert_high double precision,
    power_alert_low double precision,
    power_alert_last_triggered timestamp without time zone,
    schedule_enabled boolean NOT NULL,
    schedule_on_time character varying(5),
    schedule_off_time character varying(5),
    show_in_switchbar boolean NOT NULL,
    show_on_printer_card boolean NOT NULL,
    last_state character varying(10),
    last_checked timestamp without time zone,
    auto_off_executed boolean NOT NULL,
    auto_off_pending boolean NOT NULL,
    auto_off_pending_since timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    zigbee_ieee character varying(23),
    measurement_source_id character varying(32),
    measurement_source_since timestamp without time zone,
    mqtt_expected_power_interval_seconds integer,
    meter_min_expected_wh double precision,
    phantom_watts_risk boolean,
    meter_watch_cursor timestamp without time zone
);


--
-- Name: smart_plugs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_plugs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_plugs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_plugs_id_seq OWNED BY public.smart_plugs.id;


--
-- Name: smart_sensor_binding_thresholds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_sensor_binding_thresholds (
    id integer NOT NULL,
    binding_id integer NOT NULL,
    kind character varying(32) NOT NULL,
    custom boolean DEFAULT false NOT NULL,
    min_value double precision,
    max_value double precision,
    deadband double precision DEFAULT '0'::double precision NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    state character varying(8) DEFAULT 'ok'::character varying NOT NULL,
    state_since timestamp without time zone,
    notified_at timestamp without time zone
);


--
-- Name: smart_sensor_binding_thresholds_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_sensor_binding_thresholds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_sensor_binding_thresholds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_sensor_binding_thresholds_id_seq OWNED BY public.smart_sensor_binding_thresholds.id;


--
-- Name: smart_sensor_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_sensor_bindings (
    id integer NOT NULL,
    sensor_id integer NOT NULL,
    printer_id integer,
    printer_location_id integer,
    storage_location_id integer,
    display_name character varying(100),
    visible boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    notify_enabled boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_smart_sensor_binding_one_target CHECK ((((
CASE
    WHEN (printer_id IS NOT NULL) THEN 1
    ELSE 0
END +
CASE
    WHEN (printer_location_id IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (storage_location_id IS NOT NULL) THEN 1
    ELSE 0
END) = 1))
);


--
-- Name: smart_sensor_bindings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_sensor_bindings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_sensor_bindings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_sensor_bindings_id_seq OWNED BY public.smart_sensor_bindings.id;


--
-- Name: smart_sensor_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_sensor_history (
    id bigint NOT NULL,
    sensor_id integer NOT NULL,
    sensor_kind character varying(32) NOT NULL,
    value double precision NOT NULL,
    recorded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: smart_sensor_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_sensor_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_sensor_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_sensor_history_id_seq OWNED BY public.smart_sensor_history.id;


--
-- Name: smart_sensor_thresholds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_sensor_thresholds (
    id integer NOT NULL,
    sensor_id integer NOT NULL,
    kind character varying(32) NOT NULL,
    min_value double precision,
    max_value double precision,
    deadband double precision DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    state character varying(8) DEFAULT 'ok'::character varying NOT NULL,
    state_since timestamp without time zone,
    notified_at timestamp without time zone
);


--
-- Name: smart_sensor_thresholds_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_sensor_thresholds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_sensor_thresholds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_sensor_thresholds_id_seq OWNED BY public.smart_sensor_thresholds.id;


--
-- Name: smart_sensors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.smart_sensors (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    zigbee_ieee character varying(23) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    location_id integer,
    silent_since timestamp without time zone,
    silence_notified_at timestamp without time zone,
    printer_id integer
);


--
-- Name: smart_sensors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.smart_sensors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: smart_sensors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.smart_sensors_id_seq OWNED BY public.smart_sensors.id;


--
-- Name: spool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spool (
    id integer NOT NULL,
    material character varying(50) NOT NULL,
    subtype character varying(50),
    color_name character varying(100),
    rgba character varying(8),
    brand character varying(100),
    label_weight integer NOT NULL,
    core_weight integer NOT NULL,
    core_weight_catalog_id integer,
    weight_used double precision NOT NULL,
    weight_used_baseline double precision NOT NULL,
    weight_locked boolean NOT NULL,
    last_scale_weight integer,
    last_weighed_at timestamp without time zone,
    slicer_filament character varying(50),
    slicer_filament_name character varying(100),
    nozzle_temp_min integer,
    nozzle_temp_max integer,
    note character varying(500),
    added_full boolean,
    cost_per_kg double precision,
    last_used timestamp without time zone,
    encode_time timestamp without time zone,
    purchase_date timestamp without time zone,
    filament_diameter character varying(8) NOT NULL,
    lot integer,
    tag_uid character varying(32),
    storage_location character varying(255),
    location_id integer,
    purchase_location character varying(255),
    tray_uuid character varying(32),
    data_origin character varying(20),
    tag_type character varying(20),
    archived_at timestamp without time zone,
    extra_colors character varying(255),
    effect_type character varying(20),
    category character varying(50),
    low_stock_threshold_pct integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    low_stock_notified boolean DEFAULT false NOT NULL,
    filament_family_id character varying(50)
);


--
-- Name: spool_assignment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spool_assignment (
    id integer NOT NULL,
    spool_id integer NOT NULL,
    printer_id integer NOT NULL,
    ams_id integer NOT NULL,
    tray_id integer NOT NULL,
    fingerprint_color character varying(8),
    fingerprint_type character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: spool_assignment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spool_assignment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spool_assignment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spool_assignment_id_seq OWNED BY public.spool_assignment.id;


--
-- Name: spool_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spool_catalog (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    weight integer NOT NULL,
    is_default boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: spool_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spool_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spool_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spool_catalog_id_seq OWNED BY public.spool_catalog.id;


--
-- Name: spool_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spool_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spool_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spool_id_seq OWNED BY public.spool.id;


--
-- Name: spool_k_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spool_k_profile (
    id integer NOT NULL,
    spool_id integer NOT NULL,
    printer_id integer NOT NULL,
    extruder integer NOT NULL,
    filament_calibration_id integer NOT NULL,
    auto_linked boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: spool_k_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spool_k_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spool_k_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spool_k_profile_id_seq OWNED BY public.spool_k_profile.id;


--
-- Name: spool_usage_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spool_usage_history (
    id integer NOT NULL,
    spool_id integer NOT NULL,
    printer_id integer,
    print_name character varying(500),
    archive_id integer,
    weight_used double precision NOT NULL,
    percent_used integer NOT NULL,
    status character varying(20) NOT NULL,
    cost double precision,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: spool_usage_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spool_usage_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spool_usage_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spool_usage_history_id_seq OWNED BY public.spool_usage_history.id;


--
-- Name: spoolman_k_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spoolman_k_profile (
    id integer NOT NULL,
    spoolman_spool_id integer NOT NULL,
    printer_id integer NOT NULL,
    extruder integer NOT NULL,
    filament_calibration_id integer NOT NULL,
    auto_linked boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_spoolman_kp_extruder_range CHECK (((extruder >= 0) AND (extruder <= 1)))
);


--
-- Name: spoolman_k_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spoolman_k_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spoolman_k_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spoolman_k_profile_id_seq OWNED BY public.spoolman_k_profile.id;


--
-- Name: spoolman_slot_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spoolman_slot_assignments (
    id integer NOT NULL,
    printer_id integer NOT NULL,
    ams_id integer NOT NULL,
    tray_id integer NOT NULL,
    spoolman_spool_id integer NOT NULL,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_spoolman_slot_ams_id_range CHECK ((((ams_id >= 0) AND (ams_id <= 7)) OR ((ams_id >= 128) AND (ams_id <= 191)) OR (ams_id = 255))),
    CONSTRAINT ck_spoolman_slot_tray_id_range CHECK (((tray_id >= 0) AND (tray_id <= 3)))
);


--
-- Name: spoolman_slot_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.spoolman_slot_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: spoolman_slot_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.spoolman_slot_assignments_id_seq OWNED BY public.spoolman_slot_assignments.id;


--
-- Name: stock_issue_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_issue_lines (
    id integer NOT NULL,
    issue_id integer NOT NULL,
    "position" integer NOT NULL,
    product_id integer,
    product_name character varying(255) NOT NULL,
    sku character varying(64),
    configuration json NOT NULL,
    part_name character varying(512),
    quantity integer NOT NULL,
    CONSTRAINT ck_stock_issue_lines_quantity CHECK ((quantity > 0))
);


--
-- Name: stock_issue_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_issue_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_issue_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_issue_lines_id_seq OWNED BY public.stock_issue_lines.id;


--
-- Name: stock_issues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_issues (
    id integer NOT NULL,
    project_id integer,
    customer_id integer,
    customer_name character varying(255) DEFAULT ''::character varying NOT NULL,
    recipient_name character varying(255),
    recipient_phone character varying(255),
    delivery_method character varying(255),
    delivery_details character varying(255),
    waybill character varying(24),
    note text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    supplier json,
    created_by_name character varying(255),
    order_code character varying(32),
    order_name character varying(255),
    units integer DEFAULT 0 NOT NULL
);


--
-- Name: stock_issues_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_issues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_issues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_issues_id_seq OWNED BY public.stock_issues.id;


--
-- Name: stock_item_choices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_item_choices (
    item_id integer NOT NULL,
    group_id integer NOT NULL,
    option_id integer NOT NULL
);


--
-- Name: stock_item_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_item_movements (
    id integer NOT NULL,
    item_id integer NOT NULL,
    kind character varying(16) NOT NULL,
    delta_on_hand integer DEFAULT 0 NOT NULL,
    delta_reserved integer DEFAULT 0 NOT NULL,
    note text,
    customer_id integer,
    project_id integer,
    project_line_id integer,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    stock_issue_id integer
);


--
-- Name: stock_item_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_item_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_item_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_item_movements_id_seq OWNED BY public.stock_item_movements.id;


--
-- Name: stock_item_part_counts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_item_part_counts (
    item_id integer NOT NULL,
    part_id integer NOT NULL,
    qty integer NOT NULL
);


--
-- Name: stock_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_items (
    id integer NOT NULL,
    product_id integer NOT NULL,
    config_key character varying(512) DEFAULT ''::character varying NOT NULL,
    on_hand integer DEFAULT 0 NOT NULL,
    reserved integer DEFAULT 0 NOT NULL,
    location character varying(64),
    min_qty integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_stock_items_on_hand CHECK ((on_hand >= 0)),
    CONSTRAINT ck_stock_items_reserved CHECK ((reserved >= 0)),
    CONSTRAINT ck_stock_items_reserved_le_on_hand CHECK ((reserved <= on_hand))
);


--
-- Name: stock_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_items_id_seq OWNED BY public.stock_items.id;


--
-- Name: swap_source_declaration_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.swap_source_declaration_audit (
    id integer NOT NULL,
    operation_id character varying(36) NOT NULL,
    action character varying(16) NOT NULL,
    source_kind character varying(16) NOT NULL,
    source_id integer NOT NULL,
    sha256 character varying(64),
    old_value boolean,
    new_value boolean,
    declaration_id character varying(36),
    previous_declaration_id character varying(36),
    actor_id integer,
    actor_label character varying(255) DEFAULT ''::character varying NOT NULL,
    actor_kind character varying(16) NOT NULL,
    revision_before character varying(64),
    revision_after character varying(64),
    request_digest character varying(64),
    jobs json,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: swap_source_declaration_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.swap_source_declaration_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: swap_source_declaration_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.swap_source_declaration_audit_id_seq OWNED BY public.swap_source_declaration_audit.id;


--
-- Name: telegram_chats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.telegram_chats (
    id integer NOT NULL,
    chat_id bigint NOT NULL,
    label character varying(100),
    group_id integer,
    user_id integer,
    is_active boolean NOT NULL,
    notify_events json,
    daily_digest boolean NOT NULL,
    quiet_hours_enabled boolean NOT NULL,
    quiet_hours_start character varying(5),
    quiet_hours_end character varying(5),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    progress_min_duration_minutes integer,
    printer_ids json,
    provider_id integer NOT NULL
);


--
-- Name: telegram_chats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.telegram_chats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: telegram_chats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.telegram_chats_id_seq OWNED BY public.telegram_chats.id;


--
-- Name: user_email_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_email_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    notify_print_start boolean NOT NULL,
    notify_print_complete boolean NOT NULL,
    notify_print_failed boolean NOT NULL,
    notify_print_stopped boolean NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_email_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_email_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_email_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_email_preferences_id_seq OWNED BY public.user_email_preferences.id;


--
-- Name: user_filament_families; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_filament_families (
    id integer NOT NULL,
    filament_id character varying(50) NOT NULL,
    ecosystem character varying(10) NOT NULL,
    alias character varying(200) NOT NULL,
    vendor character varying(200),
    filament_type character varying(50),
    origin character varying(12) NOT NULL,
    orphaned boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_filament_families_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_filament_families_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_filament_families_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_filament_families_id_seq OWNED BY public.user_filament_families.id;


--
-- Name: user_filament_presets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_filament_presets (
    id integer NOT NULL,
    owner_user_id integer,
    ecosystem character varying(10) NOT NULL,
    source character varying(12) NOT NULL,
    cloud_id character varying(64),
    local_preset_id integer,
    name character varying(300) NOT NULL,
    family_filament_id character varying(50),
    base_ref character varying(300),
    vendor character varying(200),
    filament_type character varying(50),
    nozzle_temp_min integer,
    nozzle_temp_max integer,
    updated_time character varying(40),
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    pushed_cloud_id character varying(64),
    pushed_at timestamp without time zone,
    push_dirty boolean DEFAULT false,
    orca_pushed_profile_id character varying(64),
    orca_pushed_at timestamp without time zone,
    orca_push_dirty boolean DEFAULT false,
    orca_pushed_updated_time integer
);


--
-- Name: user_filament_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_filament_presets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_filament_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_filament_presets_id_seq OWNED BY public.user_filament_presets.id;


--
-- Name: user_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_groups (
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: user_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    severity character varying(10) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    printer_id integer,
    printer_name character varying(100),
    extra_data json,
    created_at timestamp without time zone NOT NULL,
    read_at timestamp without time zone
);


--
-- Name: user_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_notifications_id_seq OWNED BY public.user_notifications.id;


--
-- Name: user_oidc_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_oidc_links (
    id integer NOT NULL,
    user_id integer NOT NULL,
    provider_id integer NOT NULL,
    provider_user_id character varying(500) NOT NULL,
    provider_email character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_oidc_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_oidc_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_oidc_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_oidc_links_id_seq OWNED BY public.user_oidc_links.id;


--
-- Name: user_otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_otp_codes (
    id integer NOT NULL,
    user_id integer NOT NULL,
    code_hash character varying(255) NOT NULL,
    attempts integer NOT NULL,
    used boolean NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_otp_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_otp_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_otp_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_otp_codes_id_seq OWNED BY public.user_otp_codes.id;


--
-- Name: user_totp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_totp (
    id integer NOT NULL,
    user_id integer NOT NULL,
    secret character varying(512) NOT NULL,
    is_enabled boolean NOT NULL,
    backup_codes_json text,
    last_totp_counter bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: user_totp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_totp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_totp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_totp_id_seq OWNED BY public.user_totp.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255),
    password_hash character varying(255),
    role character varying(20) NOT NULL,
    auth_source character varying(20) NOT NULL,
    is_active boolean NOT NULL,
    password_changed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cloud_token character varying(500),
    cloud_email character varying(255),
    cloud_region character varying(10),
    cloud_token_invalid_at timestamp without time zone,
    orca_cloud_token character varying(2000),
    orca_cloud_refresh_token character varying(128),
    orca_cloud_expires_at timestamp without time zone,
    orca_cloud_email character varying(255),
    orca_cloud_user_id character varying(64),
    orca_cloud_pending_verifier character varying(64),
    orca_cloud_pending_state character varying(32),
    orca_cloud_pending_at timestamp without time zone,
    cloud_refresh_token character varying(500),
    orca_cloud_scope character varying(128),
    inbox_events json
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: virtual_printers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.virtual_printers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    enabled boolean NOT NULL,
    mode character varying(20) NOT NULL,
    auto_dispatch boolean NOT NULL,
    queue_force_color_match boolean DEFAULT false NOT NULL,
    gcode_injection boolean DEFAULT false NOT NULL,
    model character varying(50),
    access_code character varying(8),
    target_printer_id integer,
    target_folder_id integer,
    bind_ip character varying(45),
    remote_interface_ip character varying(45),
    serial_suffix character varying(9) NOT NULL,
    tailscale_disabled boolean DEFAULT true NOT NULL,
    "position" integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    save_ams_mapping boolean DEFAULT false,
    nozzle_diameter character varying(3) DEFAULT '0.4'::character varying NOT NULL,
    nozzle_flow character varying(20) DEFAULT 'standard'::character varying NOT NULL
);


--
-- Name: virtual_printers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.virtual_printers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: virtual_printers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.virtual_printers_id_seq OWNED BY public.virtual_printers.id;


--
-- Name: zigbee_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.zigbee_devices (
    ieee character varying(23) NOT NULL,
    kind character varying(10) NOT NULL,
    name character varying(100),
    reporting json,
    poll_seconds integer,
    stale_after_seconds integer,
    first_seen_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_seen_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: _migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations ALTER COLUMN id SET DEFAULT nextval('public._migrations_id_seq'::regclass);


--
-- Name: active_print_spoolman id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_print_spoolman ALTER COLUMN id SET DEFAULT nextval('public.active_print_spoolman_id_seq'::regclass);


--
-- Name: ams_labels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_labels ALTER COLUMN id SET DEFAULT nextval('public.ams_labels_id_seq'::regclass);


--
-- Name: ams_sensor_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_sensor_history ALTER COLUMN id SET DEFAULT nextval('public.ams_sensor_history_id_seq'::regclass);


--
-- Name: ams_setting_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_setting_audit ALTER COLUMN id SET DEFAULT nextval('public.ams_setting_audit_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: auth_ephemeral_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_ephemeral_tokens ALTER COLUMN id SET DEFAULT nextval('public.auth_ephemeral_tokens_id_seq'::regclass);


--
-- Name: auth_rate_limit_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_rate_limit_events ALTER COLUMN id SET DEFAULT nextval('public.auth_rate_limit_events_id_seq'::regclass);


--
-- Name: auto_queue_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items ALTER COLUMN id SET DEFAULT nextval('public.auto_queue_items_id_seq'::regclass);


--
-- Name: bug_reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bug_reports ALTER COLUMN id SET DEFAULT nextval('public.bug_reports_id_seq'::regclass);


--
-- Name: calibration_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit ALTER COLUMN id SET DEFAULT nextval('public.calibration_audit_id_seq'::regclass);


--
-- Name: calibration_session id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session ALTER COLUMN id SET DEFAULT nextval('public.calibration_session_id_seq'::regclass);


--
-- Name: cameras id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cameras ALTER COLUMN id SET DEFAULT nextval('public.cameras_id_seq'::regclass);


--
-- Name: cloud_link_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloud_link_audit ALTER COLUMN id SET DEFAULT nextval('public.cloud_link_audit_id_seq'::regclass);


--
-- Name: color_catalog id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.color_catalog ALTER COLUMN id SET DEFAULT nextval('public.color_catalog_id_seq'::regclass);


--
-- Name: connector_submission_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_submission_entries ALTER COLUMN id SET DEFAULT nextval('public.connector_submission_entries_id_seq'::regclass);


--
-- Name: connector_submissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_submissions ALTER COLUMN id SET DEFAULT nextval('public.connector_submissions_id_seq'::regclass);


--
-- Name: customer_contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_contacts ALTER COLUMN id SET DEFAULT nextval('public.customer_contacts_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: delivery_methods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_methods ALTER COLUMN id SET DEFAULT nextval('public.delivery_methods_id_seq'::regclass);


--
-- Name: drying_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drying_schedules ALTER COLUMN id SET DEFAULT nextval('public.drying_schedules_id_seq'::regclass);


--
-- Name: external_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_links ALTER COLUMN id SET DEFAULT nextval('public.external_links_id_seq'::regclass);


--
-- Name: filament_calibration id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_calibration ALTER COLUMN id SET DEFAULT nextval('public.filament_calibration_id_seq'::regclass);


--
-- Name: filament_shopping_list id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_shopping_list ALTER COLUMN id SET DEFAULT nextval('public.filament_shopping_list_id_seq'::regclass);


--
-- Name: filament_sku_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_sku_settings ALTER COLUMN id SET DEFAULT nextval('public.filament_sku_settings_id_seq'::regclass);


--
-- Name: firmware_batch_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.firmware_batch_items ALTER COLUMN id SET DEFAULT nextval('public.firmware_batch_items_id_seq'::regclass);


--
-- Name: firmware_batch_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.firmware_batch_runs ALTER COLUMN id SET DEFAULT nextval('public.firmware_batch_runs_id_seq'::regclass);


--
-- Name: firmware_cache_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.firmware_cache_entries ALTER COLUMN id SET DEFAULT nextval('public.firmware_cache_entries_id_seq'::regclass);


--
-- Name: git_backup_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_backup_config ALTER COLUMN id SET DEFAULT nextval('public.git_backup_config_id_seq'::regclass);


--
-- Name: git_backup_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_backup_logs ALTER COLUMN id SET DEFAULT nextval('public.git_backup_logs_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: ha_sensor_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ha_sensor_history ALTER COLUMN id SET DEFAULT nextval('public.ha_sensor_history_id_seq'::regclass);


--
-- Name: hms_muted_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hms_muted_entries ALTER COLUMN id SET DEFAULT nextval('public.hms_muted_entries_id_seq'::regclass);


--
-- Name: kprofile_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kprofile_notes ALTER COLUMN id SET DEFAULT nextval('public.kprofile_notes_id_seq'::regclass);


--
-- Name: label_cassettes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_cassettes ALTER COLUMN id SET DEFAULT nextval('public.label_cassettes_id_seq'::regclass);


--
-- Name: label_devices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_devices ALTER COLUMN id SET DEFAULT nextval('public.label_devices_id_seq'::regclass);


--
-- Name: label_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_jobs ALTER COLUMN id SET DEFAULT nextval('public.label_jobs_id_seq'::regclass);


--
-- Name: label_sheets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_sheets ALTER COLUMN id SET DEFAULT nextval('public.label_sheets_id_seq'::regclass);


--
-- Name: label_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_templates ALTER COLUMN id SET DEFAULT nextval('public.label_templates_id_seq'::regclass);


--
-- Name: library_file_makerworld_meta id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_makerworld_meta ALTER COLUMN id SET DEFAULT nextval('public.library_file_makerworld_meta_id_seq'::regclass);


--
-- Name: library_file_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_notes ALTER COLUMN id SET DEFAULT nextval('public.library_file_notes_id_seq'::regclass);


--
-- Name: library_files id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_files ALTER COLUMN id SET DEFAULT nextval('public.library_files_id_seq'::regclass);


--
-- Name: library_folders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folders ALTER COLUMN id SET DEFAULT nextval('public.library_folders_id_seq'::regclass);


--
-- Name: library_scan_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_scan_jobs ALTER COLUMN id SET DEFAULT nextval('public.library_scan_jobs_id_seq'::regclass);


--
-- Name: library_tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_tags ALTER COLUMN id SET DEFAULT nextval('public.library_tags_id_seq'::regclass);


--
-- Name: local_presets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_presets ALTER COLUMN id SET DEFAULT nextval('public.local_presets_id_seq'::regclass);


--
-- Name: location_ha_sensors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_ha_sensors ALTER COLUMN id SET DEFAULT nextval('public.location_ha_sensors_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: long_lived_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.long_lived_tokens ALTER COLUMN id SET DEFAULT nextval('public.long_lived_tokens_id_seq'::regclass);


--
-- Name: macros id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.macros ALTER COLUMN id SET DEFAULT nextval('public.macros_id_seq'::regclass);


--
-- Name: maintenance_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_history ALTER COLUMN id SET DEFAULT nextval('public.maintenance_history_id_seq'::regclass);


--
-- Name: maintenance_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_types ALTER COLUMN id SET DEFAULT nextval('public.maintenance_types_id_seq'::regclass);


--
-- Name: notification_digest_queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_digest_queue ALTER COLUMN id SET DEFAULT nextval('public.notification_digest_queue_id_seq'::regclass);


--
-- Name: notification_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs ALTER COLUMN id SET DEFAULT nextval('public.notification_logs_id_seq'::regclass);


--
-- Name: notification_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_providers ALTER COLUMN id SET DEFAULT nextval('public.notification_providers_id_seq'::regclass);


--
-- Name: notification_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates ALTER COLUMN id SET DEFAULT nextval('public.notification_templates_id_seq'::regclass);


--
-- Name: oidc_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers ALTER COLUMN id SET DEFAULT nextval('public.oidc_providers_id_seq'::regclass);


--
-- Name: orca_base_profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orca_base_profiles ALTER COLUMN id SET DEFAULT nextval('public.orca_base_profiles_id_seq'::regclass);


--
-- Name: plate_render_objects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_render_objects ALTER COLUMN id SET DEFAULT nextval('public.plate_render_objects_id_seq'::regclass);


--
-- Name: plate_renders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_renders ALTER COLUMN id SET DEFAULT nextval('public.plate_renders_id_seq'::regclass);


--
-- Name: print_archive_parts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archive_parts ALTER COLUMN id SET DEFAULT nextval('public.print_archive_parts_id_seq'::regclass);


--
-- Name: print_archives id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives ALTER COLUMN id SET DEFAULT nextval('public.print_archives_id_seq'::regclass);


--
-- Name: print_completion_receipts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_completion_receipts ALTER COLUMN id SET DEFAULT nextval('public.print_completion_receipts_id_seq'::regclass);


--
-- Name: print_options_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_options_preferences ALTER COLUMN id SET DEFAULT nextval('public.print_options_preferences_id_seq'::regclass);


--
-- Name: print_queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue ALTER COLUMN id SET DEFAULT nextval('public.print_queue_id_seq'::regclass);


--
-- Name: print_usage_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_usage_events ALTER COLUMN id SET DEFAULT nextval('public.print_usage_events_id_seq'::regclass);


--
-- Name: printer_ha_sensors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_ha_sensors ALTER COLUMN id SET DEFAULT nextval('public.printer_ha_sensors_id_seq'::regclass);


--
-- Name: printer_locations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_locations ALTER COLUMN id SET DEFAULT nextval('public.printer_locations_id_seq'::regclass);


--
-- Name: printer_maintenance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_maintenance ALTER COLUMN id SET DEFAULT nextval('public.printer_maintenance_id_seq'::regclass);


--
-- Name: printer_queues id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_queues ALTER COLUMN id SET DEFAULT nextval('public.printer_queues_id_seq'::regclass);


--
-- Name: printer_sensor_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_sensor_history ALTER COLUMN id SET DEFAULT nextval('public.printer_sensor_history_id_seq'::regclass);


--
-- Name: printer_setting_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_setting_audit ALTER COLUMN id SET DEFAULT nextval('public.printer_setting_audit_id_seq'::regclass);


--
-- Name: printer_tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_tags ALTER COLUMN id SET DEFAULT nextval('public.printer_tags_id_seq'::regclass);


--
-- Name: printers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printers ALTER COLUMN id SET DEFAULT nextval('public.printers_id_seq'::regclass);


--
-- Name: product_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories ALTER COLUMN id SET DEFAULT nextval('public.product_categories_id_seq'::regclass);


--
-- Name: product_part_stock_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_part_stock_movements ALTER COLUMN id SET DEFAULT nextval('public.product_part_stock_movements_id_seq'::regclass);


--
-- Name: product_parts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parts ALTER COLUMN id SET DEFAULT nextval('public.product_parts_id_seq'::regclass);


--
-- Name: product_plates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_plates ALTER COLUMN id SET DEFAULT nextval('public.product_plates_id_seq'::regclass);


--
-- Name: product_variant_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_groups ALTER COLUMN id SET DEFAULT nextval('public.product_variant_groups_id_seq'::regclass);


--
-- Name: product_variant_options id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_options ALTER COLUMN id SET DEFAULT nextval('public.product_variant_options_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: project_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_events ALTER COLUMN id SET DEFAULT nextval('public.project_events_id_seq'::regclass);


--
-- Name: project_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lines ALTER COLUMN id SET DEFAULT nextval('public.project_lines_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: queue_sources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queue_sources ALTER COLUMN id SET DEFAULT nextval('public.queue_sources_id_seq'::regclass);


--
-- Name: scheduled_dryings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_dryings ALTER COLUMN id SET DEFAULT nextval('public.scheduled_dryings_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: slicer_pipelines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slicer_pipelines ALTER COLUMN id SET DEFAULT nextval('public.slicer_pipelines_id_seq'::regclass);


--
-- Name: smart_plug_energy_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_energy_snapshots ALTER COLUMN id SET DEFAULT nextval('public.smart_plug_energy_snapshots_id_seq'::regclass);


--
-- Name: smart_plug_meter_incidents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_meter_incidents ALTER COLUMN id SET DEFAULT nextval('public.smart_plug_meter_incidents_id_seq'::regclass);


--
-- Name: smart_plug_power_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_power_history ALTER COLUMN id SET DEFAULT nextval('public.smart_plug_power_history_id_seq'::regclass);


--
-- Name: smart_plugs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plugs ALTER COLUMN id SET DEFAULT nextval('public.smart_plugs_id_seq'::regclass);


--
-- Name: smart_sensor_binding_thresholds id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_binding_thresholds ALTER COLUMN id SET DEFAULT nextval('public.smart_sensor_binding_thresholds_id_seq'::regclass);


--
-- Name: smart_sensor_bindings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_bindings ALTER COLUMN id SET DEFAULT nextval('public.smart_sensor_bindings_id_seq'::regclass);


--
-- Name: smart_sensor_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_history ALTER COLUMN id SET DEFAULT nextval('public.smart_sensor_history_id_seq'::regclass);


--
-- Name: smart_sensor_thresholds id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_thresholds ALTER COLUMN id SET DEFAULT nextval('public.smart_sensor_thresholds_id_seq'::regclass);


--
-- Name: smart_sensors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensors ALTER COLUMN id SET DEFAULT nextval('public.smart_sensors_id_seq'::regclass);


--
-- Name: spool id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool ALTER COLUMN id SET DEFAULT nextval('public.spool_id_seq'::regclass);


--
-- Name: spool_assignment id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_assignment ALTER COLUMN id SET DEFAULT nextval('public.spool_assignment_id_seq'::regclass);


--
-- Name: spool_catalog id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_catalog ALTER COLUMN id SET DEFAULT nextval('public.spool_catalog_id_seq'::regclass);


--
-- Name: spool_k_profile id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_k_profile ALTER COLUMN id SET DEFAULT nextval('public.spool_k_profile_id_seq'::regclass);


--
-- Name: spool_usage_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_usage_history ALTER COLUMN id SET DEFAULT nextval('public.spool_usage_history_id_seq'::regclass);


--
-- Name: spoolman_k_profile id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_k_profile ALTER COLUMN id SET DEFAULT nextval('public.spoolman_k_profile_id_seq'::regclass);


--
-- Name: spoolman_slot_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_slot_assignments ALTER COLUMN id SET DEFAULT nextval('public.spoolman_slot_assignments_id_seq'::regclass);


--
-- Name: stock_issue_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_issue_lines ALTER COLUMN id SET DEFAULT nextval('public.stock_issue_lines_id_seq'::regclass);


--
-- Name: stock_issues id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_issues ALTER COLUMN id SET DEFAULT nextval('public.stock_issues_id_seq'::regclass);


--
-- Name: stock_item_movements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_item_movements_id_seq'::regclass);


--
-- Name: stock_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_items ALTER COLUMN id SET DEFAULT nextval('public.stock_items_id_seq'::regclass);


--
-- Name: swap_source_declaration_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swap_source_declaration_audit ALTER COLUMN id SET DEFAULT nextval('public.swap_source_declaration_audit_id_seq'::regclass);


--
-- Name: telegram_chats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats ALTER COLUMN id SET DEFAULT nextval('public.telegram_chats_id_seq'::regclass);


--
-- Name: user_email_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_email_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_email_preferences_id_seq'::regclass);


--
-- Name: user_filament_families id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_filament_families ALTER COLUMN id SET DEFAULT nextval('public.user_filament_families_id_seq'::regclass);


--
-- Name: user_filament_presets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_filament_presets ALTER COLUMN id SET DEFAULT nextval('public.user_filament_presets_id_seq'::regclass);


--
-- Name: user_notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notifications ALTER COLUMN id SET DEFAULT nextval('public.user_notifications_id_seq'::regclass);


--
-- Name: user_oidc_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links ALTER COLUMN id SET DEFAULT nextval('public.user_oidc_links_id_seq'::regclass);


--
-- Name: user_otp_codes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_otp_codes ALTER COLUMN id SET DEFAULT nextval('public.user_otp_codes_id_seq'::regclass);


--
-- Name: user_totp id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_totp ALTER COLUMN id SET DEFAULT nextval('public.user_totp_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: virtual_printers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtual_printers ALTER COLUMN id SET DEFAULT nextval('public.virtual_printers_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (id, version, name, applied_at) FROM stdin;
1	0	bambuddy_to_bamdude_301	2026-11-14 23:21:18
2	1	bamdude_baseline	2026-11-14 23:21:19
3	2	bamdude_311	2026-11-14 23:21:19
4	3	enforce_admin_user	2026-11-14 23:21:19
5	4	m002_reconcile	2026-11-14 23:21:19
6	5	swap_profiles	2026-11-14 23:21:19
7	6	mesh_mode_fast_check	2026-11-14 23:21:19
8	7	drop_vibration_cali	2026-11-14 23:21:19
9	8	swap_macro_queue_fields	2026-11-14 23:21:19
10	9	archive_source_hash	2026-11-14 23:21:19
11	10	queue_reliability	2026-11-14 23:21:19
12	11	cloud_region	2026-11-14 23:21:19
13	12	mfa	2026-11-14 23:21:19
14	13	library_file_print_count	2026-11-14 23:21:19
15	14	archive_library_link	2026-11-14 23:21:19
16	15	refresh_token_support	2026-11-14 23:21:19
17	16	project_print_plan	2026-11-14 23:21:19
18	17	macro_action_type	2026-11-14 23:21:19
19	18	queue_library_fk_set_null	2026-11-14 23:21:19
20	19	archive_queue_batch_error	2026-11-14 23:21:19
21	20	spool_purchase_date	2026-11-14 23:21:19
22	21	drop_auto_light_off	2026-11-14 23:21:19
23	22	label_object_metadata_backfill	2026-11-14 23:21:19
24	23	per_plate_metadata_backfill	2026-11-14 23:21:19
25	24	auto_queue	2026-11-14 23:21:19
26	25	settings_dedupe	2026-11-14 23:21:19
27	26	spool_extensions	2026-11-14 23:21:19
28	27	project_url_and_cover	2026-11-14 23:21:19
29	28	long_lived_tokens	2026-11-14 23:21:19
30	29	library_trash	2026-11-14 23:21:19
31	30	vp_tailscale	2026-11-14 23:21:19
32	31	oidc_email_claim	2026-11-14 23:21:19
33	32	gcode_injection	2026-11-14 23:21:19
34	33	library_file_source	2026-11-14 23:21:19
35	34	archive_trash	2026-11-14 23:21:19
36	35	normalize_file_type	2026-11-14 23:21:19
37	36	library_file_tags	2026-11-14 23:21:19
38	37	project_geometry_tags	2026-11-14 23:21:19
39	38	archive_plate_index	2026-11-14 23:21:19
40	39	archive_source_hash_backfill	2026-11-14 23:21:19
41	40	vp_target_folder	2026-11-14 23:21:19
42	41	drain_pending_and_purge_archived	2026-11-14 23:21:19
43	42	drop_pending_uploads	2026-11-14 23:21:19
44	43	print_options_preferences	2026-11-14 23:21:19
45	44	library_project_pivots	2026-11-14 23:21:19
46	45	telegram_config_refactor	2026-11-14 23:21:19
47	46	normalize_group_permissions	2026-11-14 23:21:19
48	47	external_camera_snapshot_url	2026-11-14 23:21:19
49	48	backfill_print_plan_from_pivots	2026-11-14 23:21:19
50	49	api_key_owner_and_cloud_scope	2026-11-14 23:21:19
51	50	vp_queue_force_color_match	2026-11-14 23:21:19
52	51	oidc_default_group	2026-11-14 23:21:19
53	52	notification_pause_resume_events	2026-11-14 23:21:19
54	53	spoolman_inventory_tables	2026-11-14 23:21:19
55	54	bug_reports	2026-11-14 23:21:19
56	55	external_link_nav_group	2026-11-14 23:21:19
57	56	library_file_makerworld_meta	2026-11-14 23:21:20
58	57	archive_bed_type	2026-11-14 23:21:20
59	58	settings_dedupe_unique_key	2026-11-14 23:21:20
60	59	stock_forecasting	2026-11-14 23:21:20
61	60	ams_setting_audit	2026-11-14 23:21:20
62	61	printer_setting_audit	2026-11-14 23:21:20
63	62	filament_calibration	2026-11-14 23:21:20
64	63	filament_calibration_per_printer	2026-11-14 23:21:20
65	64	spool_kprofile_link_table	2026-11-14 23:21:20
66	65	kprofile_notes_rekey	2026-11-14 23:21:20
67	66	auto_queue_archive_flag	2026-11-14 23:21:20
68	67	printer_queue_is_paused	2026-11-14 23:21:20
69	68	printer_queue_completed_event	2026-11-14 23:21:20
70	69	filament_calibration_tower_result	2026-11-14 23:21:20
71	70	calibration_session_dispatch_args	2026-11-14 23:21:20
72	71	oidc_icon_cache	2026-11-14 23:21:20
73	72	orphan_auth_cleanup	2026-11-14 23:21:20
74	73	api_key_energy_cost_scope	2026-11-14 23:21:20
75	74	spoolman_slot_ams_id_range_widen	2026-11-14 23:21:20
76	75	spool_weight_used_baseline	2026-11-14 23:21:20
77	76	color_catalog_extra_colors	2026-11-14 23:21:20
78	77	smart_plug_drying_auto_off	2026-11-14 23:21:20
79	78	print_options_pref_system_row	2026-11-14 23:21:20
80	79	kprofile_autolink	2026-11-14 23:21:20
81	80	library_drop_print_name	2026-11-14 23:21:20
82	81	firmware_batch_and_cache	2026-11-14 23:21:20
83	82	firmware_batch_source	2026-11-14 23:21:20
84	83	backfill_failed_print_filament	2026-11-14 23:21:20
85	84	null_orphaned_usage_history_archive_id	2026-11-14 23:21:20
86	85	spool_purchase_location	2026-11-14 23:21:20
87	86	apikey_library_inventory_scopes	2026-11-14 23:21:20
88	87	vp_access_code_sync	2026-11-14 23:21:20
89	88	print_queue_nozzle_offset_cali	2026-11-14 23:21:20
90	89	archive_bamdude_forced_timelapse	2026-11-14 23:21:20
91	90	user_orca_cloud_credentials	2026-11-14 23:21:20
92	91	ownership_read_split_backfill	2026-11-14 23:21:20
93	92	printer_sensor_history	2026-11-14 23:21:20
94	93	storage_locations_catalog	2026-11-14 23:21:20
95	94	forecast_color_grouping	2026-11-14 23:21:20
96	95	library_user_tags	2026-11-14 23:21:20
97	96	oidc_provider_autologin	2026-11-14 23:21:20
98	97	ai_failure_detection_event	2026-11-14 23:21:20
99	98	print_queue_nozzle_mapping	2026-11-14 23:21:20
100	99	virtual_printer_gcode_injection	2026-11-14 23:21:20
101	100	backfill_archive_created_at	2026-11-14 23:21:20
102	101	spoolman_tray_remain_start	2026-11-14 23:21:20
103	102	slicer_pipelines	2026-11-14 23:21:20
104	103	print_queue_preheat_override	2026-11-14 23:21:20
105	104	api_key_management_scopes	2026-11-14 23:21:20
106	105	printer_archived	2026-11-14 23:21:20
107	106	print_queue_calibration_modes	2026-11-14 23:21:20
108	107	archive_actual_time_columns	2026-11-14 23:21:20
109	108	print_queue_dispatch_attempts	2026-11-14 23:21:20
110	109	user_cloud_token_invalid_at	2026-11-14 23:21:20
111	110	smart_plug_power_and_energy	2026-11-14 23:21:20
112	111	makerworld_permission_backfill	2026-11-14 23:21:20
113	112	drop_pipeline_runs	2026-11-14 23:21:20
114	113	mqtt_plug_control	2026-11-14 23:21:20
115	114	skip_objects_supported	2026-11-14 23:21:20
116	115	zigbee_plug	2026-11-14 23:44:44.425336
117	116	require_previous_success	2026-11-14 23:44:44.44453
118	117	low_stock_notified	2026-11-14 23:44:44.457632
119	118	stock_break_notified	2026-11-14 23:44:44.471341
120	119	stock_reorder_notified	2026-11-14 23:44:44.484828
121	120	clear_queues	2026-11-14 23:44:44.511938
122	121	backfill_bed_temperature	2026-11-14 23:44:44.722856
123	122	archive_defective_count	2026-11-14 23:44:44.732118
124	123	zigbee_device_settings	2026-11-14 23:44:45.002275
125	124	printer_locations	2026-11-14 23:44:45.074886
126	125	measurement_history	2026-11-14 23:44:45.09888
127	126	location_hierarchy	2026-11-14 23:44:45.118574
128	127	sensor_thresholds	2026-11-14 23:44:45.18013
129	128	library_system_tags	2026-11-14 23:44:45.208916
130	129	library_fs_modified_at	2026-11-14 23:44:45.218667
131	130	oidc_env_managed	2026-11-14 23:44:45.227545
132	131	vp_save_ams_mapping	2026-11-14 23:44:45.236344
133	132	plate_total_layers	2026-11-14 23:44:45.243225
134	133	one_folder_per_archive	2026-11-14 23:44:45.252598
135	134	macro_action_param_and_layer	2026-11-14 23:44:45.26555
136	135	queue_selected_macros	2026-11-14 23:44:45.275652
137	136	timelapse_storage_choice	2026-11-14 23:44:45.285473
138	137	sliced_by_content_backfill	2026-11-14 23:44:45.295261
139	138	repair_ams_sync_full_spool_writes	2026-11-14 23:44:45.307586
140	139	mqtt_recording_state	2026-11-14 23:44:45.322901
141	140	library_file_hash_index	2026-11-14 23:44:45.330889
142	141	dedupe_existing_library_files	2026-11-14 23:44:45.358826
143	142	notification_filament_deficit	2026-11-14 23:44:45.376811
144	143	notification_ams_drying_suspended	2026-11-14 23:44:45.394558
145	144	smart_sensor_printer_binding	2026-11-14 23:44:45.404228
146	145	users_read_slim_permission	2026-11-14 23:44:45.414116
147	146	label_templates	2026-11-14 23:44:45.472159
148	147	device_direct_labels	2026-11-14 23:44:45.520882
149	148	library_scan_jobs	2026-11-14 23:44:45.542661
150	149	filament_families	2026-11-14 23:44:45.587239
151	150	drop_retired_identity	2026-11-14 23:44:45.605733
152	151	filament_push_metadata	2026-11-14 23:44:45.617878
153	152	cloud_refresh_token	2026-11-14 23:44:45.626387
154	153	print_usage_events	2026-11-14 23:44:45.645619
155	154	orca_push_bookkeeping	2026-11-14 23:44:45.660782
156	155	cloud_link	2026-11-14 23:44:45.692033
157	156	auto_queue_nozzle_mapping	2026-11-14 23:44:45.699842
158	157	notifications_rework	2026-11-14 23:44:45.831018
159	158	products_and_orders	2026-11-14 23:44:46.937599
160	159	forecast_usage_index	2026-11-14 23:44:46.94737
161	160	print_queue_origin	2026-11-14 23:44:46.959661
162	161	usage_event_slot_occupied	2026-11-14 23:44:46.969327
163	162	product_part_stock	2026-11-14 23:44:46.994784
164	163	hms_muted_entries	2026-11-14 23:44:47.013305
165	164	printer_tags	2026-11-14 23:44:47.0357
166	165	printer_tag_color	2026-11-14 23:44:47.044596
167	166	orders_from_files	2026-11-14 23:44:47.060077
168	167	api_key_column_widths	2026-11-14 23:44:47.078972
169	168	hot_path_indexes	2026-11-14 23:44:47.095081
170	169	auto_queue_filament_routing	2026-11-14 23:44:47.110869
171	170	monitor_wait_reasons	2026-11-14 23:44:47.123387
172	171	auto_queue_rebalance	2026-11-14 23:44:47.135402
173	172	restore_lost_indexes	2026-11-14 23:44:47.148891
174	173	queue_sources	2026-11-14 23:44:47.199157
175	174	auto_queue_base_material_match	2026-11-14 23:44:47.209418
176	175	printer_ams_policies	2026-11-14 23:44:47.220523
177	176	user_inbox	2026-11-14 23:44:47.249553
178	177	data_dir_roots	2026-11-14 23:44:47.262542
179	178	printer_camera_light_auto	2026-11-14 23:44:47.271078
180	179	cameras	2026-11-14 23:44:47.289167
181	180	telegram_chat_provider	2026-11-14 23:44:47.314343
182	181	stagger_group_overrides	2026-11-14 23:44:47.329751
183	182	completion_receipts	2026-11-14 23:44:47.353579
184	183	rfid_core_weight_repair	2026-11-14 23:44:47.433059
185	184	scheduled_drying	2026-11-14 23:44:47.474406
186	185	drop_ams_slot_locations	2026-11-14 23:44:47.560289
187	186	failure_reason_vocabulary	2026-11-14 23:44:47.576721
188	187	print_queue_nozzle_rack_choice	2026-11-14 23:44:47.585834
189	188	home_assistant_sensor_bindings	2026-11-14 23:44:47.648545
190	189	zigbee_sensor_bindings	2026-11-14 23:44:47.698905
191	190	customer_contacts	2026-11-14 23:44:47.759971
192	191	order_stage_journal	2026-11-14 23:44:48.141768
193	192	a2l_swap_profile	2026-11-14 23:44:48.152604
194	193	projects_file_prints	2026-11-14 23:44:48.163116
195	194	workshop_permissions	2026-11-14 23:44:48.175344
196	195	bom_extra_percent	2026-11-14 23:44:48.188146
197	197	order_auto_eject	2026-11-14 23:44:48.203089
198	198	auto_eject_camera_settings	2026-11-14 23:44:48.214967
199	199	order_print_options	2026-11-14 23:44:48.225458
200	200	plate_detection_polygon	2026-11-14 23:44:48.233826
201	201	part_renders	2026-11-14 23:44:48.26126
202	202	part_images	2026-11-14 23:44:48.284403
203	203	swap_source_declaration	2026-11-14 23:44:48.319385
204	204	print_state_recovery	2026-11-14 23:44:48.351465
205	205	farm_resume_permission	2026-11-14 23:44:48.361917
206	206	order_working_plans	2026-11-14 23:44:48.414185
207	207	archive_dispatch_phase	2026-11-14 23:44:48.432096
208	208	queue_error_code	2026-11-14 23:44:48.442596
209	209	order_printer_resources	2026-11-14 23:44:48.453661
210	210	order_part_recounts	2026-11-14 23:44:48.465817
211	211	plug_meter_watch	2026-11-14 23:44:48.527197
212	212	mcp_key_opt_in	2026-11-14 23:44:48.538887
213	213	virtual_printer_nozzle	2026-11-14 23:44:48.549267
214	214	generic_cream_color	2026-11-14 23:44:48.595194
215	215	obico_history	2026-11-14 23:44:48.617368
216	216	connector_identity	2026-11-14 23:44:48.694356
217	217	job_lineage	2026-11-14 23:44:48.740894
218	218	account_mail_default_bodies	2026-11-14 23:44:48.753863
219	219	credential_config_guard	2026-11-14 23:44:48.760976
220	220	auth_remember_me	2026-11-14 23:44:48.77109
\.


--
-- Data for Name: active_print_spoolman; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.active_print_spoolman (id, printer_id, archive_id, filament_usage, ams_trays, slot_to_tray, layer_usage, filament_properties, tray_remain_start) FROM stdin;
\.


--
-- Data for Name: ams_labels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ams_labels (id, ams_serial_number, ams_id, label, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ams_sensor_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ams_sensor_history (id, printer_id, ams_id, humidity, humidity_raw, temperature, recorded_at) FROM stdin;
\.


--
-- Data for Name: ams_setting_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ams_setting_audit (id, printer_id, user_id, action, payload_json, sequence_id, result, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_keys (id, name, key_hash, key_prefix, user_id, can_queue, can_control_printer, can_read_status, can_access_cloud, can_update_energy_cost, can_manage_library, can_manage_inventory, can_manage_maintenance, can_manage_archives, can_manage_projects, printer_ids, enabled, last_used, created_at, expires_at, can_print_labels, can_access_mcp, can_read_mcp_logs, connector_identity) FROM stdin;
\.


--
-- Data for Name: auth_ephemeral_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_ephemeral_tokens (id, token, token_type, username, provider_id, nonce, code_verifier, challenge_id, used_at, family_id, expires_at, created_at, remember_me) FROM stdin;
\.


--
-- Data for Name: auth_rate_limit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_rate_limit_events (id, username, event_type, occurred_at) FROM stdin;
\.


--
-- Data for Name: auto_queue_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auto_queue_items (id, archive_id, library_file_id, project_id, target_model, required_filament_types, filament_overrides, force_color_match, plate_id, bed_levelling, flow_cali, layer_inspect, timelapse, use_ams, mesh_mode_fast_check, gcode_injection, execute_swap_macros, swap_macro_events, "position", scheduled_time, manual_start, auto_off_after, require_previous_success, status, waiting_reason, assigned_to_item_id, assigned_at, cancelled_at, print_time_seconds, been_jumped, batch_id, created_at, created_by_id, target_location_id, selected_macro_ids, timelapse_storage, nozzle_mapping, project_line_id, feed_policy, rebalanced_at, rebalanced_from_model, queue_source_id, source_snapshot, allow_base_material_match, auto_eject, auto_eject_settings, order_print_options, swap_declaration_identity, recovery_identity) FROM stdin;
\.


--
-- Data for Name: bug_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bug_reports (id, description, reporter_email, github_issue_number, github_issue_url, status, error_message, email_sent, created_at) FROM stdin;
\.


--
-- Data for Name: calibration_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calibration_audit (id, printer_id, session_id, filament_calibration_id, user_id, action, payload_json, sequence_id, result, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: calibration_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calibration_session (id, printer_id, user_id, cali_mode, method, nozzle_diameter, nozzle_volume_type, extruder_id, filaments_json, status, mqtt_sequence_id, print_queue_item_id, parent_session_id, stage, coarse_ratio, dispatch_args_json, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cameras; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cameras (id, name, camera_type, url, snapshot_url, rotation, enabled, location_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cloud_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cloud_link (id, enabled, portal_url, instance_id, instance_secret_encrypted, last_connected_at, last_error, revoked) FROM stdin;
\.


--
-- Data for Name: cloud_link_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cloud_link_audit (id, ts, direction, kind, summary, ok) FROM stdin;
\.


--
-- Data for Name: cloud_link_printers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cloud_link_printers (printer_id) FROM stdin;
\.


--
-- Data for Name: color_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.color_catalog (id, manufacturer, color_name, hex_color, material, is_default, extra_colors, effect_type, created_at) FROM stdin;
1	Bambu Lab	Jade White	#FFFFFF	PLA Basic	t	\N	\N	2026-11-14 23:21:19
2	Bambu Lab	Black	#000000	PLA Basic	t	\N	\N	2026-11-14 23:21:19
3	Bambu Lab	Silver	#A6A9AA	PLA Basic	t	\N	\N	2026-11-14 23:21:19
4	Bambu Lab	Light Gray	#D1D3D5	PLA Basic	t	\N	\N	2026-11-14 23:21:19
5	Bambu Lab	Gray	#8E9089	PLA Basic	t	\N	\N	2026-11-14 23:21:19
6	Bambu Lab	Dark Gray	#545454	PLA Basic	t	\N	\N	2026-11-14 23:21:19
7	Bambu Lab	Red	#C12E1F	PLA Basic	t	\N	\N	2026-11-14 23:21:19
8	Bambu Lab	Maroon Red	#9D2235	PLA Basic	t	\N	\N	2026-11-14 23:21:19
9	Bambu Lab	Magenta	#EC008C	PLA Basic	t	\N	\N	2026-11-14 23:21:19
10	Bambu Lab	Hot Pink	#F5547C	PLA Basic	t	\N	\N	2026-11-14 23:21:19
11	Bambu Lab	Pink	#F55A74	PLA Basic	t	\N	\N	2026-11-14 23:21:19
12	Bambu Lab	Beige	#F7E6DE	PLA Basic	t	\N	\N	2026-11-14 23:21:19
13	Bambu Lab	Yellow	#F4EE2A	PLA Basic	t	\N	\N	2026-11-14 23:21:19
14	Bambu Lab	Sunflower Yellow	#FEC600	PLA Basic	t	\N	\N	2026-11-14 23:21:19
15	Bambu Lab	Gold	#E4BD68	PLA Basic	t	\N	\N	2026-11-14 23:21:19
16	Bambu Lab	Orange	#FF6A13	PLA Basic	t	\N	\N	2026-11-14 23:21:19
17	Bambu Lab	Pumpkin Orange	#FF9016	PLA Basic	t	\N	\N	2026-11-14 23:21:19
18	Bambu Lab	Bright Green	#BECF00	PLA Basic	t	\N	\N	2026-11-14 23:21:19
19	Bambu Lab	Bambu Green	#00AE42	PLA Basic	t	\N	\N	2026-11-14 23:21:19
20	Bambu Lab	Mistletoe Green	#3F8E43	PLA Basic	t	\N	\N	2026-11-14 23:21:19
21	Bambu Lab	Turquoise	#00B1B7	PLA Basic	t	\N	\N	2026-11-14 23:21:19
22	Bambu Lab	Cyan	#0086D6	PLA Basic	t	\N	\N	2026-11-14 23:21:19
23	Bambu Lab	Blue	#0A2989	PLA Basic	t	\N	\N	2026-11-14 23:21:19
24	Bambu Lab	Blue Grey	#5B6579	PLA Basic	t	\N	\N	2026-11-14 23:21:19
25	Bambu Lab	Cobalt Blue	#0056B8	PLA Basic	t	\N	\N	2026-11-14 23:21:19
26	Bambu Lab	Purple	#5E43B7	PLA Basic	t	\N	\N	2026-11-14 23:21:19
27	Bambu Lab	Indigo Purple	#482960	PLA Basic	t	\N	\N	2026-11-14 23:21:19
28	Bambu Lab	Brown	#9D432C	PLA Basic	t	\N	\N	2026-11-14 23:21:19
29	Bambu Lab	Cocoa Brown	#6F5034	PLA Basic	t	\N	\N	2026-11-14 23:21:19
30	Bambu Lab	Bronze	#847D48	PLA Basic	t	\N	\N	2026-11-14 23:21:19
31	Bambu Lab	Ivory White	#FFFFFF	PLA Matte	t	\N	\N	2026-11-14 23:21:19
32	Bambu Lab	Bone White	#CBC6B8	PLA Matte	t	\N	\N	2026-11-14 23:21:19
33	Bambu Lab	Desert Tan	#E8DBB7	PLA Matte	t	\N	\N	2026-11-14 23:21:19
34	Bambu Lab	Latte Brown	#D3B7A7	PLA Matte	t	\N	\N	2026-11-14 23:21:19
35	Bambu Lab	Caramel	#AE835B	PLA Matte	t	\N	\N	2026-11-14 23:21:19
36	Bambu Lab	Terracotta	#B15533	PLA Matte	t	\N	\N	2026-11-14 23:21:19
37	Bambu Lab	Dark Brown	#7D6556	PLA Matte	t	\N	\N	2026-11-14 23:21:19
38	Bambu Lab	Dark Chocolate	#4D3324	PLA Matte	t	\N	\N	2026-11-14 23:21:19
39	Bambu Lab	Lilac Purple	#AE96D4	PLA Matte	t	\N	\N	2026-11-14 23:21:19
40	Bambu Lab	Sakura Pink	#E8AFCF	PLA Matte	t	\N	\N	2026-11-14 23:21:19
41	Bambu Lab	Mandarin Orange	#F99963	PLA Matte	t	\N	\N	2026-11-14 23:21:19
42	Bambu Lab	Lemon Yellow	#F7D959	PLA Matte	t	\N	\N	2026-11-14 23:21:19
43	Bambu Lab	Plum	#950051	PLA Matte	t	\N	\N	2026-11-14 23:21:19
44	Bambu Lab	Scarlet Red	#DE4343	PLA Matte	t	\N	\N	2026-11-14 23:21:19
45	Bambu Lab	Dark Red	#BB3D43	PLA Matte	t	\N	\N	2026-11-14 23:21:19
46	Bambu Lab	Dark Green	#68724D	PLA Matte	t	\N	\N	2026-11-14 23:21:19
47	Bambu Lab	Grass Green	#61C680	PLA Matte	t	\N	\N	2026-11-14 23:21:19
48	Bambu Lab	Apple Green	#C2E189	PLA Matte	t	\N	\N	2026-11-14 23:21:19
49	Bambu Lab	Ice Blue	#A3D8E1	PLA Matte	t	\N	\N	2026-11-14 23:21:19
50	Bambu Lab	Sky Blue	#56B7E6	PLA Matte	t	\N	\N	2026-11-14 23:21:19
51	Bambu Lab	Marine Blue	#0078BF	PLA Matte	t	\N	\N	2026-11-14 23:21:19
52	Bambu Lab	Dark Blue	#042F56	PLA Matte	t	\N	\N	2026-11-14 23:21:19
53	Bambu Lab	Ash Gray	#9B9EA0	PLA Matte	t	\N	\N	2026-11-14 23:21:19
54	Bambu Lab	Nardo Gray	#757575	PLA Matte	t	\N	\N	2026-11-14 23:21:19
55	Bambu Lab	Charcoal	#000000	PLA Matte	t	\N	\N	2026-11-14 23:21:19
56	Bambu Lab	Gold	#F4A925	PLA Silk	t	\N	\N	2026-11-14 23:21:19
57	Bambu Lab	Silver	#C8C8C8	PLA Silk	t	\N	\N	2026-11-14 23:21:19
58	Bambu Lab	Titan Gray	#5F6367	PLA Silk	t	\N	\N	2026-11-14 23:21:19
59	Bambu Lab	Blue	#008BDA	PLA Silk	t	\N	\N	2026-11-14 23:21:19
60	Bambu Lab	Purple	#8671CB	PLA Silk	t	\N	\N	2026-11-14 23:21:19
61	Bambu Lab	Candy Red	#D02727	PLA Silk	t	\N	\N	2026-11-14 23:21:19
62	Bambu Lab	Candy Green	#018814	PLA Silk	t	\N	\N	2026-11-14 23:21:19
63	Bambu Lab	Rose Gold	#BA9594	PLA Silk	t	\N	\N	2026-11-14 23:21:19
64	Bambu Lab	Baby Blue	#A8C6EE	PLA Silk	t	\N	\N	2026-11-14 23:21:19
65	Bambu Lab	Pink	#F7ADA6	PLA Silk	t	\N	\N	2026-11-14 23:21:19
66	Bambu Lab	Mint	#96DCB9	PLA Silk	t	\N	\N	2026-11-14 23:21:19
67	Bambu Lab	Champagne	#F3CFB2	PLA Silk	t	\N	\N	2026-11-14 23:21:19
68	Bambu Lab	White	#FFFFFF	PLA Silk	t	\N	\N	2026-11-14 23:21:19
69	Bambu Lab	Classic Gold Sparkle	#CEA629	PLA Sparkle	t	\N	\N	2026-11-14 23:21:19
70	Bambu Lab	Slate Gray Sparkle	#8E9089	PLA Sparkle	t	\N	\N	2026-11-14 23:21:19
71	Bambu Lab	Crimson Red Sparkle	#792B36	PLA Sparkle	t	\N	\N	2026-11-14 23:21:19
72	Bambu Lab	Royal Purple Sparkle	#483D8B	PLA Sparkle	t	\N	\N	2026-11-14 23:21:19
73	Bambu Lab	Alpine Green Sparkle	#3F5443	PLA Sparkle	t	\N	\N	2026-11-14 23:21:19
74	Bambu Lab	Onyx Black Sparkle	#2D2B28	PLA Sparkle	t	\N	\N	2026-11-14 23:21:19
75	Bambu Lab	Teal	#009FA1	PLA Translucent	t	\N	\N	2026-11-14 23:21:19
76	Bambu Lab	Light Jade	#96D8AF	PLA Translucent	t	\N	\N	2026-11-14 23:21:19
77	Bambu Lab	Blue	#0047BB	PLA Translucent	t	\N	\N	2026-11-14 23:21:19
78	Bambu Lab	Mellow Yellow	#F5DBAB	PLA Translucent	t	\N	\N	2026-11-14 23:21:19
79	Bambu Lab	Purple	#8344B0	PLA Translucent	t	\N	\N	2026-11-14 23:21:19
80	Bambu Lab	Cherry Pink	#F5B6CD	PLA Translucent	t	\N	\N	2026-11-14 23:21:19
81	Bambu Lab	Orange	#F74E02	PLA Translucent	t	\N	\N	2026-11-14 23:21:19
82	Bambu Lab	Ice Blue	#B8CDE9	PLA Translucent	t	\N	\N	2026-11-14 23:21:19
83	Bambu Lab	Red	#B50011	PLA Translucent	t	\N	\N	2026-11-14 23:21:19
84	Bambu Lab	Lavender	#B8ACD6	PLA Translucent	t	\N	\N	2026-11-14 23:21:19
85	Bambu Lab	Glow Green	#A1FFAC	PLA Glow	t	\N	\N	2026-11-14 23:21:19
86	Bambu Lab	Glow Yellow	#F8FF80	PLA Glow	t	\N	\N	2026-11-14 23:21:19
87	Bambu Lab	Glow Pink	#F17B8F	PLA Glow	t	\N	\N	2026-11-14 23:21:19
88	Bambu Lab	Glow Blue	#7AC0E9	PLA Glow	t	\N	\N	2026-11-14 23:21:19
89	Bambu Lab	Glow Orange	#FF9D5B	PLA Glow	t	\N	\N	2026-11-14 23:21:19
90	Bambu Lab	Brown	#684A43	PLA Galaxy	t	\N	\N	2026-11-14 23:21:19
91	Bambu Lab	Green	#3B665E	PLA Galaxy	t	\N	\N	2026-11-14 23:21:19
92	Bambu Lab	Nebulae	#424379	PLA Galaxy	t	\N	\N	2026-11-14 23:21:19
93	Bambu Lab	Purple	#594177	PLA Galaxy	t	\N	\N	2026-11-14 23:21:19
94	Bambu Lab	Iridium Gold Metallic	#B39B84	PLA Metal	t	\N	\N	2026-11-14 23:21:19
95	Bambu Lab	Copper Brown Metallic	#AA6443	PLA Metal	t	\N	\N	2026-11-14 23:21:19
96	Bambu Lab	Oxide Green Metallic	#1D7C6A	PLA Metal	t	\N	\N	2026-11-14 23:21:19
97	Bambu Lab	Cobalt Blue Metallic	#39699E	PLA Metal	t	\N	\N	2026-11-14 23:21:19
98	Bambu Lab	Iron Gray Metallic	#43403D	PLA Metal	t	\N	\N	2026-11-14 23:21:19
99	Bambu Lab	White Marble	#F7F3F0	PLA Marble	t	\N	\N	2026-11-14 23:21:19
100	Bambu Lab	Red Granite	#AD4E38	PLA Marble	t	\N	\N	2026-11-14 23:21:19
101	Bambu Lab	Black Walnut	#4F3F24	PLA Wood	t	\N	\N	2026-11-14 23:21:19
102	Bambu Lab	Rosewood	#4C241C	PLA Wood	t	\N	\N	2026-11-14 23:21:19
103	Bambu Lab	Clay Brown	#995F11	PLA Wood	t	\N	\N	2026-11-14 23:21:19
104	Bambu Lab	Classic Birch	#918669	PLA Wood	t	\N	\N	2026-11-14 23:21:19
105	Bambu Lab	White Oak	#D6CCA3	PLA Wood	t	\N	\N	2026-11-14 23:21:19
106	Bambu Lab	Ochre Yellow	#C98935	PLA Wood	t	\N	\N	2026-11-14 23:21:19
107	Bambu Lab	White	#FFFFFF	PLA Tough	t	\N	\N	2026-11-14 23:21:19
108	Bambu Lab	Gray	#AFB1AE	PLA Tough	t	\N	\N	2026-11-14 23:21:19
109	Bambu Lab	Black	#000000	PLA Tough	t	\N	\N	2026-11-14 23:21:19
110	Bambu Lab	Silver	#959698	PLA Tough	t	\N	\N	2026-11-14 23:21:19
111	Bambu Lab	Yellow	#F4D53F	PLA Tough	t	\N	\N	2026-11-14 23:21:19
112	Bambu Lab	Cyan	#009BD8	PLA Tough	t	\N	\N	2026-11-14 23:21:19
113	Bambu Lab	Orange	#DC3A27	PLA Tough	t	\N	\N	2026-11-14 23:21:19
114	Bambu Lab	Burgundy Red	#951E23	PLA-CF	t	\N	\N	2026-11-14 23:21:19
115	Bambu Lab	Iris Purple	#69398E	PLA-CF	t	\N	\N	2026-11-14 23:21:19
116	Bambu Lab	Matcha Green	#5C9748	PLA-CF	t	\N	\N	2026-11-14 23:21:19
117	Bambu Lab	Jeans Blue	#6E88BC	PLA-CF	t	\N	\N	2026-11-14 23:21:19
118	Bambu Lab	Royal Blue	#2842AD	PLA-CF	t	\N	\N	2026-11-14 23:21:19
119	Bambu Lab	Lava Gray	#4D5054	PLA-CF	t	\N	\N	2026-11-14 23:21:19
120	Bambu Lab	Black	#000000	PLA-CF	t	\N	\N	2026-11-14 23:21:19
121	Bambu Lab	White	#FFFFFF	ABS	t	\N	\N	2026-11-14 23:21:19
122	Bambu Lab	Desert Tan	#E8DBB7	ABS	t	\N	\N	2026-11-14 23:21:19
123	Bambu Lab	Olive	#789D4A	ABS	t	\N	\N	2026-11-14 23:21:19
124	Bambu Lab	Azure	#489FDF	ABS	t	\N	\N	2026-11-14 23:21:19
125	Bambu Lab	Navy Blue	#0C2340	ABS	t	\N	\N	2026-11-14 23:21:19
126	Bambu Lab	Blue	#0A2CA5	ABS	t	\N	\N	2026-11-14 23:21:19
127	Bambu Lab	Tangerine Yellow	#FFC72C	ABS	t	\N	\N	2026-11-14 23:21:19
128	Bambu Lab	Orange	#FF6A13	ABS	t	\N	\N	2026-11-14 23:21:19
129	Bambu Lab	Red	#D32941	ABS	t	\N	\N	2026-11-14 23:21:19
130	Bambu Lab	Purple	#AF1685	ABS	t	\N	\N	2026-11-14 23:21:19
131	Bambu Lab	Silver	#87909A	ABS	t	\N	\N	2026-11-14 23:21:19
132	Bambu Lab	Black	#000000	ABS	t	\N	\N	2026-11-14 23:21:19
133	Bambu Lab	White	#FFFAF2	ASA	t	\N	\N	2026-11-14 23:21:19
134	Bambu Lab	Gray	#8A949E	ASA	t	\N	\N	2026-11-14 23:21:19
135	Bambu Lab	Red	#E02928	ASA	t	\N	\N	2026-11-14 23:21:19
136	Bambu Lab	Green	#00A6A0	ASA	t	\N	\N	2026-11-14 23:21:19
137	Bambu Lab	Blue	#2140B4	ASA	t	\N	\N	2026-11-14 23:21:19
138	Bambu Lab	Black	#000000	ASA	t	\N	\N	2026-11-14 23:21:19
139	Bambu Lab	Yellow	#FFD00B	PETG HF	t	\N	\N	2026-11-14 23:21:19
140	Bambu Lab	Orange	#F75403	PETG HF	t	\N	\N	2026-11-14 23:21:19
141	Bambu Lab	Green	#00AE42	PETG HF	t	\N	\N	2026-11-14 23:21:19
142	Bambu Lab	Red	#EB3A3A	PETG HF	t	\N	\N	2026-11-14 23:21:19
143	Bambu Lab	Blue	#002E96	PETG HF	t	\N	\N	2026-11-14 23:21:19
144	Bambu Lab	Black	#000000	PETG HF	t	\N	\N	2026-11-14 23:21:19
145	Bambu Lab	White	#FFFFFF	PETG HF	t	\N	\N	2026-11-14 23:21:19
146	Bambu Lab	Cream	#F9DFB9	PETG HF	t	\N	\N	2026-11-14 23:21:19
147	Bambu Lab	Lime Green	#6EE53C	PETG HF	t	\N	\N	2026-11-14 23:21:19
148	Bambu Lab	Forest Green	#39541A	PETG HF	t	\N	\N	2026-11-14 23:21:19
149	Bambu Lab	Lake Blue	#1F79E5	PETG HF	t	\N	\N	2026-11-14 23:21:19
150	Bambu Lab	Peanut Brown	#875718	PETG HF	t	\N	\N	2026-11-14 23:21:19
151	Bambu Lab	Gray	#ADB1B2	PETG HF	t	\N	\N	2026-11-14 23:21:19
152	Bambu Lab	Dark Gray	#515151	PETG HF	t	\N	\N	2026-11-14 23:21:19
153	Bambu Lab	Translucent Gray	#8E8E8E	PETG Translucent	t	\N	\N	2026-11-14 23:21:19
154	Bambu Lab	Translucent Light Blue	#61B0FF	PETG Translucent	t	\N	\N	2026-11-14 23:21:19
155	Bambu Lab	Translucent Olive	#748C45	PETG Translucent	t	\N	\N	2026-11-14 23:21:19
156	Bambu Lab	Translucent Brown	#C9A381	PETG Translucent	t	\N	\N	2026-11-14 23:21:19
157	Bambu Lab	Translucent Teal	#77EDD7	PETG Translucent	t	\N	\N	2026-11-14 23:21:19
158	Bambu Lab	Translucent Orange	#FF911A	PETG Translucent	t	\N	\N	2026-11-14 23:21:19
159	Bambu Lab	Translucent Purple	#D6ABFF	PETG Translucent	t	\N	\N	2026-11-14 23:21:19
160	Bambu Lab	Translucent Pink	#F9C1BD	PETG Translucent	t	\N	\N	2026-11-14 23:21:19
161	Bambu Lab	Brick Red	#9F332A	PETG-CF	t	\N	\N	2026-11-14 23:21:19
162	Bambu Lab	Violet Purple	#583061	PETG-CF	t	\N	\N	2026-11-14 23:21:19
163	Bambu Lab	Indigo Blue	#324585	PETG-CF	t	\N	\N	2026-11-14 23:21:19
164	Bambu Lab	Malachite Green	#16B08E	PETG-CF	t	\N	\N	2026-11-14 23:21:19
165	Bambu Lab	Black	#000000	PETG-CF	t	\N	\N	2026-11-14 23:21:19
166	Bambu Lab	Titan Gray	#565656	PETG-CF	t	\N	\N	2026-11-14 23:21:19
167	Bambu Lab	White	#FFFFFF	TPU 95A	t	\N	\N	2026-11-14 23:21:19
168	Bambu Lab	Yellow	#F3E600	TPU 95A	t	\N	\N	2026-11-14 23:21:19
169	Bambu Lab	Blue	#0072CE	TPU 95A	t	\N	\N	2026-11-14 23:21:19
170	Bambu Lab	Red	#C8102E	TPU 95A	t	\N	\N	2026-11-14 23:21:19
171	Bambu Lab	Gray	#898D8D	TPU 95A	t	\N	\N	2026-11-14 23:21:19
172	Bambu Lab	Black	#101820	TPU 95A	t	\N	\N	2026-11-14 23:21:19
173	Bambu Lab	Black	#000000	TPU 90A	t	\N	\N	2026-11-14 23:21:19
174	Bambu Lab	White	#FFFFFF	TPU 90A	t	\N	\N	2026-11-14 23:21:19
175	Bambu Lab	Grape Jelly	#D6ABFF	TPU 90A	t	\N	\N	2026-11-14 23:21:19
176	Bambu Lab	Crystal Blue	#7EB4E1	TPU 90A	t	\N	\N	2026-11-14 23:21:19
177	Bambu Lab	Cocoa Brown	#5C4738	TPU 90A	t	\N	\N	2026-11-14 23:21:19
178	Bambu Lab	Black	#1A1A1A	PAHT-CF	t	\N	\N	2026-11-14 23:21:19
179	Bambu Lab	Natural	#F5F5DC	PLA Support	t	\N	\N	2026-11-14 23:21:19
180	Bambu Lab	Natural	#F5F5DC	PVA Support	t	\N	\N	2026-11-14 23:21:19
181	Polymaker	Cotton White	#F5F5F5	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
182	Polymaker	Charcoal Black	#2B2B2B	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
183	Polymaker	Marble White	#E8E8E8	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
184	Polymaker	Fossil Grey	#6B6B6B	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
185	Polymaker	Shadow Black	#1A1A1A	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
186	Polymaker	Army Red	#8B0000	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
187	Polymaker	Lava Red	#CF1020	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
188	Polymaker	Sakura Pink	#FFB7C5	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
189	Polymaker	Rose	#FF007F	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
190	Polymaker	Peach	#FFCBA4	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
191	Polymaker	Banana	#FFE135	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
192	Polymaker	Savannah Yellow	#F4C430	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
193	Polymaker	Sunrise Orange	#FF6600	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
194	Polymaker	Muted Green	#4F7942	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
195	Polymaker	Forest Green	#228B22	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
196	Polymaker	Mint	#98FF98	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
197	Polymaker	Lavender Purple	#B57EDC	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
198	Polymaker	Sapphire Blue	#0F52BA	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
199	Polymaker	Ice	#D6ECEF	PolyTerra PLA	t	\N	\N	2026-11-14 23:21:19
200	Prusament	Jet Black	#1A1A1A	PLA	t	\N	\N	2026-11-14 23:21:19
201	Prusament	Galaxy Black	#1F1F1F	PLA	t	\N	\N	2026-11-14 23:21:19
202	Prusament	Pristine White	#FFFFFF	PLA	t	\N	\N	2026-11-14 23:21:19
203	Prusament	Gentleman's Grey	#5A5A5A	PLA	t	\N	\N	2026-11-14 23:21:19
204	Prusament	Lipstick Red	#C21E1E	PLA	t	\N	\N	2026-11-14 23:21:19
205	Prusament	Orange	#FF6600	PLA	t	\N	\N	2026-11-14 23:21:19
206	Prusament	Pineapple Yellow	#FFD700	PLA	t	\N	\N	2026-11-14 23:21:19
207	Prusament	Jungle Green	#29AB87	PLA	t	\N	\N	2026-11-14 23:21:19
208	Prusament	Azure Blue	#007FFF	PLA	t	\N	\N	2026-11-14 23:21:19
209	Prusament	Royal Blue	#4169E1	PLA	t	\N	\N	2026-11-14 23:21:19
210	Prusament	Mystic Purple	#7B68EE	PLA	t	\N	\N	2026-11-14 23:21:19
211	eSUN	Beige	#ECCAB0	PLA+	t	\N	\N	2026-11-14 23:21:19
212	eSUN	Black	#373838	PLA+	t	\N	\N	2026-11-14 23:21:19
213	eSUN	Blue	#054795	PLA+	t	\N	\N	2026-11-14 23:21:19
214	eSUN	Bone White	#C2BAA7	PLA+	t	\N	\N	2026-11-14 23:21:19
215	eSUN	Brown	#6F513C	PLA+	t	\N	\N	2026-11-14 23:21:19
216	eSUN	Cool White	#E1E4E5	PLA+	t	\N	\N	2026-11-14 23:21:19
217	eSUN	Dark Blue	#2F314D	PLA+	t	\N	\N	2026-11-14 23:21:19
218	eSUN	Fire Engine Red	#91202B	PLA+	t	\N	\N	2026-11-14 23:21:19
219	eSUN	Gold	#C99B26	PLA+	t	\N	\N	2026-11-14 23:21:19
220	eSUN	Gray	#697480	PLA+	t	\N	\N	2026-11-14 23:21:19
221	eSUN	Green	#015E58	PLA+	t	\N	\N	2026-11-14 23:21:19
222	eSUN	Grey	#5F6574	PLA+	t	\N	\N	2026-11-14 23:21:19
223	eSUN	Light Blue	#48BFD5	PLA+	t	\N	\N	2026-11-14 23:21:19
224	eSUN	Light Brown	#A27556	PLA+	t	\N	\N	2026-11-14 23:21:19
225	eSUN	Luminous Blue	#C8CAC8	PLA+	t	\N	\N	2026-11-14 23:21:19
226	eSUN	Magenta	#DA3B6C	PLA+	t	\N	\N	2026-11-14 23:21:19
227	eSUN	Olive Green	#555B45	PLA+	t	\N	\N	2026-11-14 23:21:19
228	eSUN	Orange	#EF7749	PLA+	t	\N	\N	2026-11-14 23:21:19
229	eSUN	Peak Green	#A1DA7C	PLA+	t	\N	\N	2026-11-14 23:21:19
230	eSUN	Pink	#E78397	PLA+	t	\N	\N	2026-11-14 23:21:19
231	eSUN	Purple	#8350A4	PLA+	t	\N	\N	2026-11-14 23:21:19
232	eSUN	Red	#C4402A	PLA+	t	\N	\N	2026-11-14 23:21:19
233	eSUN	Silver	#8B8889	PLA+	t	\N	\N	2026-11-14 23:21:19
234	eSUN	Skin	#E3C7AF	PLA+	t	\N	\N	2026-11-14 23:21:19
235	eSUN	White	#E1E9E9	PLA+	t	\N	\N	2026-11-14 23:21:19
236	eSUN	Yellow	#FBCE2B	PLA+	t	\N	\N	2026-11-14 23:21:19
237	eSUN	Blue	#065AA1	Pro PLA+	t	\N	\N	2026-11-14 23:21:19
238	eSUN	Glow in the Dark	#C5C2AB	PLA	t	\N	\N	2026-11-14 23:21:19
239	eSUN	Marble White	#B5BCC0	PLA	t	\N	\N	2026-11-14 23:21:19
240	eSUN	Natural Wood	#EBCFA6	PLA	t	\N	\N	2026-11-14 23:21:19
241	eSUN	Pine Green	#375C49	PLA	t	\N	\N	2026-11-14 23:21:19
242	eSUN	UV Change Purple	#CABBA9	PLA	t	\N	\N	2026-11-14 23:21:19
243	eSUN	eTwinkling Blue	#115CAF	PLA	t	\N	\N	2026-11-14 23:21:19
244	eSUN	eStars Galaxy Black	#403936	PLA	t	\N	\N	2026-11-14 23:21:19
245	eSUN	Silk Blue	#2275AA	PLA Silk	t	\N	\N	2026-11-14 23:21:19
246	eSUN	Silk Bronze	#829172	PLA Silk	t	\N	\N	2026-11-14 23:21:19
247	eSUN	Silk Copper	#AE6B2F	PLA Silk	t	\N	\N	2026-11-14 23:21:19
248	eSUN	Silk Cyan	#34A7CF	PLA Silk	t	\N	\N	2026-11-14 23:21:19
249	eSUN	Silk Dark Yellow	#D4A62E	PLA Silk	t	\N	\N	2026-11-14 23:21:19
250	eSUN	Silk Gold	#C48E2F	PLA Silk	t	\N	\N	2026-11-14 23:21:19
251	eSUN	Silk Green	#7FCB43	PLA Silk	t	\N	\N	2026-11-14 23:21:19
252	eSUN	Silk Jacinth	#DA8061	PLA Silk	t	\N	\N	2026-11-14 23:21:19
253	eSUN	Silk Lime	#C1D762	PLA Silk	t	\N	\N	2026-11-14 23:21:19
254	eSUN	Silk Magic Green Blue	#508669	PLA Silk	t	\N	\N	2026-11-14 23:21:19
255	eSUN	Silk Purple	#905295	PLA Silk	t	\N	\N	2026-11-14 23:21:19
256	eSUN	Silk Red	#C94830	PLA Silk	t	\N	\N	2026-11-14 23:21:19
257	eSUN	Silk Rose Gold	#C7886B	PLA Silk	t	\N	\N	2026-11-14 23:21:19
258	eSUN	Silk Silver	#B5C1C5	PLA Silk	t	\N	\N	2026-11-14 23:21:19
259	eSUN	Silk Violet	#B93CA1	PLA Silk	t	\N	\N	2026-11-14 23:21:19
260	eSUN	Silk White	#E3E0DB	PLA Silk	t	\N	\N	2026-11-14 23:21:19
261	eSUN	Silk Yellow	#DED74B	PLA Silk	t	\N	\N	2026-11-14 23:21:19
262	eSUN	Bronze	#917F57	PLA Metal	t	\N	\N	2026-11-14 23:21:19
263	eSUN	Grey	#626C77	PLA-ST	t	\N	\N	2026-11-14 23:21:19
264	eSUN	Black	#353434	PETG	t	\N	\N	2026-11-14 23:21:19
265	eSUN	Magenta	#E03E76	PETG	t	\N	\N	2026-11-14 23:21:19
266	eSUN	Solid Blue	#1A6FB4	PETG	t	\N	\N	2026-11-14 23:21:19
267	eSUN	Solid Green	#008A58	PETG	t	\N	\N	2026-11-14 23:21:19
268	eSUN	Solid Purple	#7A4795	PETG	t	\N	\N	2026-11-14 23:21:19
269	eSUN	Solid White	#F4F1F1	PETG	t	\N	\N	2026-11-14 23:21:19
270	eSUN	Solid Yellow	#F0CA41	PETG	t	\N	\N	2026-11-14 23:21:19
271	eSUN	Translucent Green	#378041	PETG	t	\N	\N	2026-11-14 23:21:19
272	eSUN	Translucent Orange	#DD7135	PETG	t	\N	\N	2026-11-14 23:21:19
273	eSUN	White	#E7EDED	PETG	t	\N	\N	2026-11-14 23:21:19
274	eSUN	Black	#424445	PETG-HS	t	\N	\N	2026-11-14 23:21:19
275	eSUN	Solid Blue	#1A6FB4	PETG-HS	t	\N	\N	2026-11-14 23:21:19
276	eSUN	Black	#3F3A3F	ABS	t	\N	\N	2026-11-14 23:21:19
277	eSUN	Brown	#624741	ABS	t	\N	\N	2026-11-14 23:21:19
278	eSUN	Natural	#D9E3DD	ABS	t	\N	\N	2026-11-14 23:21:19
279	eSUN	Pine Green	#3C694E	ABS	t	\N	\N	2026-11-14 23:21:19
280	eSUN	Pink	#E86477	ABS	t	\N	\N	2026-11-14 23:21:19
281	eSUN	Red	#A74237	ABS	t	\N	\N	2026-11-14 23:21:19
282	eSUN	Silver	#838080	ABS	t	\N	\N	2026-11-14 23:21:19
283	eSUN	Gray	#616777	ABS+	t	\N	\N	2026-11-14 23:21:19
284	eSUN	Green	#018068	ABS+	t	\N	\N	2026-11-14 23:21:19
285	eSUN	Natural	#E4DEC9	ABS+	t	\N	\N	2026-11-14 23:21:19
286	eSUN	Orange	#EE7845	ABS+	t	\N	\N	2026-11-14 23:21:19
287	eSUN	Silver	#7F807E	ABS+	t	\N	\N	2026-11-14 23:21:19
288	eSUN	White	#E1E1DF	ABS+	t	\N	\N	2026-11-14 23:21:19
289	eSUN	Yellow	#D3BC0F	ABS+	t	\N	\N	2026-11-14 23:21:19
290	Hatchbox	White	#FFFFFF	PLA	t	\N	\N	2026-11-14 23:21:19
291	Hatchbox	Black	#000000	PLA	t	\N	\N	2026-11-14 23:21:19
292	Hatchbox	Gray	#808080	PLA	t	\N	\N	2026-11-14 23:21:19
293	Hatchbox	Red	#FF0000	PLA	t	\N	\N	2026-11-14 23:21:19
294	Hatchbox	Blue	#0000FF	PLA	t	\N	\N	2026-11-14 23:21:19
295	Hatchbox	Green	#00FF00	PLA	t	\N	\N	2026-11-14 23:21:19
296	Hatchbox	Yellow	#FFFF00	PLA	t	\N	\N	2026-11-14 23:21:19
297	Hatchbox	Orange	#FFA500	PLA	t	\N	\N	2026-11-14 23:21:19
298	Hatchbox	Purple	#800080	PLA	t	\N	\N	2026-11-14 23:21:19
299	Hatchbox	Pink	#FFC0CB	PLA	t	\N	\N	2026-11-14 23:21:19
300	Hatchbox	True Blue	#0073CF	PLA	t	\N	\N	2026-11-14 23:21:19
301	Hatchbox	True Green	#008000	PLA	t	\N	\N	2026-11-14 23:21:19
302	Overture	Black	#2B292E	PLA	t	\N	\N	2026-11-14 23:21:19
303	Overture	Blue	#034070	PLA	t	\N	\N	2026-11-14 23:21:19
304	Overture	Cement Gray	#48494A	PLA	t	\N	\N	2026-11-14 23:21:19
305	Overture	Dark Blue	#124775	PLA	t	\N	\N	2026-11-14 23:21:19
306	Overture	Fresh Red	#C01F1D	PLA	t	\N	\N	2026-11-14 23:21:19
307	Overture	Gray Blue	#6D8790	PLA	t	\N	\N	2026-11-14 23:21:19
308	Overture	Green	#318C49	PLA	t	\N	\N	2026-11-14 23:21:19
309	Overture	Highlight Yellow	#FBF93C	PLA	t	\N	\N	2026-11-14 23:21:19
310	Overture	Light Blue	#7CC4D5	PLA	t	\N	\N	2026-11-14 23:21:19
311	Overture	Light Gray	#8F9694	PLA	t	\N	\N	2026-11-14 23:21:19
312	Overture	Neon Green Air	#C5ED33	PLA	t	\N	\N	2026-11-14 23:21:19
313	Overture	Olive Green	#8F843D	PLA	t	\N	\N	2026-11-14 23:21:19
314	Overture	Pink	#DC99B4	PLA	t	\N	\N	2026-11-14 23:21:19
315	Overture	Red	#C9341A	PLA	t	\N	\N	2026-11-14 23:21:19
316	Overture	Royal Gold	#C58F31	PLA	t	\N	\N	2026-11-14 23:21:19
317	Overture	Space Grey	#797779	PLA	t	\N	\N	2026-11-14 23:21:19
318	Overture	White	#E7EBE3	PLA	t	\N	\N	2026-11-14 23:21:19
319	Overture	Black	#3F3E41	PLA Matte	t	\N	\N	2026-11-14 23:21:19
320	Overture	Blue	#277EAB	PLA Matte	t	\N	\N	2026-11-14 23:21:19
321	Overture	Brick Red	#AE4848	PLA Matte	t	\N	\N	2026-11-14 23:21:19
322	Overture	Green	#5EAE73	PLA Matte	t	\N	\N	2026-11-14 23:21:19
323	Overture	Light Grey	#919598	PLA Matte	t	\N	\N	2026-11-14 23:21:19
324	Overture	Light Brown	#BF9C80	PLA Matte	t	\N	\N	2026-11-14 23:21:19
325	Overture	Light Green	#A1C1A5	PLA Matte	t	\N	\N	2026-11-14 23:21:19
326	Overture	Olive Green	#B59837	PLA Matte	t	\N	\N	2026-11-14 23:21:19
327	Overture	Orange	#F59752	PLA Matte	t	\N	\N	2026-11-14 23:21:19
328	Overture	Pink	#EBBDCE	PLA Matte	t	\N	\N	2026-11-14 23:21:19
329	Overture	Purple	#978DC5	PLA Matte	t	\N	\N	2026-11-14 23:21:19
330	Overture	White	#E1E4DD	PLA Matte	t	\N	\N	2026-11-14 23:21:19
331	Overture	Yellow	#FFD359	PLA Matte	t	\N	\N	2026-11-14 23:21:19
332	Overture	Digital Blue	#008FBE	PLA Pro	t	\N	\N	2026-11-14 23:21:19
333	Overture	Light Blue	#68C8DB	PLA Pro	t	\N	\N	2026-11-14 23:21:19
334	Overture	Orange	#F27C1B	PLA Pro	t	\N	\N	2026-11-14 23:21:19
335	Overture	Purple	#7B5DB0	PLA Pro	t	\N	\N	2026-11-14 23:21:19
336	Overture	Red	#E62F18	PLA Pro	t	\N	\N	2026-11-14 23:21:19
337	Overture	Yellow	#DFB233	PLA Pro	t	\N	\N	2026-11-14 23:21:19
338	Overture	Black	#2F2821	PETG	t	\N	\N	2026-11-14 23:21:19
339	Overture	Blue	#225291	PETG	t	\N	\N	2026-11-14 23:21:19
340	Overture	Clear	#BEC3C5	PETG	t	\N	\N	2026-11-14 23:21:19
341	Overture	Pink	#E0A1BA	PETG	t	\N	\N	2026-11-14 23:21:19
342	Overture	Purple	#67518F	PETG	t	\N	\N	2026-11-14 23:21:19
343	Overture	Rock White	#C2C8C9	PETG	t	\N	\N	2026-11-14 23:21:19
344	Overture	Red	#AB291B	PETG	t	\N	\N	2026-11-14 23:21:19
345	Overture	Space Grey	#80817E	PETG	t	\N	\N	2026-11-14 23:21:19
346	Overture	Translucent Blue	#38487B	PETG	t	\N	\N	2026-11-14 23:21:19
347	Overture	White	#E7E9E7	PETG	t	\N	\N	2026-11-14 23:21:19
348	Overture	Yellow	#E6B93C	PETG	t	\N	\N	2026-11-14 23:21:19
349	Overture	Diamond Gray	#5D5F5F	ABS	t	\N	\N	2026-11-14 23:21:19
350	Overture	Diamond Purple	#6B649D	ABS	t	\N	\N	2026-11-14 23:21:19
351	Overture	Gold	#CA9B52	Silk PLA	t	\N	\N	2026-11-14 23:21:19
352	Overture	Neon Green	#C2D74D	Silk PLA	t	\N	\N	2026-11-14 23:21:19
353	Overture	Copper	#B27052	Silk PLA	t	\N	\N	2026-11-14 23:21:19
354	Overture	Glow Blue	#4EA2AA	Glow PLA	t	\N	\N	2026-11-14 23:21:19
355	Overture	Glow Orange	#C2895E	Glow PLA	t	\N	\N	2026-11-14 23:21:19
356	Overture	Glow Red	#C27B7D	Glow PLA	t	\N	\N	2026-11-14 23:21:19
357	Overture	Glow Yellow	#E3F079	Glow PLA	t	\N	\N	2026-11-14 23:21:19
358	Sunlu	Black	#3C3C3C	PLA	t	\N	\N	2026-11-14 23:21:19
359	Sunlu	Blue	#006AB8	PLA	t	\N	\N	2026-11-14 23:21:19
360	Sunlu	Cherry Red	#EA4A5D	PLA	t	\N	\N	2026-11-14 23:21:19
361	Sunlu	Glow in the Dark	#CBCAB8	PLA	t	\N	\N	2026-11-14 23:21:19
362	Sunlu	Green Mint	#4CCB9A	PLA	t	\N	\N	2026-11-14 23:21:19
363	Sunlu	Grey	#6B6E6E	PLA	t	\N	\N	2026-11-14 23:21:19
364	Sunlu	Orange	#E77932	PLA	t	\N	\N	2026-11-14 23:21:19
365	Sunlu	Red	#AC3637	PLA	t	\N	\N	2026-11-14 23:21:19
366	Sunlu	Sky Blue	#0CB7CC	PLA	t	\N	\N	2026-11-14 23:21:19
367	Sunlu	Sunny Orange	#FF7235	PLA	t	\N	\N	2026-11-14 23:21:19
368	Sunlu	Transparent	#C8C7BF	PLA	t	\N	\N	2026-11-14 23:21:19
369	Sunlu	Transparent Orange	#DB7F42	PLA	t	\N	\N	2026-11-14 23:21:19
370	Sunlu	White	#DEDFD9	PLA	t	\N	\N	2026-11-14 23:21:19
371	Sunlu	Wood	#D5BA95	PLA	t	\N	\N	2026-11-14 23:21:19
372	Sunlu	Silk Black	#737272	PLA Silk	t	\N	\N	2026-11-14 23:21:19
373	Sunlu	Silk Green	#34C0A5	PLA Silk	t	\N	\N	2026-11-14 23:21:19
374	Sunlu	Silk Red	#CD5C62	PLA Silk	t	\N	\N	2026-11-14 23:21:19
375	Sunlu	Silky Silver	#C6CBD0	PLA Silk	t	\N	\N	2026-11-14 23:21:19
376	Sunlu	Blue	#00B2CC	PLA Meta	t	\N	\N	2026-11-14 23:21:19
377	Sunlu	Mint Green	#03A490	PLA Meta	t	\N	\N	2026-11-14 23:21:19
378	Sunlu	Sakura Pink	#F5B5C2	PLA Meta	t	\N	\N	2026-11-14 23:21:19
379	Sunlu	Taro Purple	#A69ED0	PLA Meta	t	\N	\N	2026-11-14 23:21:19
380	Sunlu	Beige	#DDBCAC	PLA+	t	\N	\N	2026-11-14 23:21:19
381	Sunlu	Black	#3A3B3B	PLA+	t	\N	\N	2026-11-14 23:21:19
382	Sunlu	Blue	#0063A0	PLA+	t	\N	\N	2026-11-14 23:21:19
383	Sunlu	Green	#4EE349	PLA+	t	\N	\N	2026-11-14 23:21:19
384	Sunlu	Light Gold	#D3943D	PLA+	t	\N	\N	2026-11-14 23:21:19
385	Sunlu	Mint Green	#00B39A	PLA+	t	\N	\N	2026-11-14 23:21:19
386	Sunlu	Orange	#ED7432	PLA+	t	\N	\N	2026-11-14 23:21:19
387	Sunlu	Pure Yellow	#FFBD2C	PLA+	t	\N	\N	2026-11-14 23:21:19
388	Sunlu	Purple	#8887C5	PLA+	t	\N	\N	2026-11-14 23:21:19
389	Sunlu	Red	#B34044	PLA+	t	\N	\N	2026-11-14 23:21:19
390	Sunlu	Silk Blue	#33ACD4	PLA+	t	\N	\N	2026-11-14 23:21:19
391	Sunlu	Silk Brass	#F1A050	PLA+	t	\N	\N	2026-11-14 23:21:19
392	Sunlu	Silk Pink	#FFCAD9	PLA+	t	\N	\N	2026-11-14 23:21:19
393	Sunlu	Silk White	#EEEFE7	PLA+	t	\N	\N	2026-11-14 23:21:19
394	Sunlu	Skin	#F7BEA1	PLA+	t	\N	\N	2026-11-14 23:21:19
395	Sunlu	White	#E6E6E2	PLA+	t	\N	\N	2026-11-14 23:21:19
396	Sunlu	Black	#3F4141	PETG	t	\N	\N	2026-11-14 23:21:19
397	Sunlu	Blue	#0068AB	PETG	t	\N	\N	2026-11-14 23:21:19
398	Sunlu	Green	#67DB25	PETG	t	\N	\N	2026-11-14 23:21:19
399	Sunlu	Olive Green	#707D63	PETG	t	\N	\N	2026-11-14 23:21:19
400	Sunlu	Transparent	#BAB9B4	PETG	t	\N	\N	2026-11-14 23:21:19
401	Sunlu	White	#DBDDD9	PETG	t	\N	\N	2026-11-14 23:21:19
402	Sunlu	Black	#404142	ABS	t	\N	\N	2026-11-14 23:21:19
403	Creality	Black	#282C2C	Hyper PLA	t	\N	\N	2026-11-14 23:21:19
404	Creality	Blue	#0881BE	Hyper PLA	t	\N	\N	2026-11-14 23:21:19
405	Creality	Grey	#7A7C7C	Hyper PLA	t	\N	\N	2026-11-14 23:21:19
406	Creality	Purple	#B0347E	Hyper PLA	t	\N	\N	2026-11-14 23:21:19
407	Creality	Red	#C32E2F	Hyper PLA	t	\N	\N	2026-11-14 23:21:19
408	Creality	White	#DEE4E1	Hyper PLA	t	\N	\N	2026-11-14 23:21:19
409	Creality	Black	#322F2D	Hyper PLA-CF	t	\N	\N	2026-11-14 23:21:19
410	Creality	Gray	#8F9395	PLA	t	\N	\N	2026-11-14 23:21:19
411	Creality	White	#E1DFD0	PLA	t	\N	\N	2026-11-14 23:21:19
412	Creality	White	#E3E5E1	PETG	t	\N	\N	2026-11-14 23:21:19
413	Creality	Blue-Green	#479B7D	Silk PLA	t	\N	\N	2026-11-14 23:21:19
414	Elegoo	Black	#282929	PLA	t	\N	\N	2026-11-14 23:21:19
415	Elegoo	Clear	#BEBBBF	PLA	t	\N	\N	2026-11-14 23:21:19
416	Elegoo	Galaxy Black	#32464E	PLA	t	\N	\N	2026-11-14 23:21:19
417	Elegoo	Galaxy Purple	#3A2F6F	PLA	t	\N	\N	2026-11-14 23:21:19
418	Elegoo	Grey	#B5B7B7	PLA	t	\N	\N	2026-11-14 23:21:19
419	Elegoo	Peacock Blue	#21606B	PLA	t	\N	\N	2026-11-14 23:21:19
420	Elegoo	Sky Blue	#46C8D4	PLA	t	\N	\N	2026-11-14 23:21:19
421	Elegoo	Black	#343132	PLA+	t	\N	\N	2026-11-14 23:21:19
422	Elegoo	Orange	#CC6A2F	PLA+	t	\N	\N	2026-11-14 23:21:19
423	Elegoo	Purple	#6E45A7	PLA+	t	\N	\N	2026-11-14 23:21:19
424	Elegoo	Coral Pink	#DB6E6D	Silk PLA	t	\N	\N	2026-11-14 23:21:19
425	Elegoo	Gold	#E2AC00	Silk PLA	t	\N	\N	2026-11-14 23:21:19
426	Elegoo	Silver	#93969B	Silk PLA	t	\N	\N	2026-11-14 23:21:19
427	Jayo	Black	#2F2E2D	PLA+	t	\N	\N	2026-11-14 23:21:19
428	Jayo	Cherry Red	#C43536	PLA+	t	\N	\N	2026-11-14 23:21:19
429	Jayo	White	#D9E0E7	PLA+	t	\N	\N	2026-11-14 23:21:19
430	Inland	Black	#27272C	PLA	t	\N	\N	2026-11-14 23:21:19
431	Inland	Blue	#044482	PLA	t	\N	\N	2026-11-14 23:21:19
432	Inland	Coral	#C16062	PLA	t	\N	\N	2026-11-14 23:21:19
433	Inland	Egyptian Blue	#075AAC	PLA	t	\N	\N	2026-11-14 23:21:19
434	Inland	Gold	#D7B536	PLA	t	\N	\N	2026-11-14 23:21:19
435	Inland	Green	#407166	PLA	t	\N	\N	2026-11-14 23:21:19
436	Inland	Grey	#6F7983	PLA	t	\N	\N	2026-11-14 23:21:19
437	Inland	Light Blue	#3CA4B8	PLA	t	\N	\N	2026-11-14 23:21:19
438	Inland	Military Green	#5B6D37	PLA	t	\N	\N	2026-11-14 23:21:19
439	Inland	Pink	#FC97AF	PLA	t	\N	\N	2026-11-14 23:21:19
440	Inland	Red	#C43220	PLA	t	\N	\N	2026-11-14 23:21:19
441	Inland	Silver	#8A8F92	PLA	t	\N	\N	2026-11-14 23:21:19
442	Inland	True Red	#B13137	PLA	t	\N	\N	2026-11-14 23:21:19
443	Inland	White	#E0E3E3	PLA	t	\N	\N	2026-11-14 23:21:19
444	Inland	Wood	#DEB98F	PLA	t	\N	\N	2026-11-14 23:21:19
445	Inland	Black	#2B272B	PLA+	t	\N	\N	2026-11-14 23:21:19
446	Inland	Blue	#054990	PLA+	t	\N	\N	2026-11-14 23:21:19
447	Inland	Bone White	#ABA18F	PLA+	t	\N	\N	2026-11-14 23:21:19
448	Inland	Dark Blue	#2C3353	PLA+	t	\N	\N	2026-11-14 23:21:19
449	Inland	Light Blue	#079FBF	PLA+	t	\N	\N	2026-11-14 23:21:19
450	Inland	Magenta	#DE2B60	PLA+	t	\N	\N	2026-11-14 23:21:19
451	Inland	Orange	#FB8B5A	PLA+	t	\N	\N	2026-11-14 23:21:19
452	Inland	Pink	#F291A4	PLA+	t	\N	\N	2026-11-14 23:21:19
453	Inland	Purple	#744FA0	PLA+	t	\N	\N	2026-11-14 23:21:19
454	Inland	Silver	#868A8B	PLA+	t	\N	\N	2026-11-14 23:21:19
455	Inland	White	#E3E5E5	PLA+	t	\N	\N	2026-11-14 23:21:19
456	Inland	Yellow	#F8D008	PLA+	t	\N	\N	2026-11-14 23:21:19
457	Inland	Blue	#084480	PETG	t	\N	\N	2026-11-14 23:21:19
458	Inland	Green	#2B783E	PETG	t	\N	\N	2026-11-14 23:21:19
459	Inland	Magenta	#E14170	PETG	t	\N	\N	2026-11-14 23:21:19
460	Inland	Transparent	#D1D6D1	PETG	t	\N	\N	2026-11-14 23:21:19
461	Inland	True Red	#97392B	PETG	t	\N	\N	2026-11-14 23:21:19
462	Inland	Grey	#8A97A2	ABS	t	\N	\N	2026-11-14 23:21:19
463	Inland	Light Blue	#6CBECF	ABS	t	\N	\N	2026-11-14 23:21:19
464	Inland	Orange	#E8712F	ABS	t	\N	\N	2026-11-14 23:21:19
465	Inland	Light Gray	#8D9497	Tough PLA	t	\N	\N	2026-11-14 23:21:19
466	Inland	Yellow	#FFBB3F	Tough PLA	t	\N	\N	2026-11-14 23:21:19
467	Eryone	Galaxy Purple	#60617B	PLA	t	\N	\N	2026-11-14 23:21:19
468	Eryone	Galaxy Red	#8E3332	PLA	t	\N	\N	2026-11-14 23:21:19
469	Eryone	Glow in the Dark	#C2C1AF	PLA	t	\N	\N	2026-11-14 23:21:19
470	Eryone	Ivory White	#DCDCD3	PLA	t	\N	\N	2026-11-14 23:21:19
471	Eryone	Silk Blue	#64A9D3	PLA	t	\N	\N	2026-11-14 23:21:19
472	Eryone	Silk Copper	#B36A50	PLA	t	\N	\N	2026-11-14 23:21:19
473	Eryone	Silk Gold	#D5983D	PLA	t	\N	\N	2026-11-14 23:21:19
474	Eryone	Silk Gold Copper	#D69366	PLA	t	\N	\N	2026-11-14 23:21:19
475	Eryone	Silk Gold Silver	#ABA787	PLA	t	\N	\N	2026-11-14 23:21:19
476	Eryone	Ultra Silk Black	#5B6264	PLA	t	\N	\N	2026-11-14 23:21:19
477	Eryone	Ultra Silk Copper	#B46A4D	PLA	t	\N	\N	2026-11-14 23:21:19
478	Eryone	Ultra Silk Silver	#999BA5	PLA	t	\N	\N	2026-11-14 23:21:19
479	Eryone	Army Green	#5D644D	PLA+	t	\N	\N	2026-11-14 23:21:19
480	Eryone	Black	#414446	ASA	t	\N	\N	2026-11-14 23:21:19
481	Eryone	Light Wood	#A5886E	PLA Wood	t	\N	\N	2026-11-14 23:21:19
482	ColorFabb	Stonefill Light Gray	#A9B2B7	PLA	t	\N	\N	2026-11-14 23:21:19
483	ColorFabb	WoodFill	#B89775	PLA	t	\N	\N	2026-11-14 23:21:19
484	ColorFabb	CopperFill	#9D7465	PLA/PHA	t	\N	\N	2026-11-14 23:21:19
485	ColorFabb	CorkFill	#7F6150	PLA/PHA	t	\N	\N	2026-11-14 23:21:19
486	ColorFabb	Natural	#CFCFC2	PLA/PHA	t	\N	\N	2026-11-14 23:21:19
487	ColorFabb	Light Gray	#BFC5BE	XT	t	\N	\N	2026-11-14 23:21:19
488	ColorFabb	Black	#3B3635	XT	t	\N	\N	2026-11-14 23:21:19
489	Fillamentum	Baby Blue	#B9D7DC	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
490	Fillamentum	Chocolate Brown	#5B4A45	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
491	Fillamentum	Cobalt Blue	#333D5C	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
492	Fillamentum	Crystal Clear Smaragd Green	#028D77	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
493	Fillamentum	Everybody's Magenta	#E1347D	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
494	Fillamentum	Gold Happens	#BC994D	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
495	Fillamentum	Mukha	#A88866	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
496	Fillamentum	Pearl Night Blue	#045589	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
497	Fillamentum	Pearl Ruby Red	#791F2A	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
498	Fillamentum	Rapunzel Silver	#AFAFB0	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
499	Fillamentum	Vertigo Cherry	#752F38	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
500	Fillamentum	Vertigo Galaxy	#333928	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
501	Fillamentum	Vertigo Grey	#5A5963	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
502	Fillamentum	Vertigo Starlight	#343A4F	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
503	Fillamentum	Wizard's Voodoo	#3F465E	PLA Extrafill	t	\N	\N	2026-11-14 23:21:19
504	Fillamentum	Crystal Clear	#EBECF2	PLA	t	\N	\N	2026-11-14 23:21:19
505	Fillamentum	Crystal Clear Amethyst Purple	#9F99BC	PLA	t	\N	\N	2026-11-14 23:21:19
506	Fillamentum	Crystal Clear Iceland Blue	#82BBCD	PLA	t	\N	\N	2026-11-14 23:21:19
507	Fillamentum	Crystal Clear Tangerine Orange	#ECD082	PLA	t	\N	\N	2026-11-14 23:21:19
508	Fillamentum	Lilac	#A99FCF	PLA	t	\N	\N	2026-11-14 23:21:19
509	Fillamentum	Timberfill Cinnamon	#AC7C67	PLA	t	\N	\N	2026-11-14 23:21:19
510	Fillamentum	Timberfill Rosewood	#6A564E	PLA	t	\N	\N	2026-11-14 23:21:19
511	Fillamentum	Vertigo Jade	#217F60	PLA	t	\N	\N	2026-11-14 23:21:19
512	Fillamentum	Anthracite Grey	#4B4F50	ASA Extrafill	t	\N	\N	2026-11-14 23:21:19
513	Fillamentum	Green Grass	#678653	ASA Extrafill	t	\N	\N	2026-11-14 23:21:19
514	Fillamentum	Grey Blue	#495965	ASA Extrafill	t	\N	\N	2026-11-14 23:21:19
515	Fillamentum	Metallic Grey	#878A8C	ASA Extrafill	t	\N	\N	2026-11-14 23:21:19
516	Fillamentum	Sky Blue	#0783B6	ASA Extrafill	t	\N	\N	2026-11-14 23:21:19
517	Fillamentum	Snow White	#F3F3EF	ASA Extrafill	t	\N	\N	2026-11-14 23:21:19
518	Fillamentum	Traffic Black	#3B3B3F	ASA Extrafill	t	\N	\N	2026-11-14 23:21:19
519	Fillamentum	Traffic White	#E9E7DA	ASA Extrafill	t	\N	\N	2026-11-14 23:21:19
520	Fillamentum	White Aluminium	#9CA1A2	ASA Extrafill	t	\N	\N	2026-11-14 23:21:19
521	Fillamentum	Black Soul	#292B27	CPE HG100	t	\N	\N	2026-11-14 23:21:19
522	Fillamentum	Ghost White	#E5E8E7	CPE HG100	t	\N	\N	2026-11-14 23:21:19
523	Fillamentum	Natural	#DCE4DF	CPE HG100	t	\N	\N	2026-11-14 23:21:19
524	Fillamentum	Blue Transparent	#047990	Flexfill TPU 98A	t	\N	\N	2026-11-14 23:21:19
525	Fillamentum	Carrot Orange	#EA6E21	Flexfill TPU 98A	t	\N	\N	2026-11-14 23:21:19
526	Fillamentum	Metallic Grey	#8F8E8F	Flexfill TPU 98A	t	\N	\N	2026-11-14 23:21:19
527	Fillamentum	Pistachio Green	#A7BE36	Flexfill TPU 98A	t	\N	\N	2026-11-14 23:21:19
528	Fillamentum	Signal Red	#9A2222	Flexfill TPU 98A	t	\N	\N	2026-11-14 23:21:19
529	Fillamentum	Traffic Black	#26262A	Flexfill TPU 98A	t	\N	\N	2026-11-14 23:21:19
530	Fillamentum	Vertigo Grey	#515150	Flexfill TPU 98A	t	\N	\N	2026-11-14 23:21:19
531	FormFutura	Basalt Grey	#5B5F61	PLA	t	\N	\N	2026-11-14 23:21:19
532	FormFutura	Dark Blue	#084B86	PLA	t	\N	\N	2026-11-14 23:21:19
533	FormFutura	Galaxy Champagne Gold	#AE9D83	PLA	t	\N	\N	2026-11-14 23:21:19
534	FormFutura	Gold High Gloss	#C89B4B	PLA	t	\N	\N	2026-11-14 23:21:19
535	FormFutura	High Gloss White	#D0D7D8	PLA	t	\N	\N	2026-11-14 23:21:19
536	FormFutura	Magenta High Gloss	#B94474	PLA	t	\N	\N	2026-11-14 23:21:19
537	FormFutura	Stonefil Terracotta	#BD634C	PLA	t	\N	\N	2026-11-14 23:21:19
538	FormFutura	Yellow Green	#7AA837	PLA	t	\N	\N	2026-11-14 23:21:19
539	FormFutura	Pure Orange	#FA9145	EasyFil PLA	t	\N	\N	2026-11-14 23:21:19
540	FormFutura	ReForm Black	#3A3B3B	ReForm rPLA	t	\N	\N	2026-11-14 23:21:19
541	FormFutura	ReForm White	#F3F3EC	ReForm rPLA	t	\N	\N	2026-11-14 23:21:19
542	Fiberlogy	Mineral White	#E2D9CD	PLA	t	\N	\N	2026-11-14 23:21:19
543	Fiberlogy	Aurora	#3C4452	Easy PLA	t	\N	\N	2026-11-14 23:21:19
544	Fiberlogy	Army Green	#535F4F	Impact PLA	t	\N	\N	2026-11-14 23:21:19
545	Fiberlogy	Olive Green	#61634B	ASA	t	\N	\N	2026-11-14 23:21:19
546	Fiberlogy	White	#F2F2EE	Easy PETG	t	\N	\N	2026-11-14 23:21:19
547	Fiberlogy	Green	#A2D780	FiberSilk Metallic	t	\N	\N	2026-11-14 23:21:19
548	MatterHackers	Blue	#044786	Build PLA	t	\N	\N	2026-11-14 23:21:19
549	MatterHackers	Magenta	#CD4263	Build PLA	t	\N	\N	2026-11-14 23:21:19
550	MatterHackers	Red	#C4351B	Build PLA	t	\N	\N	2026-11-14 23:21:19
551	MatterHackers	Shiny Gold	#DFAC1E	Build PLA	t	\N	\N	2026-11-14 23:21:19
552	MatterHackers	Silky Copper	#C76F35	Build PLA	t	\N	\N	2026-11-14 23:21:19
553	MatterHackers	Silky Silver	#BDBDB8	Build PLA	t	\N	\N	2026-11-14 23:21:19
554	MatterHackers	Silky Teal	#078EBC	Build PLA	t	\N	\N	2026-11-14 23:21:19
555	MatterHackers	Silky Yellow	#EDB554	Build PLA	t	\N	\N	2026-11-14 23:21:19
556	MatterHackers	Yellow	#EBC100	Build PLA	t	\N	\N	2026-11-14 23:21:19
557	MatterHackers	Gold	#E7AC37	PLA	t	\N	\N	2026-11-14 23:21:19
558	MatterHackers	Lime Green	#75BA52	PLA	t	\N	\N	2026-11-14 23:21:19
559	MatterHackers	Pearl White	#D4DCDD	PLA	t	\N	\N	2026-11-14 23:21:19
560	MatterHackers	Red	#E54931	PLA	t	\N	\N	2026-11-14 23:21:19
561	MatterHackers	Electric Pink	#F35886	Pro PLA	t	\N	\N	2026-11-14 23:21:19
562	MatterHackers	Jet Gray	#474B4C	Pro PLA	t	\N	\N	2026-11-14 23:21:19
563	MatterHackers	Clear	#D5DDDA	PETG	t	\N	\N	2026-11-14 23:21:19
564	MatterHackers	White	#E9EBEF	PETG	t	\N	\N	2026-11-14 23:21:19
565	MatterHackers	Black	#3D3C38	NylonX	t	\N	\N	2026-11-14 23:21:19
566	MatterHackers	White	#DCDED9	NylonG	t	\N	\N	2026-11-14 23:21:19
567	Protopasta	Atikam Teal	#135859	HTPLA	t	\N	\N	2026-11-14 23:21:19
568	Protopasta	Blood of My Enemies	#7A1A23	HTPLA	t	\N	\N	2026-11-14 23:21:19
569	Protopasta	Blue Opaque	#044A86	HTPLA	t	\N	\N	2026-11-14 23:21:19
570	Protopasta	Blue Wonder Glitter Flake	#20556F	HTPLA	t	\N	\N	2026-11-14 23:21:19
571	Protopasta	Bobbi's Purple Iris	#542B5C	HTPLA	t	\N	\N	2026-11-14 23:21:19
572	Protopasta	Brass Composite	#8C7A4F	HTPLA	t	\N	\N	2026-11-14 23:21:19
573	Protopasta	Bronze Composite	#635146	HTPLA	t	\N	\N	2026-11-14 23:21:19
574	Protopasta	Candy Apple Metallic Red	#A32423	HTPLA	t	\N	\N	2026-11-14 23:21:19
575	Protopasta	Cloverleaf Metallic Green	#245A3F	HTPLA	t	\N	\N	2026-11-14 23:21:19
576	Protopasta	Copper Composite	#976252	HTPLA	t	\N	\N	2026-11-14 23:21:19
577	Protopasta	Cupid's Crush Metallic Pink	#EA8699	HTPLA	t	\N	\N	2026-11-14 23:21:19
578	Protopasta	Double Espresso Metallic Brown	#6B473B	HTPLA	t	\N	\N	2026-11-14 23:21:19
579	Protopasta	Dragon Fruit Smoothie	#B3295F	HTPLA	t	\N	\N	2026-11-14 23:21:19
580	Protopasta	Dragon Scale Purple	#8A80AC	HTPLA	t	\N	\N	2026-11-14 23:21:19
581	Protopasta	Dusty Smoke	#8F9491	HTPLA	t	\N	\N	2026-11-14 23:21:19
582	Protopasta	Electric Lemonade Metallic Yellow	#E4CA6B	HTPLA	t	\N	\N	2026-11-14 23:21:19
583	Protopasta	Empire Strikes Metallic Black	#393B3B	HTPLA	t	\N	\N	2026-11-14 23:21:19
584	Protopasta	Fluorescent Yellow	#D4DC3A	HTPLA	t	\N	\N	2026-11-14 23:21:19
585	Protopasta	Galactic Empire Metallic Purple	#3B3F5D	HTPLA	t	\N	\N	2026-11-14 23:21:19
586	Protopasta	Glitter's Mane	#128C93	HTPLA	t	\N	\N	2026-11-14 23:21:19
587	Protopasta	Gold Dust Glitter Flake	#BFAE6D	HTPLA	t	\N	\N	2026-11-14 23:21:19
588	Protopasta	Good as Gold	#9A774B	HTPLA	t	\N	\N	2026-11-14 23:21:19
589	Protopasta	Good Old Gray	#6D737B	HTPLA	t	\N	\N	2026-11-14 23:21:19
590	Protopasta	Green Glowing Natural	#D4D3AD	HTPLA	t	\N	\N	2026-11-14 23:21:19
591	Protopasta	Heartthrob Red Metallic	#7E3030	HTPLA	t	\N	\N	2026-11-14 23:21:19
592	Protopasta	Joel's Highfive Blue	#056B9A	HTPLA	t	\N	\N	2026-11-14 23:21:19
593	Protopasta	Lootsef Green	#8FB841	HTPLA	t	\N	\N	2026-11-14 23:21:19
594	Protopasta	Luke's Proton Purple	#7D3F59	HTPLA	t	\N	\N	2026-11-14 23:21:19
595	Protopasta	Mahogany	#7F5D4F	HTPLA	t	\N	\N	2026-11-14 23:21:19
596	Protopasta	Matte Fiber Black	#3F3F3E	HTPLA	t	\N	\N	2026-11-14 23:21:19
597	Protopasta	Matte Fiber Daffodil	#B79868	HTPLA	t	\N	\N	2026-11-14 23:21:19
598	Protopasta	Matte Fiber Gray	#767A7D	HTPLA	t	\N	\N	2026-11-14 23:21:19
599	Protopasta	Matte Fiber Walnut	#6F5D4E	HTPLA	t	\N	\N	2026-11-14 23:21:19
600	Protopasta	Matte Fiber White	#F4EADB	HTPLA	t	\N	\N	2026-11-14 23:21:19
601	Protopasta	Mermaid's Tale Metallic Teal	#026768	HTPLA	t	\N	\N	2026-11-14 23:21:19
602	Protopasta	Moonstruck White Satin	#DCE4DD	HTPLA	t	\N	\N	2026-11-14 23:21:19
603	Protopasta	Obsidian	#474743	HTPLA	t	\N	\N	2026-11-14 23:21:19
604	Protopasta	Opaque Black	#312F30	HTPLA	t	\N	\N	2026-11-14 23:21:19
605	Protopasta	Opaque Natural	#CBD0D0	HTPLA	t	\N	\N	2026-11-14 23:21:19
606	Protopasta	Opaque White	#DFE4E2	HTPLA	t	\N	\N	2026-11-14 23:21:19
607	Protopasta	Orange Papaya Smoothie	#C57231	HTPLA	t	\N	\N	2026-11-14 23:21:19
608	Protopasta	Out of Darts Orange	#E58429	HTPLA	t	\N	\N	2026-11-14 23:21:19
609	Protopasta	Pineapple Banana Smoothie	#D0A645	HTPLA	t	\N	\N	2026-11-14 23:21:19
610	Protopasta	Pretty in Pink Pearl	#CE95AE	HTPLA	t	\N	\N	2026-11-14 23:21:19
611	Protopasta	Red Hot Cinnamon	#7C4448	HTPLA	t	\N	\N	2026-11-14 23:21:19
612	Protopasta	Red Opaque	#972425	HTPLA	t	\N	\N	2026-11-14 23:21:19
613	Protopasta	Second to None Silver	#B4B6B6	HTPLA	t	\N	\N	2026-11-14 23:21:19
614	Protopasta	Sparkling Spruce	#47614C	HTPLA	t	\N	\N	2026-11-14 23:21:19
615	Protopasta	Stardust Glitter Flake	#AAB1AE	HTPLA	t	\N	\N	2026-11-14 23:21:19
616	Protopasta	Summertime Green	#89A78A	HTPLA	t	\N	\N	2026-11-14 23:21:19
617	Protopasta	Tangerine Orange Metallic Gold	#C05834	HTPLA	t	\N	\N	2026-11-14 23:21:19
618	Protopasta	Translucent Iridescent Ice	#C4CBC8	HTPLA	t	\N	\N	2026-11-14 23:21:19
619	Protopasta	Translucent Silver Smoke	#A5ACA9	HTPLA	t	\N	\N	2026-11-14 23:21:19
620	Protopasta	Unicorn Tears White Glitter	#D7DEDE	HTPLA	t	\N	\N	2026-11-14 23:21:19
621	Protopasta	What Karat? Smooth Gold	#CD974B	HTPLA	t	\N	\N	2026-11-14 23:21:19
622	Protopasta	White	#F6F5F0	HTPLA	t	\N	\N	2026-11-14 23:21:19
623	Protopasta	White Marble	#C6CECF	HTPLA	t	\N	\N	2026-11-14 23:21:19
624	Protopasta	Winter Blue Glitter Flake	#056F9D	HTPLA	t	\N	\N	2026-11-14 23:21:19
625	Protopasta	Black	#323132	PLA	t	\N	\N	2026-11-14 23:21:19
626	Protopasta	Conductive	#373838	PLA	t	\N	\N	2026-11-14 23:21:19
627	Protopasta	Iron Composite	#555451	PLA	t	\N	\N	2026-11-14 23:21:19
628	Protopasta	Natural	#E1DFD6	PLA	t	\N	\N	2026-11-14 23:21:19
629	Protopasta	Steel Composite	#676561	PLA	t	\N	\N	2026-11-14 23:21:19
630	Protopasta	Black	#424140	Carbon Fiber PLA	t	\N	\N	2026-11-14 23:21:19
631	3DXTECH	Natural	#DED7C6	ASA	t	\N	\N	2026-11-14 23:21:19
632	3DXTECH	Black	#444342	Carbon Fiber PLA	t	\N	\N	2026-11-14 23:21:19
633	3DXTECH	Venom	#CACC19	ECOMAX PLA	t	\N	\N	2026-11-14 23:21:19
634	3DXTECH	Simubone	#EAE0CB	PLA	t	\N	\N	2026-11-14 23:21:19
635	3DXTECH	Blue Frost	#B1C1C5	rPETG	t	\N	\N	2026-11-14 23:21:19
636	Sakata3D	Red	#B63A32	PLA	t	\N	\N	2026-11-14 23:21:19
637	Sakata3D	Silk Sunset	#F49545	PLA	t	\N	\N	2026-11-14 23:21:19
638	Sakata3D	Surf Green	#00C1A8	PLA	t	\N	\N	2026-11-14 23:21:19
639	Generic	Cream	#FFFDD0		t	\N	\N	2026-11-14 23:44:48.554285
640	Generic	Ivory	#FFFFF0		t	\N	\N	2026-11-14 23:44:48.554285
641	Generic	Charcoal	#36454F		t	\N	\N	2026-11-14 23:44:48.554285
642	Generic	Tan	#D2B48C		t	\N	\N	2026-11-14 23:44:48.554285
643	Generic	Chocolate	#D2691E		t	\N	\N	2026-11-14 23:44:48.554285
644	Generic	Olive	#808000		t	\N	\N	2026-11-14 23:44:48.554285
645	Generic	Maroon	#800000		t	\N	\N	2026-11-14 23:44:48.554285
646	Generic	Salmon	#FA8072		t	\N	\N	2026-11-14 23:44:48.554285
647	Generic	Navy	#000080		t	\N	\N	2026-11-14 23:44:48.554285
648	Generic	Teal	#008080		t	\N	\N	2026-11-14 23:44:48.554285
649	Generic	Turquoise	#40E0D0		t	\N	\N	2026-11-14 23:44:48.554285
650	Generic	Lime	#32CD32		t	\N	\N	2026-11-14 23:44:48.554285
651	Generic	Silver	#C0C0C0		t	\N	\N	2026-11-14 23:44:48.554285
652	Generic	Magenta	#FF00FF		t	\N	\N	2026-11-14 23:44:48.554285
653	Generic	Violet	#EE82EE		t	\N	\N	2026-11-14 23:44:48.554285
654	Generic	Indigo	#4B0082		t	\N	\N	2026-11-14 23:44:48.554285
655	Generic	Slate	#708090		t	\N	\N	2026-11-14 23:44:48.554285
656	Generic	Coral	#FF7F50		t	\N	\N	2026-11-14 23:44:48.554285
657	Generic	Green	#00AA00		t	\N	\N	2026-11-14 23:44:48.554285
658	Generic	Cyan	#00FFFF		t	\N	\N	2026-11-14 23:44:48.554285
659	Generic	Brown	#8B4513		t	\N	\N	2026-11-14 23:44:48.554285
\.


--
-- Data for Name: connector_submission_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.connector_submission_entries (id, submission_id, entry_id, ordinal, intent_hash, state, published_receipt, error_code, error_message, attempt_generation, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: connector_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.connector_submissions (id, operation_id, api_key_identity, owner_id, server_id, storage_epoch, manifest, manifest_hash, state, cancel_requested, compacted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_contacts (id, customer_id, "position", name, role, phone, email, city, delivery_method_id, delivery_details, note) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, notes, created_at, updated_at, kind) FROM stdin;
\.


--
-- Data for Name: delivery_methods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.delivery_methods (id, name, name_key, "position") FROM stdin;
1	Pickup	pickup	0
2	Courier	courier	1
3	Post	post	2
\.


--
-- Data for Name: drying_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drying_schedules (id, printer_id, ams_id, temp, duration_hours, filament, rotate_tray, start_time, weekdays, latest_start, enabled, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: external_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_links (id, name, url, icon, custom_icon, open_in_new_tab, nav_group, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: filament_calibration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filament_calibration (id, printer_id, filament_id, filament_setting_id, nozzle_diameter, nozzle_volume_type, extruder_id, pa_k_value, pa_n_coef, flow_ratio, confidence, cali_mode, source, is_active, cali_idx, name, notes, nozzle_id, calibrated_by_user_id, created_at, tower_result) FROM stdin;
\.


--
-- Data for Name: filament_shopping_list; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filament_shopping_list (id, material, subtype, brand, color_name, quantity_spools, note, status, purchased_at, added_at) FROM stdin;
\.


--
-- Data for Name: filament_sku_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filament_sku_settings (id, material, subtype, brand, color_name, lead_time_days, safety_margin_value, safety_margin_unit, alerts_snoozed, created_at, updated_at, stock_break_notified_at, stock_reorder_notified_at) FROM stdin;
\.


--
-- Data for Name: firmware_batch_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.firmware_batch_items (id, run_id, printer_id, model, from_version, to_version, action, status, message, error, started_at, finished_at) FROM stdin;
\.


--
-- Data for Name: firmware_batch_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.firmware_batch_runs (id, created_by_id, created_at, source, status, total, succeeded, skipped, failed) FROM stdin;
\.


--
-- Data for Name: firmware_cache_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.firmware_cache_entries (id, model, version, filename, sha256, size_bytes, source_url, release_notes, downloaded_at) FROM stdin;
\.


--
-- Data for Name: git_backup_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_backup_config (id, provider, repository_url, access_token, branch, api_base_url, schedule_enabled, schedule_type, schedule_cron, backup_kprofiles, backup_cloud_profiles, backup_settings, backup_spools, backup_archives, enabled, last_backup_at, last_backup_status, last_backup_message, last_backup_commit_sha, next_scheduled_run, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: git_backup_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.git_backup_logs (id, config_id, started_at, completed_at, status, trigger, commit_sha, files_changed, error_message) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, name, description, permissions, is_system, created_at, updated_at) FROM stdin;
3	Viewers	Read-only access to printers, archives, and queue	["printers:read", "archives:read", "archives:read_all", "queue:read", "queue:read_all", "library:read", "library:read_all", "library:notes_write", "makerworld:view", "inventory:read", "inventory:view_assignments", "inventory:forecast_read", "smart_plugs:read", "camera:view", "maintenance:read", "pipelines:read", "kprofiles:read", "notifications:read", "notification_templates:read", "external_links:read", "firmware:read", "ams_history:read", "printer_sensor_history:read", "stats:read", "system:read", "settings:read", "websocket:connect", "smart_sensors:read", "label_templates:read", "label_devices:read", "notifications:inbox", "orders:read", "products:read", "customers:read", "stock:read"]	t	2026-11-14 23:21:18	2026-11-14 23:44:48.168141
1	Administrators	Full access to all features and settings	["printers:read", "printers:create", "printers:update", "printers:delete", "printers:control", "printers:files", "printers:ams_rfid", "printers:clear_plate", "archives:read", "archives:read_own", "archives:read_all", "archives:create", "archives:update_own", "archives:update_all", "archives:delete_own", "archives:delete_all", "archives:reprint_own", "archives:reprint_all", "archives:purge", "queue:read", "queue:read_own", "queue:read_all", "queue:create", "queue:update_own", "queue:update_all", "queue:delete_own", "queue:delete_all", "queue:reorder", "library:read", "library:read_own", "library:read_all", "library:upload", "library:update_own", "library:update_all", "library:delete_own", "library:delete_all", "library:purge", "library:notes_write", "makerworld:view", "makerworld:import", "inventory:read", "inventory:create", "inventory:update", "inventory:delete", "inventory:view_assignments", "inventory:forecast_read", "inventory:forecast_write", "smart_plugs:read", "smart_plugs:create", "smart_plugs:update", "smart_plugs:delete", "smart_plugs:control", "camera:view", "maintenance:read", "maintenance:create", "maintenance:update", "maintenance:delete", "pipelines:read", "pipelines:write", "kprofiles:read", "kprofiles:create", "kprofiles:update", "kprofiles:delete", "notifications:read", "notifications:create", "notifications:update", "notifications:delete", "notifications:user_email", "notification_templates:read", "notification_templates:update", "external_links:read", "external_links:create", "external_links:update", "external_links:delete", "discovery:scan", "firmware:read", "firmware:update", "ams_history:read", "printer_sensor_history:read", "stats:read", "stats:filter_by_user", "system:read", "settings:read", "settings:update", "settings:backup", "settings:restore", "git:backup", "git:restore", "cloud:auth", "orca_cloud:auth", "api_keys:read", "api_keys:create", "api_keys:update", "api_keys:delete", "users:read", "users:create", "users:update", "users:delete", "groups:read", "groups:create", "groups:update", "groups:delete", "websocket:connect", "smart_sensors:read", "smart_sensors:create", "smart_sensors:update", "smart_sensors:delete", "users:read_slim", "label_templates:read", "label_templates:write", "label_devices:read", "label_devices:poll", "label_devices:manage", "label_jobs:create", "cloud_link:manage", "notifications:inbox", "orders:read", "products:read", "customers:read", "stock:read", "orders:create", "products:create", "customers:create", "orders:update", "products:update", "customers:update", "stock:move", "stock:adjust", "orders:delete", "products:delete", "customers:delete", "orders:file_prints", "farm:resume"]	t	2026-11-14 23:21:18	2026-11-14 23:44:48.356031
2	Operators	Can control printers, manage queue and archives, view settings	["printers:read", "printers:create", "printers:update", "printers:delete", "printers:control", "printers:files", "printers:ams_rfid", "printers:clear_plate", "archives:read", "archives:read_all", "archives:create", "archives:update_own", "archives:delete_own", "archives:reprint_own", "queue:read", "queue:read_all", "queue:create", "queue:update_own", "queue:delete_own", "queue:reorder", "library:read", "library:read_all", "library:upload", "library:update_own", "library:delete_own", "library:notes_write", "makerworld:view", "makerworld:import", "orca_cloud:auth", "inventory:read", "inventory:create", "inventory:update", "inventory:delete", "inventory:view_assignments", "inventory:forecast_read", "inventory:forecast_write", "smart_plugs:read", "smart_plugs:create", "smart_plugs:update", "smart_plugs:delete", "smart_plugs:control", "camera:view", "maintenance:read", "maintenance:create", "maintenance:update", "maintenance:delete", "pipelines:read", "pipelines:write", "kprofiles:read", "kprofiles:create", "kprofiles:update", "kprofiles:delete", "notifications:read", "notifications:create", "notifications:update", "notifications:delete", "notifications:user_email", "notification_templates:read", "notification_templates:update", "external_links:read", "external_links:create", "external_links:update", "external_links:delete", "discovery:scan", "firmware:read", "ams_history:read", "printer_sensor_history:read", "stats:read", "stats:filter_by_user", "system:read", "settings:read", "websocket:connect", "smart_sensors:read", "smart_sensors:create", "smart_sensors:update", "smart_sensors:delete", "users:read_slim", "label_templates:read", "label_templates:write", "label_devices:read", "label_jobs:create", "notifications:inbox", "orders:read", "products:read", "customers:read", "stock:read", "orders:create", "products:create", "customers:create", "orders:update", "products:update", "customers:update", "stock:move", "stock:adjust", "orders:delete", "products:delete", "customers:delete", "orders:file_prints"]	t	2026-11-14 23:21:18	2026-11-14 23:44:48.168141
\.


--
-- Data for Name: ha_sensor_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ha_sensor_history (id, printer_sensor_id, location_sensor_id, revision, entity_id, kind, unit, state, value, observed_at) FROM stdin;
\.


--
-- Data for Name: hms_muted_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hms_muted_entries (id, printer_id, full_code, created_at) FROM stdin;
\.


--
-- Data for Name: kprofile_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kprofile_notes (id, filament_calibration_id, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: label_cassettes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.label_cassettes (id, barcode, width_mm, height_mm, name, created_at) FROM stdin;
\.


--
-- Data for Name: label_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.label_devices (id, installation_id, driver, model, protocol_version, transport, address, name, enabled, density, app_version, last_seen_at, cassette_barcode, cassette_width_mm, cassette_height_mm, paper_state, power_level, printer_reachable, created_at) FROM stdin;
\.


--
-- Data for Name: label_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.label_jobs (id, device_id, spool_id, template_id, width_mm, height_mm, copies, image_png, status, attempts, error, claimed_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: label_sheets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.label_sheets (id, name, builtin_key, page_size, cell_width_mm, cell_height_mm, cols, rows, margin_top_mm, margin_left_mm, gap_x_mm, gap_y_mm, created_at) FROM stdin;
1	Avery 5160 (US Letter, 30 per sheet)	avery_5160	letter	66.675	25.4	3	10	12.7	4.76	3.175	0	\N
2	Avery L7160 (A4, 21 per sheet)	avery_l7160	A4	63.5	38.1	3	7	15.15	7	2.5	0	\N
\.


--
-- Data for Name: label_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.label_templates (id, name, width_mm, height_mm, shape, target, description, elements, builtin_key, created_by, created_at, updated_at) FROM stdin;
1	AMS holder 74 × 33	74	33	rect	driver	Single label per page; matches the printable label STL from MakerWorld model 752566 (AMS Filament Label Holder).	[{"h_mm": 30.6, "type": "swatch", "w_mm": 12.89, "x_mm": 1.2, "y_mm": 1.2, "content": "{color_hex_all}"}, {"fit": "clip", "bold": true, "h_mm": 2.82, "type": "text", "w_mm": 41.39, "x_mm": 15.59, "y_mm": 1.2, "italic": false, "content": "{brand}", "size_mm": 2.82}, {"fit": "clip", "bold": false, "h_mm": 2.47, "type": "text", "w_mm": 41.39, "x_mm": 15.59, "y_mm": 4.47, "italic": false, "content": "{material} · {subtype}", "size_mm": 2.47}, {"fit": "clip", "bold": false, "h_mm": 2.29, "type": "text", "w_mm": 41.39, "x_mm": 15.59, "y_mm": 7.39, "italic": false, "content": "{color_hex}", "size_mm": 2.29}, {"fit": "clip", "bold": true, "h_mm": 3.17, "type": "text", "w_mm": 41.39, "x_mm": 15.59, "y_mm": 10.13, "italic": false, "content": "{display_name}", "size_mm": 3.17}, {"fit": "clip", "bold": false, "h_mm": 2.29, "type": "text", "w_mm": 41.39, "x_mm": 15.59, "y_mm": 13.75, "italic": true, "content": "{note}", "size_mm": 2.29}, {"fit": "clip", "bold": true, "h_mm": 5.64, "type": "text", "w_mm": 41.39, "x_mm": 15.59, "y_mm": 26.16, "content": "#{id}", "size_mm": 5.64}, {"h_mm": 14.32, "type": "qr", "w_mm": 14.32, "x_mm": 58.48, "y_mm": 9.34, "content": "{deeplink}"}]	ams_holder_74x33	\N	\N	\N
2	AMS holder 75 × 55	75	55	rect	driver	Single label per page; fits the cardstock-insert variant of the AMS Filament Label Holder. Roomy enough for swatch, brand and QR.	[{"h_mm": 52.6, "type": "swatch", "w_mm": 13.07, "x_mm": 1.2, "y_mm": 1.2, "content": "{color_hex_all}"}, {"fit": "clip", "bold": true, "h_mm": 2.82, "type": "text", "w_mm": 42.01, "x_mm": 15.77, "y_mm": 1.2, "italic": false, "content": "{brand}", "size_mm": 2.82}, {"fit": "clip", "bold": false, "h_mm": 2.47, "type": "text", "w_mm": 42.01, "x_mm": 15.77, "y_mm": 4.47, "italic": false, "content": "{material} · {subtype}", "size_mm": 2.47}, {"fit": "clip", "bold": false, "h_mm": 2.29, "type": "text", "w_mm": 42.01, "x_mm": 15.77, "y_mm": 7.39, "italic": false, "content": "{color_hex}", "size_mm": 2.29}, {"fit": "clip", "bold": true, "h_mm": 3.17, "type": "text", "w_mm": 42.01, "x_mm": 15.77, "y_mm": 10.13, "italic": false, "content": "{display_name}", "size_mm": 3.17}, {"fit": "clip", "bold": false, "h_mm": 2.29, "type": "text", "w_mm": 42.01, "x_mm": 15.77, "y_mm": 13.75, "italic": true, "content": "{note}", "size_mm": 2.29}, {"fit": "clip", "bold": true, "h_mm": 5.64, "type": "text", "w_mm": 42.01, "x_mm": 15.77, "y_mm": 48.16, "content": "#{id}", "size_mm": 5.64}, {"h_mm": 14.52, "type": "qr", "w_mm": 14.52, "x_mm": 59.28, "y_mm": 20.24, "content": "{deeplink}"}]	ams_holder_75x55	\N	\N	\N
3	Box label 40 × 30	40	30	rect	driver	Single label per page; common DK/Brother roll size, good for filament bags and storage bins.	[{"h_mm": 27.6, "type": "swatch", "w_mm": 6.77, "x_mm": 1.2, "y_mm": 1.2, "content": "{color_hex_all}"}, {"fit": "clip", "bold": true, "h_mm": 2.82, "type": "text", "w_mm": 15.83, "x_mm": 9.47, "y_mm": 1.2, "italic": false, "content": "{brand}", "size_mm": 2.82}, {"fit": "clip", "bold": false, "h_mm": 2.47, "type": "text", "w_mm": 15.83, "x_mm": 9.47, "y_mm": 4.47, "italic": false, "content": "{material} · {subtype}", "size_mm": 2.47}, {"fit": "clip", "bold": false, "h_mm": 2.29, "type": "text", "w_mm": 15.83, "x_mm": 9.47, "y_mm": 7.39, "italic": false, "content": "{color_hex}", "size_mm": 2.29}, {"fit": "clip", "bold": true, "h_mm": 3.17, "type": "text", "w_mm": 15.83, "x_mm": 9.47, "y_mm": 10.13, "italic": false, "content": "{display_name}", "size_mm": 3.17}, {"fit": "clip", "bold": false, "h_mm": 2.29, "type": "text", "w_mm": 15.83, "x_mm": 9.47, "y_mm": 13.75, "italic": true, "content": "{note}", "size_mm": 2.29}, {"fit": "clip", "bold": true, "h_mm": 5.64, "type": "text", "w_mm": 15.83, "x_mm": 9.47, "y_mm": 23.16, "content": "#{id}", "size_mm": 5.64}, {"h_mm": 12.0, "type": "qr", "w_mm": 12.0, "x_mm": 26.8, "y_mm": 9.0, "content": "{deeplink}"}]	box_40x30	\N	\N	\N
4	Box label 62 × 29	62	29	rect	driver	Single label per page; sized for Brother PT/QL and Dymo small labels.	[{"h_mm": 26.6, "type": "swatch", "w_mm": 10.73, "x_mm": 1.2, "y_mm": 1.2, "content": "{color_hex_all}"}, {"fit": "clip", "bold": true, "h_mm": 2.82, "type": "text", "w_mm": 33.87, "x_mm": 13.43, "y_mm": 1.2, "italic": false, "content": "{brand}", "size_mm": 2.82}, {"fit": "clip", "bold": false, "h_mm": 2.47, "type": "text", "w_mm": 33.87, "x_mm": 13.43, "y_mm": 4.47, "italic": false, "content": "{material} · {subtype}", "size_mm": 2.47}, {"fit": "clip", "bold": false, "h_mm": 2.29, "type": "text", "w_mm": 33.87, "x_mm": 13.43, "y_mm": 7.39, "italic": false, "content": "{color_hex}", "size_mm": 2.29}, {"fit": "clip", "bold": true, "h_mm": 3.17, "type": "text", "w_mm": 33.87, "x_mm": 13.43, "y_mm": 10.13, "italic": false, "content": "{display_name}", "size_mm": 3.17}, {"fit": "clip", "bold": false, "h_mm": 2.29, "type": "text", "w_mm": 33.87, "x_mm": 13.43, "y_mm": 13.75, "italic": true, "content": "{note}", "size_mm": 2.29}, {"fit": "clip", "bold": true, "h_mm": 5.64, "type": "text", "w_mm": 33.87, "x_mm": 13.43, "y_mm": 22.16, "content": "#{id}", "size_mm": 5.64}, {"h_mm": 12.0, "type": "qr", "w_mm": 12.0, "x_mm": 48.8, "y_mm": 8.5, "content": "{deeplink}"}]	box_62x29	\N	\N	\N
5	Label printer 40 × 20	40	20	rect	thermal		[{"bold": true, "h_mm": 4.42, "type": "text", "w_mm": 22.4, "x_mm": 1.5, "y_mm": 1.5, "italic": false, "content": "{display_name}", "size_mm": 4.42}, {"bold": false, "h_mm": 2.46, "type": "text", "w_mm": 22.4, "x_mm": 1.5, "y_mm": 6.61, "italic": false, "content": "{brand} · {material}", "size_mm": 2.46}, {"bold": false, "h_mm": 2.46, "type": "text", "w_mm": 22.4, "x_mm": 1.5, "y_mm": 9.76, "italic": false, "content": "{remaining_g} g · #{id}", "size_mm": 2.46}, {"bold": false, "h_mm": 2.46, "type": "text", "w_mm": 22.4, "x_mm": 1.5, "y_mm": 12.91, "italic": true, "content": "{purchase_date}", "size_mm": 2.46}, {"bold": false, "h_mm": 2.46, "type": "text", "w_mm": 22.4, "x_mm": 1.5, "y_mm": 16.06, "italic": true, "content": "{lot}", "size_mm": 2.46}, {"h_mm": 13.6, "type": "qr", "w_mm": 13.6, "x_mm": 24.9, "y_mm": 3.2, "content": "{deeplink}"}]	\N	\N	\N	\N
6	Label printer 50 × 30	50	30	rect	thermal		[{"bold": true, "h_mm": 4.89, "type": "text", "w_mm": 27.68, "x_mm": 1.5, "y_mm": 1.5, "italic": false, "content": "{display_name}", "size_mm": 4.89}, {"bold": false, "h_mm": 2.73, "type": "text", "w_mm": 27.68, "x_mm": 1.5, "y_mm": 7.14, "italic": false, "content": "{brand} · {material}", "size_mm": 2.73}, {"bold": false, "h_mm": 2.73, "type": "text", "w_mm": 27.68, "x_mm": 1.5, "y_mm": 10.62, "italic": false, "content": "{remaining_g} g · #{id}", "size_mm": 2.73}, {"bold": false, "h_mm": 2.73, "type": "text", "w_mm": 27.68, "x_mm": 1.5, "y_mm": 14.1, "italic": true, "content": "{purchase_date}", "size_mm": 2.73}, {"bold": false, "h_mm": 2.73, "type": "text", "w_mm": 27.68, "x_mm": 1.5, "y_mm": 17.58, "italic": true, "content": "{lot}", "size_mm": 2.73}, {"h_mm": 16.32, "type": "qr", "w_mm": 16.32, "x_mm": 30.18, "y_mm": 2.74, "content": "{deeplink}"}, {"h_mm": 7.0, "type": "barcode", "w_mm": 45.0, "x_mm": 1.5, "y_mm": 21.5, "content": "{ean}", "symbology": "ean13"}]	\N	\N	\N	\N
\.


--
-- Data for Name: library_file_makerworld_meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_file_makerworld_meta (id, library_file_id, title, description, author_name, author_profile_url, license, original_design_id, variant_title, variant_description, variant_url, profile_id, cover_path, variant_cover_path, sliced_for, compatible_models, needs_ams, material_count, materials, model_id_alphanumeric, raw_payload, imported_at) FROM stdin;
\.


--
-- Data for Name: library_file_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_file_notes (id, library_file_id, user_id, body, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: library_file_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_file_tags (file_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: library_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_files (id, folder_id, is_external, filename, file_path, file_type, file_tags, file_size, file_hash, thumbnail_path, file_metadata, print_count, last_printed_at, notes, source_type, source_url, created_by_id, swap_compatible, skip_objects_supported, created_at, updated_at, deleted_at, fs_modified_at, swap_source_declaration) FROM stdin;
\.


--
-- Data for Name: library_folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_folders (id, name, parent_id, is_external, external_readonly, external_show_hidden, external_path, archive_id, created_at, updated_at, fs_modified_at) FROM stdin;
\.


--
-- Data for Name: library_scan_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_scan_jobs (id, folder_id, status, started_at, finished_at, files_total, files_seen, files_added, files_updated, files_removed, folders_added, folders_removed, skipped_deletions, error, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: library_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_tags (id, name, name_key, created_at, updated_at, is_system, code) FROM stdin;
1	3MF	3mf	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	3mf
2	GCODE	gcode	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	gcode
3	STL	stl	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	stl
4	OBJ	obj	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	obj
5	STEP	step	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	step
6	Project	project	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	project
7	Geometry	geometry	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	geometry
8	Multi-plate	multiplate	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	multiplate
9	Swap	swap	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	swap
10	Sliced	sliced	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	sliced
11	MakerWorld	makerworld	2026-11-14 23:44:45.196974	2026-11-14 23:44:45.196974	t	makerworld
\.


--
-- Data for Name: local_presets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.local_presets (id, name, preset_type, source, filament_type, filament_vendor, nozzle_temp_min, nozzle_temp_max, pressure_advance, default_filament_colour, filament_cost, filament_density, compatible_printers, setting, inherits, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: location_ha_sensors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location_ha_sensors (id, location_id, name, entity_id, kind, device_class, unit, alert_state, alert_above, alert_below, notify_on_alert, show_on_card, sort_order, history_revision, last_state, last_changed, last_checked, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: location_sensor_primary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location_sensor_primary (location_id, category, source, binding_id) FROM stdin;
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.locations (id, name, name_key, identifier, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: long_lived_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.long_lived_tokens (id, user_id, name, lookup_prefix, secret_hash, scope, expires_at, last_used_at, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: macros; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.macros (id, name, description, printer_models, swap_mode_only, swap_profile, event, action_type, mqtt_action, delay_seconds, gcode, is_custom, enabled, created_at, updated_at, mqtt_action_param, trigger_layer) FROM stdin;
1	A1 Mini. Kit Edition. Start Sequence	\N	["A1 Mini"]	t	a1mini_kit	swap_mode_start	gcode	\N	0	;swap ini code\nG91 ;\nG0 Z50 F1000;\nG0 Z-20;\nG90;\nG28 XY;\nG0 Y-4 F5000; grab\nG0 Y145; pull and fix the plate\nG0 Y115 F1000; rehook\nG0 Y180 F5000; pull\nG4 P500; wait\nG0 Y186.5 F200; fix the plate\nG4 P500; wait\nG0 Y3 F15000; back\nG0 Y-5 F200; snap\nG4 P500; wait\nG0 Y10 F1000; load\nG0 Y20 F15000; ready	f	t	2026-11-14 23:21:19	2026-11-14 23:21:19	\N	\N
2	A1 Mini. Kit Edition. Change Table	\N	["A1 Mini"]	t	a1mini_kit	swap_mode_change_table	gcode	\N	0	;swap\nG0 X-10 F5000;\nG0 Z175;\nG0 Y-5 F2000;\nG0 Y186.5 F2000;\nG0 Y182 F10000;\nG0 Z186;\nG0 Y120 F500;\nG0 Y-4 Z175 F5000;\nG0 Y145;\nG0 Y115 F1000;\nG0 Y25 F500;\nG0 Y85 F1000;\nG0 Y180 F2000;\nG4 P500; wait\nG0 Y186.5 F200;\nG4 P500; wait\nG0 Y3 F3000;\nG0 Y-5 F200;\nG4 P500; wait\nG0 Y10 F1000;\nG0 Z100 Y186 F2000;\nG0 Y150;\nG4 P1000; wait	f	t	2026-11-14 23:21:19	2026-11-14 23:21:19	\N	\N
3	A1 Mini. STL Edition. Start Sequence	swapmod-stl-a1m / swap-sequence_v05_20260312 - initial plate seating before the first print.	["A1 Mini"]	t	a1mini_stl	swap_mode_start	gcode	\N	0	;ini swapmod-stl-a1m start / swap-sequence_v05_20260312\nG90;\nG28;\nG0 Z30 F5000;\nG0 X-10;\nG0 Y-6 F2000;\nG0 Y150;\nG0 Y100;\nG0 Y186.5;\nG0 Y-6;\nG4 S1;\nG0 Y5 F500;\nG0 Y100 F5000;	f	t	2026-11-14 23:21:19	2026-11-14 23:21:19	\N	\N
4	A1 Mini. STL Edition. Change Table	swapmod-stl-a1m / swap-sequence_v05_20260312 - swaps the finished plate out for a fresh one between prints.	["A1 Mini"]	t	a1mini_stl	swap_mode_change_table	gcode	\N	0	;swap swapmod-stl-a1m start / swap-sequence_v05_20260312\nG0 X170 F5000;\nG0 Z180 F2000;\nG0 Y186.5 F3000;\nG0 Z186 F2000;\nG0 X188 F5000;\nG0 Z180;\nG4 S1;\nG0 Y150 F200;\nG0 Y-6 F2000;\nG0 Z186 F5000;\nG0 X170;\nG0 Z180 F5000;\nG0 Y150 F2000;\nG0 Y15 F3000;\nG0 Y180 F2000;\nG0 Y186.5 F500;\nG0 Y5 F5000;\nG0 Y-6 F200;\nG4 S1;\nG0 Y5 F500;\nG0 Y100 F5000;	f	t	2026-11-14 23:21:19	2026-11-14 23:21:19	\N	\N
5	JobOx A1. Start Sequence	Extracted from A1-clone test file (Y=266 full-size overflow). Review before first run on real hardware.	["A1"]	t	jobox-a1	swap_mode_start	gcode	\N	0	;========start plate change=================\nG91;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG1 Z5 F1200;\nG90;\nG28 Y;\nG90;\nG1 Y266 F2000;\nG4 P1000;\nG91;\nG380 S2 Z30 F1200;\nG90;\nM211 Y0 Z0;\nG91;\nG90;\nG1 Y50 F1000;\nG1 Y0 F2500;\nG91;\nG380 S3 Z-20 F1200;\nG90;\nG1 Y266 F2000;\nG1 Y43 F2000;\nG1 Y266 F2000;\nG1 Y250 F8000;\nG1 Y266 F8000;\nG1 Y43 F5000;\nG1 Y266 F2000;\nG1 Y250 F8000;\nG1 Y266 F8000;\nG1 Y-2 F7000;\nG1 Y150 F2000;	f	t	2026-11-14 23:21:19	2026-11-14 23:21:19	\N	\N
6	JobOx A1. Change Table	Extracted from A1-clone test file (Y=266 full-size overflow). Same sequence as start until real JobOx gcode is confirmed.	["A1"]	t	jobox-a1	swap_mode_change_table	gcode	\N	0	;========start plate change=================\nG91;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG380 S2 Z75 F1200;\nG380 S3 Z-20 F1200;\nG1 Z5 F1200;\nG90;\nG28 Y;\nG90;\nG1 Y266 F2000;\nG4 P1000;\nG91;\nG380 S2 Z30 F1200;\nG90;\nM211 Y0 Z0;\nG91;\nG90;\nG1 Y50 F1000;\nG1 Y0 F2500;\nG91;\nG380 S3 Z-20 F1200;\nG90;\nG1 Y266 F2000;\nG1 Y43 F2000;\nG1 Y266 F2000;\nG1 Y250 F8000;\nG1 Y266 F8000;\nG1 Y43 F5000;\nG1 Y266 F2000;\nG1 Y250 F8000;\nG1 Y266 F8000;\nG1 Y-2 F7000;\nG1 Y150 F2000;	f	t	2026-11-14 23:21:19	2026-11-14 23:21:19	\N	\N
7	A2L. STL Edition. Start Sequence	swapmod-stl A2L / v 01-00 20260725 - initial plate seating before the first print.	["A2L"]	t	a2l_stl	swap_mode_start	gcode	\N	0	;ini swapmod-stl A2L start / v 01-00 20260725\nG0 Z30\nG28 X Y\nG0 X-40 F8000\nG0 Y-1 F3000\nG0 Y50 F1000\nG0 Y290 F5000\nG0 Y265 F1000\nG0 Y334 F3000\nG0 Y-1 F3000\nG0 Y25 F5000\nG0 Y-1 F5000\nG0 Y20 F300\nG0 Y-1 F1000\nG0 Y20 F1000\nG0 Y160 F8000\nG28\n;===== detection start =====\n;===== build_plate_detect_flag start =====\nM1002 judge_flag build_plate_detect_flag\nM622 S1\n  G91\n  G1 Z5 F1200\n  G90\n  G0 X15 F30000\n  G0 Y319 F3000\n  G91\n  G1 Z-5 F1200\n  G28 Z P0 T140\n  G1 F1200\n  G39.4\n  G90\n  G1 Z5 F1200\nM623\n;===== build_plate_detect_flag end =====\n;===== detection end =====\n;ini end	f	t	2026-11-14 23:44:48.145794	2026-11-14 23:44:48.145794	\N	\N
8	A2L. STL Edition. Change Table	swapmod-stl A2L / v 01-00 20260725 - swaps the finished plate out for a fresh one between prints.	["A2L"]	t	a2l_stl	swap_mode_change_table	gcode	\N	0	G4 S0\n; swap swapmod-stl A2L start / v 01-00 20260725\nG0 X-40 F8000\nG0 Y305 F8000\nG0 Y333 F1500\nG0 Z20 F10000\nG0 Z-20 F10000\nG0 Y300 F500\nG0 Z320 F10000\nG0 Y-1 F500\nG0 Y50 F1000\nG0 Y290 F5000\nG0 Y265 F1000\nG0 Y170 F5000\nG0 Y10 Z20 F1000\nG0 Y334 F3000\nG0 Y-1 F3000\nG0 Y25 F5000\nG0 Y-1 F5000\nG0 Y20 F300\nG0 Y-1 F1000\nG0 Y20 F1000\nG0 Y305 F8000\nG0 Y333 F500\nG0 Y120 F8000\nG28 X Y\n;===== detection start =====\n;===== build_plate_detect_flag start =====\nM1002 judge_flag build_plate_detect_flag\nM622 S1\n  G91\n  G1 Z5 F1200\n  G90\n  G0 X15 F30000\n  G0 Y319 F3000\n  G91\n  G1 Z-5 F1200\n  G28 Z P0 T140\n  G1 F1200\n  G39.4\n  G90\n  G1 Z5 F1200\nM623\n;===== build_plate_detect_flag end =====\n;===== detection end =====\n;swap end	f	t	2026-11-14 23:44:48.145794	2026-11-14 23:44:48.145794	\N	\N
\.


--
-- Data for Name: maintenance_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_history (id, printer_maintenance_id, performed_at, hours_at_maintenance, notes, performed_by_user_id, performed_by_chat_id) FROM stdin;
\.


--
-- Data for Name: maintenance_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_types (id, name, description, default_interval_hours, interval_type, icon, wiki_url, printer_models, type_code, is_system, is_deleted, created_at) FROM stdin;
1	Clean Carbon Rods	Wipe carbon rods with a dry cloth	100	hours	Sparkles	\N	["X1C", "X1", "X1E", "P1P", "P1S"]	clean_carbon_rods	t	f	2026-11-14 23:21:18
2	Lubricate Steel Rods	Apply lubricant to steel rods for smooth motion	50	hours	Droplet	\N	["P2S", "X2D"]	lubricate_steel_rods	t	f	2026-11-14 23:21:18
3	Clean Steel Rods	Wipe steel rods with a dry cloth	100	hours	Sparkles	\N	["P2S", "X2D"]	clean_steel_rods	t	f	2026-11-14 23:21:18
4	Lubricate Linear Rails	Apply lubricant to linear rails for smooth motion	50	hours	Droplet	\N	["A1", "A1 Mini", "H2D", "H2D Pro", "H2C", "H2S"]	lubricate_linear_rails	t	f	2026-11-14 23:21:18
5	Clean Linear Rails	Wipe linear rails with a dry cloth to remove dust and debris	100	hours	Sparkles	\N	["A1", "A1 Mini", "H2D", "H2D Pro", "H2C", "H2S"]	clean_linear_rails	t	f	2026-11-14 23:21:18
6	Clean Nozzle/Hotend	Clean nozzle exterior and perform cold pull if needed	100	hours	Flame	\N	["*"]	clean_nozzle	t	f	2026-11-14 23:21:18
7	Check Belt Tension	Verify and adjust belt tension for X/Y axes	200	hours	Ruler	\N	["*"]	check_belt_tension	t	f	2026-11-14 23:21:18
8	Clean Build Plate	Deep clean build plate with IPA or soap	25	hours	Square	\N	["*"]	clean_build_plate	t	f	2026-11-14 23:21:18
9	Check PTFE Tube	Inspect PTFE tube for wear or discoloration	500	hours	Cable	\N	["*"]	check_ptfe_tube	t	f	2026-11-14 23:21:18
\.


--
-- Data for Name: notification_digest_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_digest_queue (id, provider_id, event_type, title, message, printer_id, printer_name, created_at) FROM stdin;
\.


--
-- Data for Name: notification_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_logs (id, provider_id, event_type, title, message, success, error_message, printer_id, printer_name, created_at) FROM stdin;
\.


--
-- Data for Name: notification_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_providers (id, name, provider_type, enabled, config, quiet_hours_enabled, quiet_hours_start, quiet_hours_end, daily_digest_enabled, daily_digest_time, last_success, last_error, last_error_at, created_at, updated_at, progress_min_duration_minutes, printer_ids, subscribed_events) FROM stdin;
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_templates (id, event_type, name, title_template, body_template, is_default, created_at, updated_at) FROM stdin;
1	print_start	Print Started	Print Started	{printer}: {filename}\nEstimated: {estimated_time}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
2	print_complete	Print Completed	Print Completed	{printer}: {filename}\nTime: {duration}\nFilament: {filament_grams}g	t	2026-11-14 23:21:18	2026-11-14 23:21:18
3	print_failed	Print Failed	Print Failed	{printer}: {filename}\nTime: {duration}\nReason: {reason}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
4	print_stopped	Print Stopped	Print Stopped	{printer}: {filename}\nTime: {duration}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
5	print_paused	Print Paused	Print Paused	{printer}: {filename}\nReason: {reason}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
6	print_resumed	Print Resumed	Print Resumed	{printer}: {filename}\nPaused for: {paused_for}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
7	print_progress	Print Progress	Print {progress}% Complete	{printer}: {filename}\nRemaining: {remaining_time}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
8	print_missing_spool_assignment	Missing Spool Assignment	Missing Spool Assignment	{printer}: print started with missing spool assignments\nSlots: {missing_slots}\nExpected profile:\n{missing_slot_details}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
9	printer_offline	Printer Offline	Printer Offline	{printer} has disconnected	t	2026-11-14 23:21:18	2026-11-14 23:21:18
10	printer_error	Printer Error	Printer Error: {error_type}	{printer}\n{error_detail}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
11	ai_failure_detection	AI Failure Detection	Possible Print Failure Detected	{printer}: {task_name}\nConfidence: {confidence}\nAction taken: {action}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
12	plate_not_empty	Plate Not Empty	Plate Not Empty - Print Paused	{printer}: Objects detected on build plate. Print has been paused. Clear plate and resume.	t	2026-11-14 23:21:18	2026-11-14 23:21:18
13	filament_low	Filament Low	Filament Low	{printer}: Slot {slot} at {remaining_percent}%	t	2026-11-14 23:21:18	2026-11-14 23:21:18
14	maintenance_due	Maintenance Due	Maintenance Due	{printer}:\n{items}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
15	ams_humidity_high	AMS Humidity High	AMS Humidity Alert	{printer} {ams_label}: Humidity {humidity}% exceeds {threshold}% threshold	t	2026-11-14 23:21:18	2026-11-14 23:21:18
16	ams_temperature_high	AMS Temperature High	AMS Temperature Alert	{printer} {ams_label}: Temperature {temperature}°C exceeds {threshold}°C threshold	t	2026-11-14 23:21:18	2026-11-14 23:21:18
17	bed_cooled	Bed Cooled	Bed Cooled	{printer}: Bed cooled to {bed_temp}°C (threshold: {threshold}°C)	t	2026-11-14 23:21:18	2026-11-14 23:21:18
18	first_layer_complete	First Layer Complete	First Layer Complete	{printer}: {filename}\nLayer 1/{total_layers} done	t	2026-11-14 23:21:18	2026-11-14 23:21:18
19	test	Test Notification	BamDude Test	This is a test notification. If you see this, notifications are working!	t	2026-11-14 23:21:18	2026-11-14 23:21:18
20	queue_job_added	Queue Job Added	Job Queued	{job_name} added to queue for {target}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
21	queue_job_started	Queue Job Started	Queue Job Started	{printer}: {job_name}\nEstimated: {estimated_time}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
22	queue_job_waiting	Queue Job Waiting	Queue Job Waiting	{job_name} waiting for {target_model}\n{waiting_reason}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
23	queue_job_skipped	Queue Job Skipped	Job Skipped	{printer}: {job_name}\nReason: {reason}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
24	queue_job_failed	Queue Job Failed	Job Failed to Start	{printer}: {job_name}\nReason: {reason}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
25	queue_completed	Queue Completed	Queue Complete	All {completed_count} queued jobs have finished	t	2026-11-14 23:21:18	2026-11-14 23:21:18
26	printer_queue_completed	Printer Queue Completed	Queue Complete	{printer}: queue finished — all jobs done	t	2026-11-14 23:21:18	2026-11-14 23:21:18
29	stock_reorder_alert	Stock Reorder Alert	Reorder Alert: {material}	{material} ({brand}) has reached the reorder point.\nStock: {stock_g}g | Rate: {rate_g_day}g/day | Days left: {days_left}d\nReorder now to avoid a stock break.	t	2026-11-14 23:21:18	2026-11-14 23:21:18
30	stock_break_alert	Stock Break Alert	Stock Break Risk: {material}	{material} ({brand}) will run out before replenishment arrives.\nStock: {stock_g}g | Rate: {rate_g_day}g/day | Lead time: {lead_time_days}d\nOnly {days_left}d of stock remaining — order immediately.	t	2026-11-14 23:21:18	2026-11-14 23:21:18
31	user_print_start	User Print Started Email	Your Print Has Started	Hello {username},\n\nYour print job has started on {printer}.\n\nFile: {filename}\n\nYou will be notified when it completes.	t	2026-11-14 23:21:18	2026-11-14 23:21:18
32	user_print_complete	User Print Completed Email	Your Print Is Complete	Hello {username},\n\nYour print job has completed on {printer}.\n\nFile: {filename}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
33	user_print_failed	User Print Failed Email	Your Print Has Failed	Hello {username},\n\nYour print job has failed on {printer}.\n\nFile: {filename}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
34	user_print_stopped	User Print Stopped Email	Your Print Has Been Stopped	Hello {username},\n\nYour print job was stopped on {printer}.\n\nFile: {filename}	t	2026-11-14 23:21:18	2026-11-14 23:21:18
35	sensor_above_max	Sensor Above Limit	Sensor Alert	{location} — {quantity} {value} {unit}, above {limit}	t	2026-11-14 23:44:45.146845	2026-11-14 23:44:45.146845
36	sensor_below_min	Sensor Below Limit	Sensor Alert	{location} — {quantity} {value} {unit}, below {limit}	t	2026-11-14 23:44:45.146845	2026-11-14 23:44:45.146845
37	sensor_back_in_range	Sensor Back In Range	Sensor Recovered	{location} — {quantity} {value} {unit}, back in range	t	2026-11-14 23:44:45.146845	2026-11-14 23:44:45.146845
38	sensor_silent	Sensor Silent	Sensor Silent	{location} — {sensor} has not reported for {minutes} min	t	2026-11-14 23:44:45.146845	2026-11-14 23:44:45.146845
39	sensor_speaking_again	Sensor Reporting Again	Sensor Recovered	{location} — {sensor} is reporting again	t	2026-11-14 23:44:45.146845	2026-11-14 23:44:45.146845
40	filament_deficit	Filament Will Run Out	Filament Will Run Out	{printer}: {print_name} needs {needed}g in slot {slot}, which holds {available}g — short by {missing}g. The print has started anyway.	t	2026-11-14 23:44:45.369683	2026-11-14 23:44:45.369683
41	ams_drying_suspended	AMS Auto-Drying Suspended	Auto-drying stopped	{printer} {ams_label}: {cycles} drying cycles in a row ended at {humidity}%, still above the {threshold}% threshold. An AMS reads higher while warm, so this threshold cannot be reached here. Automatic drying is paused for this unit until the reading comes down.	t	2026-11-14 23:44:45.388638	2026-11-14 23:44:45.388638
42	scheduled_drying_started	Scheduled Drying Started	Drying started	{printer} {ams_label}: scheduled drying started — {filament}, {temp}°C for {hours} h. {schedule}	t	2026-11-14 23:44:47.462602	2026-11-14 23:44:47.462602
43	scheduled_drying_completed	Scheduled Drying Finished	Drying finished	{printer} {ams_label}: scheduled drying finished ({hours} h at {temp}°C). {schedule}	t	2026-11-14 23:44:47.462602	2026-11-14 23:44:47.462602
44	scheduled_drying_failed	Scheduled Drying Failed	Drying did not happen	{printer} {ams_label}: scheduled drying did not happen — {reason}. {schedule}	t	2026-11-14 23:44:47.462602	2026-11-14 23:44:47.462602
45	ha_sensor_alert	Printer HA Sensor Alert	Printer Sensor Alert	{printer}: {sensor} reports {state}	t	2026-11-14 23:44:47.640666	2026-11-14 23:44:47.640666
46	location_ha_sensor_alert	Storage HA Sensor Alert	Storage Sensor Alert	{location}: {sensor} reports {state}	t	2026-11-14 23:44:47.640666	2026-11-14 23:44:47.640666
47	plug_meter_stalled	Plug Energy Counter Stalled	Plug Energy Counter Stalled	The energy counter of plug {plug} has not changed since {since}, although its power history shows a load. Print energy may be estimated or unknown. Check where the plug's total comes from. If the device has hung, unplug it from the mains and plug it back in once prints have finished; the relay button does not restart its electronics.	t	2026-11-14 23:44:48.508901	2026-11-14 23:44:48.508901
27	user_created	Welcome Email	Welcome to {app_name}	Welcome {username}!\n\nYour account has been created. Your sign-in details are added securely below.	t	2026-11-14 23:21:18	2026-11-14 23:21:18
28	password_reset	Password Reset	{app_name} - Password Reset	Hello {username},\n\nYour password has been reset. Your new sign-in details are added securely below.	t	2026-11-14 23:21:18	2026-11-14 23:21:18
\.


--
-- Data for Name: obico_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.obico_events (id, printer_id, observed_at, verdict, state, size_bytes, sha256, width, height, facts, raw_boxes, invalid_boxes) FROM stdin;
\.


--
-- Data for Name: oidc_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oidc_providers (id, name, issuer_url, client_id, client_secret, scopes, is_enabled, auto_create_users, auto_link_existing_accounts, email_claim, require_email_verified, default_group_id, icon_url, icon_data, icon_content_type, icon_etag, is_autologin, created_at, updated_at, is_env_managed) FROM stdin;
\.


--
-- Data for Name: orca_base_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orca_base_profiles (id, name, profile_type, setting, fetched_at) FROM stdin;
\.


--
-- Data for Name: order_plan_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_plan_receipts (id, operation_id, entry_id, count, outcome, created_at) FROM stdin;
\.


--
-- Data for Name: order_plan_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_plan_submissions (id, plan_id, actor, request_digest, request, status, epoch_advanced, created_at) FROM stdin;
\.


--
-- Data for Name: order_working_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_working_plans (id, revision, schema_version, entries, facts, saved_revision, saved_entries, saved_facts, saved_epoch, saved_at, saved_by, epoch, active_operation, created_at, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: plate_render_objects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plate_render_objects (id, render_id, identify_id, method, reason, width, height, tools) FROM stdin;
\.


--
-- Data for Name: plate_renders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plate_renders (id, file_sha256, plate_index, renderer_version, status, phase, reason, result_dir, manifest_sha256, runtime_version, priority, attempts, next_attempt_at, last_error, requested_at, finished_at, elapsed_ms, orphaned_at) FROM stdin;
\.


--
-- Data for Name: print_archive_parts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.print_archive_parts (id, archive_id, name, name_key, identify_ids, quantity, defective) FROM stdin;
\.


--
-- Data for Name: print_archives; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.print_archives (id, printer_id, project_id, library_file_id, queue_id, batch_id, error_message, filename, file_path, file_size, content_hash, source_content_hash, applied_patches, subtask_id, thumbnail_path, timelapse_path, bamdude_forced_timelapse, source_3mf_path, f3d_path, print_name, print_time_seconds, filament_used_grams, filament_type, filament_color, layer_height, total_layers, nozzle_diameter, bed_temperature, bed_type, nozzle_temperature, sliced_for_model, plate_index, status, started_at, completed_at, actual_time_seconds, time_accuracy, extra_data, makerworld_url, designer, external_url, is_favorite, tags, notes, cost, photos, failure_reason, quantity, energy_kwh, energy_cost, energy_start_kwh, swap_compatible, skip_objects_supported, created_at, deleted_at, created_by_id, is_calibration, calibration_session_id, from_auto_queue, defective_count, project_line_id, swap_source_declaration, recovery_identity, dispatch_phase, dispatch_boot_id, queue_item_identity, source_auto_identity) FROM stdin;
9000	9000	9000	\N	\N	\N	\N	g02-b-fts-orchid.3mf		0	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	completed	2026-01-01 12:00:00	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	1	\N	\N	\N	f	f	2026-01-01 12:00:00	\N	\N	f	\N	f	0	1	\N	2ee04dd2-3738-43ed-ab9f-a687506e607f	\N	\N	\N	\N
\.


--
-- Data for Name: print_completion_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.print_completion_receipts (id, archive_id, assessment, assessment_at, assessment_actor_id, plate_action, plate_action_at, plate_action_actor_id, gate_token, rearmed_queue_item_id, created_at) FROM stdin;
\.


--
-- Data for Name: print_options_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.print_options_preferences (id, user_id, printer_model, options, updated_at) FROM stdin;
\.


--
-- Data for Name: print_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.print_queue (id, queue_id, waiting_reason, archive_id, library_file_id, project_id, "position", scheduled_time, manual_start, auto_off_after, ams_mapping, plate_id, bed_levelling, flow_cali, layer_inspect, timelapse, use_ams, mesh_mode_fast_check, status, execute_swap_macros, swap_macro_events, batch_id, started_at, completed_at, error_message, created_at, created_by_id, source_auto_item_id, gcode_injection, is_calibration, calibration_session_id, nozzle_offset_cali, nozzle_mapping, preheat_override, preheat_chamber_target_override, bed_levelling_mode, flow_cali_mode, nozzle_offset_cali_mode, dispatch_attempts, require_previous_success, gate_acknowledged, selected_macro_ids, timelapse_storage, project_line_id, origin, filament_routing, waiting_reason_code, waiting_reason_checked_at, queue_source_id, source_snapshot, nozzle_rack_choice, auto_eject, auto_eject_settings, swap_declaration_identity, recovery_identity, error_code, source_auto_identity) FROM stdin;
\.


--
-- Data for Name: print_state_recovery_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.print_state_recovery_actions (id, created_at, actor, actor_label, printer_id, queue_id, item_id, archive_id, action, input_hash, result) FROM stdin;
\.


--
-- Data for Name: print_usage_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.print_usage_events (id, printer_id, archive_id, layer_num, event, kind, global_tray_id, spool_id, spoolman_spool_id, created_at, slot_occupied) FROM stdin;
\.


--
-- Data for Name: printer_ha_sensors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_ha_sensors (id, printer_id, name, entity_id, kind, device_class, unit, alert_state, alert_above, alert_below, block_print, notify_on_alert, show_on_printer_card, sort_order, history_revision, last_state, last_changed, last_checked, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: printer_locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_locations (id, name, name_key, created_at, updated_at, parent_id) FROM stdin;
\.


--
-- Data for Name: printer_maintenance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_maintenance (id, printer_id, maintenance_type_id, custom_interval_hours, custom_interval_type, enabled, last_performed_at, last_performed_hours, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: printer_queues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_queues (id, printer_id, status, last_activity_at, current_item_id, pending_count, skipped_count, created_at, updated_at, auto_distribute_eligible, is_paused, recovery_identity) FROM stdin;
\.


--
-- Data for Name: printer_sensor_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_sensor_history (id, printer_id, sensor_kind, value, target, recorded_at) FROM stdin;
\.


--
-- Data for Name: printer_setting_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_setting_audit (id, printer_id, user_id, tab, action, payload_json, sequence_id, result, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: printer_tag_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_tag_links (printer_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: printer_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printer_tags (id, name, name_key, created_at, updated_at, color) FROM stdin;
\.


--
-- Data for Name: printers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.printers (id, name, serial_number, ip_address, access_code, model, nozzle_count, is_active, auto_archive, cleanup_after_print, mqtt_connection_timeout, print_hours_offset, runtime_seconds, last_runtime_update, external_camera_url, external_camera_type, external_camera_enabled, camera_rotation, plate_detection_enabled, plate_detection_roi_x, plate_detection_roi_y, plate_detection_roi_w, plate_detection_roi_h, stagger_interval_minutes, swap_mode_enabled, swap_profile, require_plate_clear, awaiting_plate_clear, created_at, updated_at, external_camera_snapshot_url, archived, archived_at, location_id, mqtt_recording, mqtt_recording_started_at, ams_policies, camera_light_auto, awaiting_plate_clear_archive_id, awaiting_plate_clear_token, plate_detection_polygon, connector_identity) FROM stdin;
9000	B fixture	SYNTHETIC-G02-B	127.0.0.1	synthetic	\N	1	f	f	f	0	0	0	\N	\N	\N	f	0	f	\N	\N	\N	\N	0	f	\N	f	f	2026-11-14 23:21:20	2026-11-14 23:21:20	\N	f	\N	\N	f	\N	{}	inherit	\N	\N	\N	fd694385-92ec-46fb-8b76-3c87d1039d11
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_categories (id, name, name_key, created_at) FROM stdin;
\.


--
-- Data for Name: product_facets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_facets (product_id, library_file_id, kind, value) FROM stdin;
\.


--
-- Data for Name: product_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_files (product_id, library_file_id) FROM stdin;
\.


--
-- Data for Name: product_folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_folders (product_id, library_folder_id) FROM stdin;
\.


--
-- Data for Name: product_part_stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_part_stock_movements (id, product_part_id, delta, reason, project_line_id, archive_id, note, created_by, created_at, stock_item_id, stock_issue_id) FROM stdin;
\.


--
-- Data for Name: product_parts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_parts (id, product_id, kind, name, name_key, qty_per_unit, aliases, auto, unit_price, sourcing_url, remarks, sort_order, variant_option_id, ignored, extra_percent, image_source, image_file_id, image_plate_index, image_identify_id, image_photo) FROM stdin;
\.


--
-- Data for Name: product_plates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_plates (id, product_id, library_file_id, plate_index) FROM stdin;
\.


--
-- Data for Name: product_variant_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variant_groups (id, product_id, name, "position", default_option_id) FROM stdin;
\.


--
-- Data for Name: product_variant_options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_variant_options (id, group_id, name, "position") FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, description, notes, designer, license, source_url, design_id, cover_image_filename, attachments, is_active, created_at, updated_at, origin, origin_file_id, origin_plate_index, sku, sku_key, version, category_id, status) FROM stdin;
1	Historical fixture	\N	\N	\N	\N	\N	\N	\N	\N	t	2026-11-14 23:44:45.834776	2026-11-14 23:44:45.834776	catalog	\N	\N	\N	\N	\N	\N	draft
\.


--
-- Data for Name: project_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_events (id, project_id, created_at, user_id, user_name, kind, payload) FROM stdin;
\.


--
-- Data for Name: project_line_choices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_line_choices (line_id, group_id, option_id) FROM stdin;
\.


--
-- Data for Name: project_line_part_counts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_line_part_counts (line_id, part_id, qty) FROM stdin;
\.


--
-- Data for Name: project_line_part_stock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_line_part_stock (line_id, part_id, received, issued, returned, written_off) FROM stdin;
\.


--
-- Data for Name: project_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_lines (id, project_id, product_id, quantity, material, color, note, sort_order, created_at, updated_at, mode, config_key, from_finished, assembled, received, issued, returned, written_off, extra_percentages, plan_identity, part_count_adjustments) FROM stdin;
1	9000	1	1	\N	\N	\N	0	2026-11-14 23:44:45.834776	2026-11-14 23:44:45.834776	product		0	0	0	0	0	0	{}	17b13a42-e8db-4917-ba81-25d7f4d70e7e	\N
\.


--
-- Data for Name: project_procurement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_procurement (project_id, product_part_id, quantity_acquired) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, name, description, color, status, notes, attachments, tags, due_date, priority, url, cover_image_filename, created_at, updated_at, customer_id, price, contact_id, stage, responsible_id, auto_eject_enabled, auto_eject_settings, order_print_options, printer_resources) FROM stdin;
9000	Historical fixture	\N	\N	completed	\N	\N	\N	\N	0	\N	\N	2026-11-14 23:21:20	2026-11-14 23:21:20	\N	\N	\N	prep	\N	f	\N	\N	\N
\.


--
-- Data for Name: queue_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.queue_sources (id, sha256, size_bytes, relative_path, format, state, created_at, unreferenced_at) FROM stdin;
\.


--
-- Data for Name: scheduled_dryings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scheduled_dryings (id, printer_id, ams_id, temp, duration_hours, filament, rotate_tray, schedule_id, start_after, latest_start, status, reason, detail, created_by_id, created_at, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, key, value, created_at, updated_at) FROM stdin;
1	migration_stagger_group_overrides_v1	1	2026-11-14 23:44:47.317942	2026-11-14 23:44:47.317942
2	connector_server_id	75321c88-427c-49d7-9da2-2f27db6f7ebd	2026-11-14 23:44:48.688555	2026-11-14 23:44:48.688555
3	connector_storage_epoch	37950914-496f-4382-92d8-a9d425347cbc	2026-11-14 23:44:48.689989	2026-11-14 23:44:48.689989
4	_credential_config_guard	1	2026-11-14 23:44:48.757151	2026-11-14 23:44:48.757151
\.


--
-- Data for Name: slicer_pipelines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.slicer_pipelines (id, name, description, printer_preset_source, printer_preset_id, process_preset_source, process_preset_id, filament_presets_json, bed_type, created_by, is_deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: smart_plug_energy_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_plug_energy_snapshots (id, plug_id, recorded_at, lifetime_kwh) FROM stdin;
\.


--
-- Data for Name: smart_plug_meter_incidents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_plug_meter_incidents (id, plug_id, source_id, status, opened_at, flat_since, flat_until, total_kwh, evidence, notified, closed_at, close_reason) FROM stdin;
\.


--
-- Data for Name: smart_plug_power_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_plug_power_history (id, plug_id, power, recorded_at, unusable_reason) FROM stdin;
\.


--
-- Data for Name: smart_plugs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_plugs (id, name, ip_address, plug_type, ha_entity_id, ha_power_entity, ha_energy_today_entity, ha_energy_total_entity, mqtt_topic, mqtt_power_topic, mqtt_power_path, mqtt_power_multiplier, mqtt_energy_topic, mqtt_energy_path, mqtt_energy_multiplier, mqtt_state_topic, mqtt_state_path, mqtt_state_on_value, mqtt_energy_total_topic, mqtt_energy_total_path, mqtt_energy_total_multiplier, mqtt_command_topic, mqtt_command_on, mqtt_command_off, mqtt_multiplier, rest_on_url, rest_on_body, rest_off_url, rest_off_body, rest_method, rest_headers, rest_status_url, rest_status_path, rest_status_on_value, rest_power_url, rest_power_path, rest_power_multiplier, rest_energy_url, rest_energy_path, rest_energy_multiplier, rest_energy_total_path, rest_energy_total_multiplier, printer_id, controls_printer_power, enabled, auto_on, auto_off, auto_off_persistent, off_delay_mode, off_delay_minutes, off_temp_threshold, auto_off_after_drying, off_delay_after_drying_minutes, username, password, power_alert_enabled, power_alert_high, power_alert_low, power_alert_last_triggered, schedule_enabled, schedule_on_time, schedule_off_time, show_in_switchbar, show_on_printer_card, last_state, last_checked, auto_off_executed, auto_off_pending, auto_off_pending_since, created_at, updated_at, zigbee_ieee, measurement_source_id, measurement_source_since, mqtt_expected_power_interval_seconds, meter_min_expected_wh, phantom_watts_risk, meter_watch_cursor) FROM stdin;
\.


--
-- Data for Name: smart_sensor_binding_thresholds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_sensor_binding_thresholds (id, binding_id, kind, custom, min_value, max_value, deadband, enabled, state, state_since, notified_at) FROM stdin;
\.


--
-- Data for Name: smart_sensor_bindings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_sensor_bindings (id, sensor_id, printer_id, printer_location_id, storage_location_id, display_name, visible, sort_order, notify_enabled) FROM stdin;
\.


--
-- Data for Name: smart_sensor_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_sensor_history (id, sensor_id, sensor_kind, value, recorded_at) FROM stdin;
\.


--
-- Data for Name: smart_sensor_thresholds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_sensor_thresholds (id, sensor_id, kind, min_value, max_value, deadband, enabled, state, state_since, notified_at) FROM stdin;
\.


--
-- Data for Name: smart_sensors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.smart_sensors (id, name, zigbee_ieee, created_at, location_id, silent_since, silence_notified_at, printer_id) FROM stdin;
\.


--
-- Data for Name: spool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spool (id, material, subtype, color_name, rgba, brand, label_weight, core_weight, core_weight_catalog_id, weight_used, weight_used_baseline, weight_locked, last_scale_weight, last_weighed_at, slicer_filament, slicer_filament_name, nozzle_temp_min, nozzle_temp_max, note, added_full, cost_per_kg, last_used, encode_time, purchase_date, filament_diameter, lot, tag_uid, storage_location, location_id, purchase_location, tray_uuid, data_origin, tag_type, archived_at, extra_colors, effect_type, category, low_stock_threshold_pct, created_at, updated_at, low_stock_notified, filament_family_id) FROM stdin;
9000	PLA	\N	\N	\N	\N	1000	250	\N	1.25	0.1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1.75	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-11-14 23:21:20	2026-11-14 23:21:20	f	\N
\.


--
-- Data for Name: spool_assignment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spool_assignment (id, spool_id, printer_id, ams_id, tray_id, fingerprint_color, fingerprint_type, created_at) FROM stdin;
\.


--
-- Data for Name: spool_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spool_catalog (id, name, weight, is_default, created_at) FROM stdin;
1	3D FilaPrint - Cardboard	210	t	2026-11-14 23:21:18
2	3D FilaPrint - Plastic	238	t	2026-11-14 23:21:18
3	3D Fuel - Plastic	264	t	2026-11-14 23:21:18
4	3D Power - Plastic	220	t	2026-11-14 23:21:18
5	3D Solutech - Plastic	173	t	2026-11-14 23:21:19
6	3DE - Cardboard	136	t	2026-11-14 23:21:19
7	3DE - Plastic	181	t	2026-11-14 23:21:19
8	3DHOJOR - Cardboard	157	t	2026-11-14 23:21:19
9	3DJake - Cardboard	209	t	2026-11-14 23:21:19
10	3DJake - Plastic	232	t	2026-11-14 23:21:19
11	3DJake 250g - Plastic	91	t	2026-11-14 23:21:19
12	3DJake ecoPLA - Plastic	210	t	2026-11-14 23:21:19
13	3DXTech - Plastic	258	t	2026-11-14 23:21:19
14	Acccreate - Plastic	161	t	2026-11-14 23:21:19
15	Amazon Basics - Plastic	234	t	2026-11-14 23:21:19
16	Amolen - Plastic	150	t	2026-11-14 23:21:19
17	AMZ3D - Plastic	233	t	2026-11-14 23:21:19
18	Anycubic - Cardboard	125	t	2026-11-14 23:21:19
19	Anycubic - Plastic	127	t	2026-11-14 23:21:19
20	Atomic Filament - Plastic	272	t	2026-11-14 23:21:19
21	Aurapol - Plastic	220	t	2026-11-14 23:21:19
22	Azure Film - Plastic	163	t	2026-11-14 23:21:19
23	Bambu Lab - Plastic High Temp	216	t	2026-11-14 23:21:19
24	Bambu Lab - Plastic Low Temp	250	t	2026-11-14 23:21:19
25	Bambu Lab - Plastic White	253	t	2026-11-14 23:21:19
26	BQ - Plastic	218	t	2026-11-14 23:21:19
27	Colorfabb - Plastic	236	t	2026-11-14 23:21:19
28	Colorfabb 750g - Cardboard	152	t	2026-11-14 23:21:19
29	Colorfabb 750g - Plastic	254	t	2026-11-14 23:21:19
30	Comgrow - Cardboard	166	t	2026-11-14 23:21:19
31	Creality - Cardboard	180	t	2026-11-14 23:21:19
32	Creality - Plastic	135	t	2026-11-14 23:21:19
33	Das Filament - Plastic	211	t	2026-11-14 23:21:19
34	Devil Design - Plastic	256	t	2026-11-14 23:21:19
35	Duramic 3D - Cardboard	136	t	2026-11-14 23:21:19
36	Elegoo - Cardboard	153	t	2026-11-14 23:21:19
37	Elegoo - Plastic	111	t	2026-11-14 23:21:19
38	Eryone - Cardboard	156	t	2026-11-14 23:21:19
39	Eryone - Plastic	187	t	2026-11-14 23:21:19
40	eSUN - Cardboard	147	t	2026-11-14 23:21:19
41	eSUN - Plastic	240	t	2026-11-14 23:21:19
42	eSUN 2.5kg - Plastic	634	t	2026-11-14 23:21:19
43	Extrudr - Plastic	244	t	2026-11-14 23:21:19
44	Fiberlogy - Plastic	260	t	2026-11-14 23:21:19
45	Filament PM - Plastic	224	t	2026-11-14 23:21:19
46	Fillamentum - Plastic	230	t	2026-11-14 23:21:19
47	Flashforge - Plastic	167	t	2026-11-14 23:21:19
48	FormFutura - Cardboard	155	t	2026-11-14 23:21:19
49	FormFutura 750g - Plastic	212	t	2026-11-14 23:21:19
50	Geeetech - Plastic	178	t	2026-11-14 23:21:19
51	Gembird - Cardboard	143	t	2026-11-14 23:21:19
52	Hatchbox - Plastic	225	t	2026-11-14 23:21:19
53	Inland - Cardboard	142	t	2026-11-14 23:21:19
54	Inland - Plastic	210	t	2026-11-14 23:21:19
55	Jayo - Cardboard	120	t	2026-11-14 23:21:19
56	Jayo - Plastic	126	t	2026-11-14 23:21:19
57	Jayo 250g - Plastic	58	t	2026-11-14 23:21:19
58	Kingroon - Cardboard	155	t	2026-11-14 23:21:19
59	Kingroon - Plastic	156	t	2026-11-14 23:21:19
60	KVP - Plastic	263	t	2026-11-14 23:21:19
61	Matter Hackers - Plastic	215	t	2026-11-14 23:21:19
62	MG Chemicals - Cardboard	150	t	2026-11-14 23:21:19
63	MG Chemicals - Plastic	239	t	2026-11-14 23:21:19
64	Mika3D - Plastic	175	t	2026-11-14 23:21:19
65	MonoPrice - Plastic	221	t	2026-11-14 23:21:19
66	Overture - Cardboard	150	t	2026-11-14 23:21:19
67	Overture - Plastic	237	t	2026-11-14 23:21:19
68	PolyMaker - Cardboard	137	t	2026-11-14 23:21:19
69	PolyMaker - Plastic	220	t	2026-11-14 23:21:19
70	PolyMaker 3kg - Cardboard	418	t	2026-11-14 23:21:19
71	PolyTerra PLA - Cardboard	147	t	2026-11-14 23:21:19
72	PrimaSelect - Plastic	222	t	2026-11-14 23:21:19
73	ProtoPasta - Cardboard	80	t	2026-11-14 23:21:19
74	Prusament - Plastic	201	t	2026-11-14 23:21:19
75	Prusament - Plastic w/ Cardboard Core	196	t	2026-11-14 23:21:19
76	Rosa3D - Plastic	245	t	2026-11-14 23:21:19
77	Sakata3D - Plastic	205	t	2026-11-14 23:21:19
78	Snapmaker - Cardboard	148	t	2026-11-14 23:21:19
79	Sovol - Cardboard	145	t	2026-11-14 23:21:19
80	Spectrum - Cardboard	180	t	2026-11-14 23:21:19
81	Spectrum - Plastic	257	t	2026-11-14 23:21:19
82	Sunlu - Plastic	117	t	2026-11-14 23:21:19
83	Sunlu - Plastic V2	165	t	2026-11-14 23:21:19
84	Sunlu - Plastic V3	179	t	2026-11-14 23:21:19
85	Sunlu 250g - Plastic	55	t	2026-11-14 23:21:19
86	UltiMaker - Plastic	235	t	2026-11-14 23:21:19
87	Voolt3D - Plastic	190	t	2026-11-14 23:21:19
88	Voxelab - Plastic	171	t	2026-11-14 23:21:19
89	Wanhao - Plastic	267	t	2026-11-14 23:21:19
90	Ziro - Plastic	166	t	2026-11-14 23:21:19
91	ZYLtech - Plastic	179	t	2026-11-14 23:21:19
\.


--
-- Data for Name: spool_k_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spool_k_profile (id, spool_id, printer_id, extruder, filament_calibration_id, auto_linked, created_at) FROM stdin;
\.


--
-- Data for Name: spool_usage_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spool_usage_history (id, spool_id, printer_id, print_name, archive_id, weight_used, percent_used, status, cost, created_at) FROM stdin;
9000	9000	\N	Historical fixture	9000	1.25	1	completed	0.025	2026-11-14 23:21:20
\.


--
-- Data for Name: spoolman_k_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spoolman_k_profile (id, spoolman_spool_id, printer_id, extruder, filament_calibration_id, auto_linked, created_at) FROM stdin;
\.


--
-- Data for Name: spoolman_slot_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spoolman_slot_assignments (id, printer_id, ams_id, tray_id, spoolman_spool_id, assigned_at) FROM stdin;
\.


--
-- Data for Name: stock_issue_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_issue_lines (id, issue_id, "position", product_id, product_name, sku, configuration, part_name, quantity) FROM stdin;
\.


--
-- Data for Name: stock_issues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_issues (id, project_id, customer_id, customer_name, recipient_name, recipient_phone, delivery_method, delivery_details, waybill, note, created_by, created_at, supplier, created_by_name, order_code, order_name, units) FROM stdin;
\.


--
-- Data for Name: stock_item_choices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_item_choices (item_id, group_id, option_id) FROM stdin;
\.


--
-- Data for Name: stock_item_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_item_movements (id, item_id, kind, delta_on_hand, delta_reserved, note, customer_id, project_id, project_line_id, created_by, created_at, stock_issue_id) FROM stdin;
\.


--
-- Data for Name: stock_item_part_counts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_item_part_counts (item_id, part_id, qty) FROM stdin;
\.


--
-- Data for Name: stock_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_items (id, product_id, config_key, on_hand, reserved, location, min_qty, created_at) FROM stdin;
\.


--
-- Data for Name: swap_source_declaration_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.swap_source_declaration_audit (id, operation_id, action, source_kind, source_id, sha256, old_value, new_value, declaration_id, previous_declaration_id, actor_id, actor_label, actor_kind, revision_before, revision_after, request_digest, jobs, created_at) FROM stdin;
\.


--
-- Data for Name: telegram_chats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.telegram_chats (id, chat_id, label, group_id, user_id, is_active, notify_events, daily_digest, quiet_hours_enabled, quiet_hours_start, quiet_hours_end, created_at, updated_at, progress_min_duration_minutes, printer_ids, provider_id) FROM stdin;
\.


--
-- Data for Name: user_email_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_email_preferences (id, user_id, notify_print_start, notify_print_complete, notify_print_failed, notify_print_stopped, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_filament_families; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_filament_families (id, filament_id, ecosystem, alias, vendor, filament_type, origin, orphaned, created_at) FROM stdin;
\.


--
-- Data for Name: user_filament_presets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_filament_presets (id, owner_user_id, ecosystem, source, cloud_id, local_preset_id, name, family_filament_id, base_ref, vendor, filament_type, nozzle_temp_min, nozzle_temp_max, updated_time, synced_at, pushed_cloud_id, pushed_at, push_dirty, orca_pushed_profile_id, orca_pushed_at, orca_push_dirty, orca_pushed_updated_time) FROM stdin;
\.


--
-- Data for Name: user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_groups (user_id, group_id) FROM stdin;
\.


--
-- Data for Name: user_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_notifications (id, user_id, event_type, severity, title, message, printer_id, printer_name, extra_data, created_at, read_at) FROM stdin;
\.


--
-- Data for Name: user_oidc_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_oidc_links (id, user_id, provider_id, provider_user_id, provider_email, created_at) FROM stdin;
\.


--
-- Data for Name: user_otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_otp_codes (id, user_id, code_hash, attempts, used, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_totp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_totp (id, user_id, secret, is_enabled, backup_codes_json, last_totp_counter, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, role, auth_source, is_active, password_changed_at, created_at, updated_at, cloud_token, cloud_email, cloud_region, cloud_token_invalid_at, orca_cloud_token, orca_cloud_refresh_token, orca_cloud_expires_at, orca_cloud_email, orca_cloud_user_id, orca_cloud_pending_verifier, orca_cloud_pending_state, orca_cloud_pending_at, cloud_refresh_token, orca_cloud_scope, inbox_events) FROM stdin;
9000	b_fixture	\N	\N	user	local	f	\N	2026-11-14 23:21:20	2026-11-14 23:21:20	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: virtual_printers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.virtual_printers (id, name, enabled, mode, auto_dispatch, queue_force_color_match, gcode_injection, model, access_code, target_printer_id, target_folder_id, bind_ip, remote_interface_ip, serial_suffix, tailscale_disabled, "position", created_at, updated_at, save_ams_mapping, nozzle_diameter, nozzle_flow) FROM stdin;
\.


--
-- Data for Name: zigbee_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.zigbee_devices (ieee, kind, name, reporting, poll_seconds, stale_after_seconds, first_seen_at, last_seen_at) FROM stdin;
\.


--
-- Name: _migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public._migrations_id_seq', 220, true);


--
-- Name: active_print_spoolman_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.active_print_spoolman_id_seq', 1, false);


--
-- Name: ams_labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ams_labels_id_seq', 1, false);


--
-- Name: ams_sensor_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ams_sensor_history_id_seq', 1, false);


--
-- Name: ams_setting_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ams_setting_audit_id_seq', 1, false);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 1, false);


--
-- Name: auth_ephemeral_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_ephemeral_tokens_id_seq', 1, false);


--
-- Name: auth_rate_limit_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_rate_limit_events_id_seq', 1, false);


--
-- Name: auto_queue_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auto_queue_items_id_seq', 1, false);


--
-- Name: bug_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bug_reports_id_seq', 1, false);


--
-- Name: calibration_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.calibration_audit_id_seq', 1, false);


--
-- Name: calibration_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.calibration_session_id_seq', 1, false);


--
-- Name: cameras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cameras_id_seq', 1, false);


--
-- Name: cloud_link_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cloud_link_audit_id_seq', 1, false);


--
-- Name: color_catalog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.color_catalog_id_seq', 659, true);


--
-- Name: connector_submission_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.connector_submission_entries_id_seq', 1, false);


--
-- Name: connector_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.connector_submissions_id_seq', 1, false);


--
-- Name: customer_contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_contacts_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: delivery_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.delivery_methods_id_seq', 3, true);


--
-- Name: drying_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.drying_schedules_id_seq', 1, false);


--
-- Name: external_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.external_links_id_seq', 1, false);


--
-- Name: filament_calibration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filament_calibration_id_seq', 1, false);


--
-- Name: filament_shopping_list_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filament_shopping_list_id_seq', 1, false);


--
-- Name: filament_sku_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filament_sku_settings_id_seq', 1, false);


--
-- Name: firmware_batch_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.firmware_batch_items_id_seq', 1, false);


--
-- Name: firmware_batch_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.firmware_batch_runs_id_seq', 1, false);


--
-- Name: firmware_cache_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.firmware_cache_entries_id_seq', 1, false);


--
-- Name: git_backup_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.git_backup_config_id_seq', 1, false);


--
-- Name: git_backup_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.git_backup_logs_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.groups_id_seq', 3, true);


--
-- Name: ha_sensor_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ha_sensor_history_id_seq', 1, false);


--
-- Name: hms_muted_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hms_muted_entries_id_seq', 1, false);


--
-- Name: kprofile_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kprofile_notes_id_seq', 1, false);


--
-- Name: label_cassettes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.label_cassettes_id_seq', 1, false);


--
-- Name: label_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.label_devices_id_seq', 1, false);


--
-- Name: label_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.label_jobs_id_seq', 1, false);


--
-- Name: label_sheets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.label_sheets_id_seq', 2, true);


--
-- Name: label_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.label_templates_id_seq', 6, true);


--
-- Name: library_file_makerworld_meta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_file_makerworld_meta_id_seq', 1, false);


--
-- Name: library_file_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_file_notes_id_seq', 1, false);


--
-- Name: library_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_files_id_seq', 1, false);


--
-- Name: library_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_folders_id_seq', 1, false);


--
-- Name: library_scan_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_scan_jobs_id_seq', 1, false);


--
-- Name: library_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_tags_id_seq', 11, true);


--
-- Name: local_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.local_presets_id_seq', 1, false);


--
-- Name: location_ha_sensors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.location_ha_sensors_id_seq', 1, false);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.locations_id_seq', 1, false);


--
-- Name: long_lived_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.long_lived_tokens_id_seq', 1, false);


--
-- Name: macros_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.macros_id_seq', 8, true);


--
-- Name: maintenance_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenance_history_id_seq', 1, false);


--
-- Name: maintenance_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenance_types_id_seq', 9, true);


--
-- Name: notification_digest_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_digest_queue_id_seq', 1, false);


--
-- Name: notification_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_logs_id_seq', 1, false);


--
-- Name: notification_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_providers_id_seq', 1, false);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_templates_id_seq', 47, true);


--
-- Name: oidc_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oidc_providers_id_seq', 1, false);


--
-- Name: orca_base_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orca_base_profiles_id_seq', 1, false);


--
-- Name: plate_render_objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plate_render_objects_id_seq', 1, false);


--
-- Name: plate_renders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plate_renders_id_seq', 1, false);


--
-- Name: print_archive_parts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.print_archive_parts_id_seq', 1, false);


--
-- Name: print_archives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.print_archives_id_seq', 9000, true);


--
-- Name: print_completion_receipts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.print_completion_receipts_id_seq', 1, false);


--
-- Name: print_options_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.print_options_preferences_id_seq', 1, false);


--
-- Name: print_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.print_queue_id_seq', 1, false);


--
-- Name: print_usage_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.print_usage_events_id_seq', 1, false);


--
-- Name: printer_ha_sensors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printer_ha_sensors_id_seq', 1, false);


--
-- Name: printer_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printer_locations_id_seq', 1, false);


--
-- Name: printer_maintenance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printer_maintenance_id_seq', 1, false);


--
-- Name: printer_queues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printer_queues_id_seq', 1, false);


--
-- Name: printer_sensor_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printer_sensor_history_id_seq', 1, false);


--
-- Name: printer_setting_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printer_setting_audit_id_seq', 1, false);


--
-- Name: printer_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printer_tags_id_seq', 1, false);


--
-- Name: printers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.printers_id_seq', 9000, true);


--
-- Name: product_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_categories_id_seq', 1, false);


--
-- Name: product_part_stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_part_stock_movements_id_seq', 1, false);


--
-- Name: product_parts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_parts_id_seq', 1, false);


--
-- Name: product_plates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_plates_id_seq', 1, false);


--
-- Name: product_variant_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_variant_groups_id_seq', 1, false);


--
-- Name: product_variant_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_variant_options_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 1, true);


--
-- Name: project_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_events_id_seq', 1, false);


--
-- Name: project_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_lines_id_seq', 1, true);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 9000, true);


--
-- Name: queue_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.queue_sources_id_seq', 1, false);


--
-- Name: scheduled_dryings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scheduled_dryings_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settings_id_seq', 4, true);


--
-- Name: slicer_pipelines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.slicer_pipelines_id_seq', 1, false);


--
-- Name: smart_plug_energy_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_plug_energy_snapshots_id_seq', 1, false);


--
-- Name: smart_plug_meter_incidents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_plug_meter_incidents_id_seq', 1, false);


--
-- Name: smart_plug_power_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_plug_power_history_id_seq', 1, false);


--
-- Name: smart_plugs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_plugs_id_seq', 1, false);


--
-- Name: smart_sensor_binding_thresholds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_sensor_binding_thresholds_id_seq', 1, false);


--
-- Name: smart_sensor_bindings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_sensor_bindings_id_seq', 1, false);


--
-- Name: smart_sensor_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_sensor_history_id_seq', 1, false);


--
-- Name: smart_sensor_thresholds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_sensor_thresholds_id_seq', 1, false);


--
-- Name: smart_sensors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.smart_sensors_id_seq', 1, false);


--
-- Name: spool_assignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spool_assignment_id_seq', 1, false);


--
-- Name: spool_catalog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spool_catalog_id_seq', 91, true);


--
-- Name: spool_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spool_id_seq', 9000, true);


--
-- Name: spool_k_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spool_k_profile_id_seq', 1, false);


--
-- Name: spool_usage_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spool_usage_history_id_seq', 9000, true);


--
-- Name: spoolman_k_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spoolman_k_profile_id_seq', 1, false);


--
-- Name: spoolman_slot_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.spoolman_slot_assignments_id_seq', 1, false);


--
-- Name: stock_issue_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_issue_lines_id_seq', 1, false);


--
-- Name: stock_issues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_issues_id_seq', 1, false);


--
-- Name: stock_item_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_item_movements_id_seq', 1, false);


--
-- Name: stock_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_items_id_seq', 1, false);


--
-- Name: swap_source_declaration_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.swap_source_declaration_audit_id_seq', 1, false);


--
-- Name: telegram_chats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.telegram_chats_id_seq', 1, false);


--
-- Name: user_email_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_email_preferences_id_seq', 1, false);


--
-- Name: user_filament_families_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_filament_families_id_seq', 1, false);


--
-- Name: user_filament_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_filament_presets_id_seq', 1, false);


--
-- Name: user_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_notifications_id_seq', 1, false);


--
-- Name: user_oidc_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_oidc_links_id_seq', 1, false);


--
-- Name: user_otp_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_otp_codes_id_seq', 1, false);


--
-- Name: user_totp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_totp_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 9000, true);


--
-- Name: virtual_printers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.virtual_printers_id_seq', 1, false);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (id);


--
-- Name: _migrations _migrations_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_version_key UNIQUE (version);


--
-- Name: active_print_spoolman active_print_spoolman_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_print_spoolman
    ADD CONSTRAINT active_print_spoolman_pkey PRIMARY KEY (id);


--
-- Name: ams_labels ams_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_labels
    ADD CONSTRAINT ams_labels_pkey PRIMARY KEY (id);


--
-- Name: ams_sensor_history ams_sensor_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_sensor_history
    ADD CONSTRAINT ams_sensor_history_pkey PRIMARY KEY (id);


--
-- Name: ams_setting_audit ams_setting_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_setting_audit
    ADD CONSTRAINT ams_setting_audit_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: auth_ephemeral_tokens auth_ephemeral_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_ephemeral_tokens
    ADD CONSTRAINT auth_ephemeral_tokens_pkey PRIMARY KEY (id);


--
-- Name: auth_rate_limit_events auth_rate_limit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_rate_limit_events
    ADD CONSTRAINT auth_rate_limit_events_pkey PRIMARY KEY (id);


--
-- Name: auto_queue_items auto_queue_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_pkey PRIMARY KEY (id);


--
-- Name: bug_reports bug_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bug_reports
    ADD CONSTRAINT bug_reports_pkey PRIMARY KEY (id);


--
-- Name: calibration_audit calibration_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit
    ADD CONSTRAINT calibration_audit_pkey PRIMARY KEY (id);


--
-- Name: calibration_session calibration_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session
    ADD CONSTRAINT calibration_session_pkey PRIMARY KEY (id);


--
-- Name: cameras cameras_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT cameras_name_key UNIQUE (name);


--
-- Name: cameras cameras_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT cameras_pkey PRIMARY KEY (id);


--
-- Name: cloud_link_audit cloud_link_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloud_link_audit
    ADD CONSTRAINT cloud_link_audit_pkey PRIMARY KEY (id);


--
-- Name: cloud_link cloud_link_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloud_link
    ADD CONSTRAINT cloud_link_pkey PRIMARY KEY (id);


--
-- Name: cloud_link_printers cloud_link_printers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloud_link_printers
    ADD CONSTRAINT cloud_link_printers_pkey PRIMARY KEY (printer_id);


--
-- Name: color_catalog color_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.color_catalog
    ADD CONSTRAINT color_catalog_pkey PRIMARY KEY (id);


--
-- Name: connector_submission_entries connector_submission_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_submission_entries
    ADD CONSTRAINT connector_submission_entries_pkey PRIMARY KEY (id);


--
-- Name: connector_submissions connector_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_submissions
    ADD CONSTRAINT connector_submissions_pkey PRIMARY KEY (id);


--
-- Name: customer_contacts customer_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_contacts
    ADD CONSTRAINT customer_contacts_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: delivery_methods delivery_methods_name_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_methods
    ADD CONSTRAINT delivery_methods_name_key_key UNIQUE (name_key);


--
-- Name: delivery_methods delivery_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_methods
    ADD CONSTRAINT delivery_methods_pkey PRIMARY KEY (id);


--
-- Name: drying_schedules drying_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drying_schedules
    ADD CONSTRAINT drying_schedules_pkey PRIMARY KEY (id);


--
-- Name: external_links external_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_links
    ADD CONSTRAINT external_links_pkey PRIMARY KEY (id);


--
-- Name: filament_calibration filament_calibration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_calibration
    ADD CONSTRAINT filament_calibration_pkey PRIMARY KEY (id);


--
-- Name: filament_shopping_list filament_shopping_list_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_shopping_list
    ADD CONSTRAINT filament_shopping_list_pkey PRIMARY KEY (id);


--
-- Name: filament_sku_settings filament_sku_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_sku_settings
    ADD CONSTRAINT filament_sku_settings_pkey PRIMARY KEY (id);


--
-- Name: firmware_batch_items firmware_batch_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.firmware_batch_items
    ADD CONSTRAINT firmware_batch_items_pkey PRIMARY KEY (id);


--
-- Name: firmware_batch_runs firmware_batch_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.firmware_batch_runs
    ADD CONSTRAINT firmware_batch_runs_pkey PRIMARY KEY (id);


--
-- Name: firmware_cache_entries firmware_cache_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.firmware_cache_entries
    ADD CONSTRAINT firmware_cache_entries_pkey PRIMARY KEY (id);


--
-- Name: git_backup_config git_backup_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_backup_config
    ADD CONSTRAINT git_backup_config_pkey PRIMARY KEY (id);


--
-- Name: git_backup_logs git_backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_backup_logs
    ADD CONSTRAINT git_backup_logs_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: ha_sensor_history ha_sensor_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ha_sensor_history
    ADD CONSTRAINT ha_sensor_history_pkey PRIMARY KEY (id);


--
-- Name: hms_muted_entries hms_muted_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hms_muted_entries
    ADD CONSTRAINT hms_muted_entries_pkey PRIMARY KEY (id);


--
-- Name: kprofile_notes kprofile_notes_filament_calibration_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kprofile_notes
    ADD CONSTRAINT kprofile_notes_filament_calibration_id_key UNIQUE (filament_calibration_id);


--
-- Name: kprofile_notes kprofile_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kprofile_notes
    ADD CONSTRAINT kprofile_notes_pkey PRIMARY KEY (id);


--
-- Name: label_cassettes label_cassettes_barcode_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_cassettes
    ADD CONSTRAINT label_cassettes_barcode_key UNIQUE (barcode);


--
-- Name: label_cassettes label_cassettes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_cassettes
    ADD CONSTRAINT label_cassettes_pkey PRIMARY KEY (id);


--
-- Name: label_devices label_devices_installation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_devices
    ADD CONSTRAINT label_devices_installation_id_key UNIQUE (installation_id);


--
-- Name: label_devices label_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_devices
    ADD CONSTRAINT label_devices_pkey PRIMARY KEY (id);


--
-- Name: label_jobs label_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_jobs
    ADD CONSTRAINT label_jobs_pkey PRIMARY KEY (id);


--
-- Name: label_sheets label_sheets_builtin_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_sheets
    ADD CONSTRAINT label_sheets_builtin_key_key UNIQUE (builtin_key);


--
-- Name: label_sheets label_sheets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_sheets
    ADD CONSTRAINT label_sheets_pkey PRIMARY KEY (id);


--
-- Name: label_templates label_templates_builtin_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_templates
    ADD CONSTRAINT label_templates_builtin_key_key UNIQUE (builtin_key);


--
-- Name: label_templates label_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_templates
    ADD CONSTRAINT label_templates_pkey PRIMARY KEY (id);


--
-- Name: library_file_makerworld_meta library_file_makerworld_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_makerworld_meta
    ADD CONSTRAINT library_file_makerworld_meta_pkey PRIMARY KEY (id);


--
-- Name: library_file_notes library_file_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_notes
    ADD CONSTRAINT library_file_notes_pkey PRIMARY KEY (id);


--
-- Name: library_file_tags library_file_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_tags
    ADD CONSTRAINT library_file_tags_pkey PRIMARY KEY (file_id, tag_id);


--
-- Name: library_files library_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_files
    ADD CONSTRAINT library_files_pkey PRIMARY KEY (id);


--
-- Name: library_folders library_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folders
    ADD CONSTRAINT library_folders_pkey PRIMARY KEY (id);


--
-- Name: library_scan_jobs library_scan_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_scan_jobs
    ADD CONSTRAINT library_scan_jobs_pkey PRIMARY KEY (id);


--
-- Name: library_tags library_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_tags
    ADD CONSTRAINT library_tags_pkey PRIMARY KEY (id);


--
-- Name: local_presets local_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.local_presets
    ADD CONSTRAINT local_presets_pkey PRIMARY KEY (id);


--
-- Name: location_ha_sensors location_ha_sensors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_ha_sensors
    ADD CONSTRAINT location_ha_sensors_pkey PRIMARY KEY (id);


--
-- Name: location_sensor_primary location_sensor_primary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_sensor_primary
    ADD CONSTRAINT location_sensor_primary_pkey PRIMARY KEY (location_id, category);


--
-- Name: locations locations_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_name_key UNIQUE (name);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: long_lived_tokens long_lived_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.long_lived_tokens
    ADD CONSTRAINT long_lived_tokens_pkey PRIMARY KEY (id);


--
-- Name: macros macros_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.macros
    ADD CONSTRAINT macros_pkey PRIMARY KEY (id);


--
-- Name: maintenance_history maintenance_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_pkey PRIMARY KEY (id);


--
-- Name: maintenance_types maintenance_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_types
    ADD CONSTRAINT maintenance_types_pkey PRIMARY KEY (id);


--
-- Name: notification_digest_queue notification_digest_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_digest_queue
    ADD CONSTRAINT notification_digest_queue_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_providers notification_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_providers
    ADD CONSTRAINT notification_providers_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_event_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_event_type_key UNIQUE (event_type);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: obico_events obico_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obico_events
    ADD CONSTRAINT obico_events_pkey PRIMARY KEY (id);


--
-- Name: oidc_providers oidc_providers_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_name_key UNIQUE (name);


--
-- Name: oidc_providers oidc_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_pkey PRIMARY KEY (id);


--
-- Name: orca_base_profiles orca_base_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orca_base_profiles
    ADD CONSTRAINT orca_base_profiles_pkey PRIMARY KEY (id);


--
-- Name: order_plan_receipts order_plan_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_plan_receipts
    ADD CONSTRAINT order_plan_receipts_pkey PRIMARY KEY (id);


--
-- Name: order_plan_submissions order_plan_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_plan_submissions
    ADD CONSTRAINT order_plan_submissions_pkey PRIMARY KEY (id);


--
-- Name: order_working_plans order_working_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_working_plans
    ADD CONSTRAINT order_working_plans_pkey PRIMARY KEY (id);


--
-- Name: plate_render_objects plate_render_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_render_objects
    ADD CONSTRAINT plate_render_objects_pkey PRIMARY KEY (id);


--
-- Name: plate_renders plate_renders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_renders
    ADD CONSTRAINT plate_renders_pkey PRIMARY KEY (id);


--
-- Name: print_archive_parts print_archive_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archive_parts
    ADD CONSTRAINT print_archive_parts_pkey PRIMARY KEY (id);


--
-- Name: print_archives print_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_pkey PRIMARY KEY (id);


--
-- Name: print_completion_receipts print_completion_receipts_archive_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_completion_receipts
    ADD CONSTRAINT print_completion_receipts_archive_id_key UNIQUE (archive_id);


--
-- Name: print_completion_receipts print_completion_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_completion_receipts
    ADD CONSTRAINT print_completion_receipts_pkey PRIMARY KEY (id);


--
-- Name: print_options_preferences print_options_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_options_preferences
    ADD CONSTRAINT print_options_preferences_pkey PRIMARY KEY (id);


--
-- Name: print_queue print_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_pkey PRIMARY KEY (id);


--
-- Name: print_state_recovery_actions print_state_recovery_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_state_recovery_actions
    ADD CONSTRAINT print_state_recovery_actions_pkey PRIMARY KEY (id);


--
-- Name: print_usage_events print_usage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_usage_events
    ADD CONSTRAINT print_usage_events_pkey PRIMARY KEY (id);


--
-- Name: printer_ha_sensors printer_ha_sensors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_ha_sensors
    ADD CONSTRAINT printer_ha_sensors_pkey PRIMARY KEY (id);


--
-- Name: printer_locations printer_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_locations
    ADD CONSTRAINT printer_locations_pkey PRIMARY KEY (id);


--
-- Name: printer_maintenance printer_maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_maintenance
    ADD CONSTRAINT printer_maintenance_pkey PRIMARY KEY (id);


--
-- Name: printer_queues printer_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_queues
    ADD CONSTRAINT printer_queues_pkey PRIMARY KEY (id);


--
-- Name: printer_queues printer_queues_printer_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_queues
    ADD CONSTRAINT printer_queues_printer_id_key UNIQUE (printer_id);


--
-- Name: printer_sensor_history printer_sensor_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_sensor_history
    ADD CONSTRAINT printer_sensor_history_pkey PRIMARY KEY (id);


--
-- Name: printer_setting_audit printer_setting_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_setting_audit
    ADD CONSTRAINT printer_setting_audit_pkey PRIMARY KEY (id);


--
-- Name: printer_tag_links printer_tag_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_tag_links
    ADD CONSTRAINT printer_tag_links_pkey PRIMARY KEY (printer_id, tag_id);


--
-- Name: printer_tags printer_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_tags
    ADD CONSTRAINT printer_tags_pkey PRIMARY KEY (id);


--
-- Name: printers printers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printers
    ADD CONSTRAINT printers_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_name_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_name_key_key UNIQUE (name_key);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: product_facets product_facets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_facets
    ADD CONSTRAINT product_facets_pkey PRIMARY KEY (product_id, library_file_id, kind, value);


--
-- Name: product_files product_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_files
    ADD CONSTRAINT product_files_pkey PRIMARY KEY (product_id, library_file_id);


--
-- Name: product_folders product_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_folders
    ADD CONSTRAINT product_folders_pkey PRIMARY KEY (product_id, library_folder_id);


--
-- Name: product_part_stock_movements product_part_stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_part_stock_movements
    ADD CONSTRAINT product_part_stock_movements_pkey PRIMARY KEY (id);


--
-- Name: product_parts product_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parts
    ADD CONSTRAINT product_parts_pkey PRIMARY KEY (id);


--
-- Name: product_plates product_plates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_plates
    ADD CONSTRAINT product_plates_pkey PRIMARY KEY (id);


--
-- Name: product_variant_groups product_variant_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_groups
    ADD CONSTRAINT product_variant_groups_pkey PRIMARY KEY (id);


--
-- Name: product_variant_options product_variant_options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_options
    ADD CONSTRAINT product_variant_options_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: project_events project_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_events
    ADD CONSTRAINT project_events_pkey PRIMARY KEY (id);


--
-- Name: project_line_choices project_line_choices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_line_choices
    ADD CONSTRAINT project_line_choices_pkey PRIMARY KEY (line_id, group_id);


--
-- Name: project_line_part_counts project_line_part_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_line_part_counts
    ADD CONSTRAINT project_line_part_counts_pkey PRIMARY KEY (line_id, part_id);


--
-- Name: project_line_part_stock project_line_part_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_line_part_stock
    ADD CONSTRAINT project_line_part_stock_pkey PRIMARY KEY (line_id, part_id);


--
-- Name: project_lines project_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lines
    ADD CONSTRAINT project_lines_pkey PRIMARY KEY (id);


--
-- Name: project_procurement project_procurement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_procurement
    ADD CONSTRAINT project_procurement_pkey PRIMARY KEY (project_id, product_part_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: queue_sources queue_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queue_sources
    ADD CONSTRAINT queue_sources_pkey PRIMARY KEY (id);


--
-- Name: scheduled_dryings scheduled_dryings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_dryings
    ADD CONSTRAINT scheduled_dryings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: slicer_pipelines slicer_pipelines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slicer_pipelines
    ADD CONSTRAINT slicer_pipelines_pkey PRIMARY KEY (id);


--
-- Name: smart_plug_energy_snapshots smart_plug_energy_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_energy_snapshots
    ADD CONSTRAINT smart_plug_energy_snapshots_pkey PRIMARY KEY (id);


--
-- Name: smart_plug_meter_incidents smart_plug_meter_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_meter_incidents
    ADD CONSTRAINT smart_plug_meter_incidents_pkey PRIMARY KEY (id);


--
-- Name: smart_plug_power_history smart_plug_power_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_power_history
    ADD CONSTRAINT smart_plug_power_history_pkey PRIMARY KEY (id);


--
-- Name: smart_plugs smart_plugs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plugs
    ADD CONSTRAINT smart_plugs_pkey PRIMARY KEY (id);


--
-- Name: smart_sensor_binding_thresholds smart_sensor_binding_thresholds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_binding_thresholds
    ADD CONSTRAINT smart_sensor_binding_thresholds_pkey PRIMARY KEY (id);


--
-- Name: smart_sensor_bindings smart_sensor_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_bindings
    ADD CONSTRAINT smart_sensor_bindings_pkey PRIMARY KEY (id);


--
-- Name: smart_sensor_history smart_sensor_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_history
    ADD CONSTRAINT smart_sensor_history_pkey PRIMARY KEY (id);


--
-- Name: smart_sensor_thresholds smart_sensor_thresholds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_thresholds
    ADD CONSTRAINT smart_sensor_thresholds_pkey PRIMARY KEY (id);


--
-- Name: smart_sensors smart_sensors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensors
    ADD CONSTRAINT smart_sensors_pkey PRIMARY KEY (id);


--
-- Name: smart_sensors smart_sensors_zigbee_ieee_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensors
    ADD CONSTRAINT smart_sensors_zigbee_ieee_key UNIQUE (zigbee_ieee);


--
-- Name: spool_assignment spool_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_assignment
    ADD CONSTRAINT spool_assignment_pkey PRIMARY KEY (id);


--
-- Name: spool_assignment spool_assignment_printer_id_ams_id_tray_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_assignment
    ADD CONSTRAINT spool_assignment_printer_id_ams_id_tray_id_key UNIQUE (printer_id, ams_id, tray_id);


--
-- Name: spool_catalog spool_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_catalog
    ADD CONSTRAINT spool_catalog_pkey PRIMARY KEY (id);


--
-- Name: spool_k_profile spool_k_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_k_profile
    ADD CONSTRAINT spool_k_profile_pkey PRIMARY KEY (id);


--
-- Name: spool spool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool
    ADD CONSTRAINT spool_pkey PRIMARY KEY (id);


--
-- Name: spool_usage_history spool_usage_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_usage_history
    ADD CONSTRAINT spool_usage_history_pkey PRIMARY KEY (id);


--
-- Name: spoolman_k_profile spoolman_k_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_k_profile
    ADD CONSTRAINT spoolman_k_profile_pkey PRIMARY KEY (id);


--
-- Name: spoolman_k_profile spoolman_k_profile_spoolman_spool_id_printer_id_extruder_fi_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_k_profile
    ADD CONSTRAINT spoolman_k_profile_spoolman_spool_id_printer_id_extruder_fi_key UNIQUE (spoolman_spool_id, printer_id, extruder, filament_calibration_id);


--
-- Name: spoolman_slot_assignments spoolman_slot_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_slot_assignments
    ADD CONSTRAINT spoolman_slot_assignments_pkey PRIMARY KEY (id);


--
-- Name: stock_issue_lines stock_issue_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_issue_lines
    ADD CONSTRAINT stock_issue_lines_pkey PRIMARY KEY (id);


--
-- Name: stock_issues stock_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_issues
    ADD CONSTRAINT stock_issues_pkey PRIMARY KEY (id);


--
-- Name: stock_item_choices stock_item_choices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_choices
    ADD CONSTRAINT stock_item_choices_pkey PRIMARY KEY (item_id, group_id);


--
-- Name: stock_item_movements stock_item_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_movements
    ADD CONSTRAINT stock_item_movements_pkey PRIMARY KEY (id);


--
-- Name: stock_item_part_counts stock_item_part_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_part_counts
    ADD CONSTRAINT stock_item_part_counts_pkey PRIMARY KEY (item_id, part_id);


--
-- Name: stock_items stock_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT stock_items_pkey PRIMARY KEY (id);


--
-- Name: swap_source_declaration_audit swap_source_declaration_audit_operation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swap_source_declaration_audit
    ADD CONSTRAINT swap_source_declaration_audit_operation_id_key UNIQUE (operation_id);


--
-- Name: swap_source_declaration_audit swap_source_declaration_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swap_source_declaration_audit
    ADD CONSTRAINT swap_source_declaration_audit_pkey PRIMARY KEY (id);


--
-- Name: telegram_chats telegram_chats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_pkey PRIMARY KEY (id);


--
-- Name: ams_labels uq_ams_label_serial; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_labels
    ADD CONSTRAINT uq_ams_label_serial UNIQUE (ams_serial_number);


--
-- Name: connector_submission_entries uq_connector_submission_entry; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_submission_entries
    ADD CONSTRAINT uq_connector_submission_entry UNIQUE (submission_id, entry_id);


--
-- Name: connector_submissions uq_connector_submission_namespace; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_submissions
    ADD CONSTRAINT uq_connector_submission_namespace UNIQUE (server_id, storage_epoch, api_key_identity, operation_id);


--
-- Name: filament_sku_settings uq_filament_sku; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_sku_settings
    ADD CONSTRAINT uq_filament_sku UNIQUE (material, subtype, brand, color_name);


--
-- Name: firmware_cache_entries uq_firmware_cache_model_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.firmware_cache_entries
    ADD CONSTRAINT uq_firmware_cache_model_version UNIQUE (model, version);


--
-- Name: hms_muted_entries uq_hms_muted_printer_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hms_muted_entries
    ADD CONSTRAINT uq_hms_muted_printer_code UNIQUE (printer_id, full_code);


--
-- Name: user_oidc_links uq_oidc_link_provider_sub; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT uq_oidc_link_provider_sub UNIQUE (provider_id, provider_user_id);


--
-- Name: user_oidc_links uq_oidc_link_user_provider; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT uq_oidc_link_user_provider UNIQUE (user_id, provider_id);


--
-- Name: plate_render_objects uq_plate_render_objects_instance; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_render_objects
    ADD CONSTRAINT uq_plate_render_objects_instance UNIQUE (render_id, identify_id);


--
-- Name: plate_renders uq_plate_renders_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_renders
    ADD CONSTRAINT uq_plate_renders_key UNIQUE (file_sha256, plate_index, renderer_version);


--
-- Name: print_options_preferences uq_print_options_pref_user_model; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_options_preferences
    ADD CONSTRAINT uq_print_options_pref_user_model UNIQUE (user_id, printer_model);


--
-- Name: active_print_spoolman uq_printer_archive; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_print_spoolman
    ADD CONSTRAINT uq_printer_archive UNIQUE (printer_id, archive_id);


--
-- Name: product_parts uq_product_parts_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parts
    ADD CONSTRAINT uq_product_parts_key UNIQUE (product_id, name_key);


--
-- Name: product_plates uq_product_plates_file_plate; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_plates
    ADD CONSTRAINT uq_product_plates_file_plate UNIQUE (product_id, library_file_id, plate_index);


--
-- Name: queue_sources uq_queue_sources_sha256; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queue_sources
    ADD CONSTRAINT uq_queue_sources_sha256 UNIQUE (sha256);


--
-- Name: spoolman_slot_assignments uq_spoolman_slot_assignment; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_slot_assignments
    ADD CONSTRAINT uq_spoolman_slot_assignment UNIQUE (printer_id, ams_id, tray_id);


--
-- Name: stock_items uq_stock_items_product_config; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT uq_stock_items_product_config UNIQUE (product_id, config_key);


--
-- Name: user_filament_families uq_user_fila_family; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_filament_families
    ADD CONSTRAINT uq_user_fila_family UNIQUE (ecosystem, filament_id);


--
-- Name: user_filament_presets uq_user_fila_preset_cloud; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_filament_presets
    ADD CONSTRAINT uq_user_fila_preset_cloud UNIQUE (owner_user_id, ecosystem, cloud_id);


--
-- Name: user_filament_presets uq_user_fila_preset_local; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_filament_presets
    ADD CONSTRAINT uq_user_fila_preset_local UNIQUE (local_preset_id);


--
-- Name: user_email_preferences user_email_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_email_preferences
    ADD CONSTRAINT user_email_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_filament_families user_filament_families_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_filament_families
    ADD CONSTRAINT user_filament_families_pkey PRIMARY KEY (id);


--
-- Name: user_filament_presets user_filament_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_filament_presets
    ADD CONSTRAINT user_filament_presets_pkey PRIMARY KEY (id);


--
-- Name: user_groups user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_pkey PRIMARY KEY (user_id, group_id);


--
-- Name: user_notifications user_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notifications
    ADD CONSTRAINT user_notifications_pkey PRIMARY KEY (id);


--
-- Name: user_oidc_links user_oidc_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT user_oidc_links_pkey PRIMARY KEY (id);


--
-- Name: user_otp_codes user_otp_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_otp_codes
    ADD CONSTRAINT user_otp_codes_pkey PRIMARY KEY (id);


--
-- Name: user_totp user_totp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_totp
    ADD CONSTRAINT user_totp_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: virtual_printers virtual_printers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtual_printers
    ADD CONSTRAINT virtual_printers_pkey PRIMARY KEY (id);


--
-- Name: zigbee_devices zigbee_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zigbee_devices
    ADD CONSTRAINT zigbee_devices_pkey PRIMARY KEY (ieee);


--
-- Name: ix_ams_history_printer_ams_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ams_history_printer_ams_time ON public.ams_sensor_history USING btree (printer_id, ams_id, recorded_at);


--
-- Name: ix_ams_sensor_history_recorded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ams_sensor_history_recorded_at ON public.ams_sensor_history USING btree (recorded_at);


--
-- Name: ix_ams_setting_audit_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ams_setting_audit_printer ON public.ams_setting_audit USING btree (printer_id, created_at);


--
-- Name: ix_api_keys_connector_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_api_keys_connector_identity ON public.api_keys USING btree (connector_identity);


--
-- Name: ix_api_keys_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_api_keys_user_id ON public.api_keys USING btree (user_id);


--
-- Name: ix_auth_eph_type_exp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_eph_type_exp ON public.auth_ephemeral_tokens USING btree (token_type, expires_at);


--
-- Name: ix_auth_ephemeral_tokens_family_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_ephemeral_tokens_family_id ON public.auth_ephemeral_tokens USING btree (family_id);


--
-- Name: ix_auth_ephemeral_tokens_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_auth_ephemeral_tokens_token ON public.auth_ephemeral_tokens USING btree (token);


--
-- Name: ix_auth_rate_limit_events_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_rate_limit_events_username ON public.auth_rate_limit_events USING btree (username);


--
-- Name: ix_auth_rl_type_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auth_rl_type_time ON public.auth_rate_limit_events USING btree (event_type, occurred_at);


--
-- Name: ix_auto_queue_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auto_queue_batch_id ON public.auto_queue_items USING btree (batch_id);


--
-- Name: ix_auto_queue_items_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auto_queue_items_batch_id ON public.auto_queue_items USING btree (batch_id);


--
-- Name: ix_auto_queue_items_project_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auto_queue_items_project_line_id ON public.auto_queue_items USING btree (project_line_id);


--
-- Name: ix_auto_queue_items_project_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auto_queue_items_project_status ON public.auto_queue_items USING btree (project_id, status);


--
-- Name: ix_auto_queue_items_queue_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auto_queue_items_queue_source_id ON public.auto_queue_items USING btree (queue_source_id);


--
-- Name: ix_auto_queue_items_recovery_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_auto_queue_items_recovery_identity ON public.auto_queue_items USING btree (recovery_identity);


--
-- Name: ix_auto_queue_items_swap_declaration_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_auto_queue_items_swap_declaration_identity ON public.auto_queue_items USING btree (swap_declaration_identity);


--
-- Name: ix_auto_queue_status_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_auto_queue_status_position ON public.auto_queue_items USING btree (status, "position");


--
-- Name: ix_calibration_audit_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calibration_audit_printer ON public.calibration_audit USING btree (printer_id, created_at);


--
-- Name: ix_calibration_session_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calibration_session_printer ON public.calibration_session USING btree (printer_id, status, created_at);


--
-- Name: ix_cameras_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cameras_location_id ON public.cameras USING btree (location_id);


--
-- Name: ix_cloud_link_audit_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cloud_link_audit_ts ON public.cloud_link_audit USING btree (ts);


--
-- Name: ix_connector_submission_entries_submission_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_connector_submission_entries_submission_id ON public.connector_submission_entries USING btree (submission_id);


--
-- Name: ix_connector_submissions_api_key_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_connector_submissions_api_key_identity ON public.connector_submissions USING btree (api_key_identity);


--
-- Name: ix_customer_contacts_customer_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_customer_contacts_customer_position ON public.customer_contacts USING btree (customer_id, "position");


--
-- Name: ix_drying_schedules_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drying_schedules_printer ON public.drying_schedules USING btree (printer_id);


--
-- Name: ix_filament_cali_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_filament_cali_lookup ON public.filament_calibration USING btree (printer_id, filament_id, nozzle_diameter, nozzle_volume_type, extruder_id);


--
-- Name: ix_firmware_batch_items_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_firmware_batch_items_run_id ON public.firmware_batch_items USING btree (run_id);


--
-- Name: ix_firmware_cache_entries_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_firmware_cache_entries_model ON public.firmware_cache_entries USING btree (model);


--
-- Name: ix_groups_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_groups_name ON public.groups USING btree (name);


--
-- Name: ix_ha_history_location_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ha_history_location_time ON public.ha_sensor_history USING btree (location_sensor_id, observed_at);


--
-- Name: ix_ha_history_printer_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ha_history_printer_time ON public.ha_sensor_history USING btree (printer_sensor_id, observed_at);


--
-- Name: ix_hms_muted_entries_printer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_hms_muted_entries_printer_id ON public.hms_muted_entries USING btree (printer_id);


--
-- Name: ix_label_cassettes_barcode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_cassettes_barcode ON public.label_cassettes USING btree (barcode);


--
-- Name: ix_label_devices_installation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_devices_installation_id ON public.label_devices USING btree (installation_id);


--
-- Name: ix_label_jobs_device_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_jobs_device_id ON public.label_jobs USING btree (device_id);


--
-- Name: ix_label_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_label_jobs_status ON public.label_jobs USING btree (status);


--
-- Name: ix_library_file_makerworld_meta_library_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_library_file_makerworld_meta_library_file_id ON public.library_file_makerworld_meta USING btree (library_file_id);


--
-- Name: ix_library_file_makerworld_meta_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_file_makerworld_meta_profile_id ON public.library_file_makerworld_meta USING btree (profile_id);


--
-- Name: ix_library_file_notes_file; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_file_notes_file ON public.library_file_notes USING btree (library_file_id);


--
-- Name: ix_library_file_tags_tag_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_file_tags_tag_id ON public.library_file_tags USING btree (tag_id);


--
-- Name: ix_library_files_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_files_deleted_at ON public.library_files USING btree (deleted_at);


--
-- Name: ix_library_files_file_hash_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_files_file_hash_active ON public.library_files USING btree (file_hash) WHERE (deleted_at IS NULL);


--
-- Name: ix_library_files_source_url; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_files_source_url ON public.library_files USING btree (source_url);


--
-- Name: ix_library_folders_archive_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_library_folders_archive_id_unique ON public.library_folders USING btree (archive_id);


--
-- Name: ix_library_scan_jobs_folder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_scan_jobs_folder_id ON public.library_scan_jobs USING btree (folder_id);


--
-- Name: ix_library_scan_jobs_folder_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_scan_jobs_folder_status ON public.library_scan_jobs USING btree (folder_id, status);


--
-- Name: ix_library_scan_jobs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_scan_jobs_status ON public.library_scan_jobs USING btree (status);


--
-- Name: ix_library_tags_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_library_tags_code ON public.library_tags USING btree (code);


--
-- Name: ix_library_tags_name_key_is_system; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_library_tags_name_key_is_system ON public.library_tags USING btree (name_key, is_system);


--
-- Name: ix_location_ha_sensors_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_location_ha_sensors_location_id ON public.location_ha_sensors USING btree (location_id);


--
-- Name: ix_locations_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_locations_name_key ON public.locations USING btree (name_key);


--
-- Name: ix_long_lived_tokens_lookup_prefix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_long_lived_tokens_lookup_prefix ON public.long_lived_tokens USING btree (lookup_prefix);


--
-- Name: ix_long_lived_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_long_lived_tokens_user_id ON public.long_lived_tokens USING btree (user_id);


--
-- Name: ix_maintenance_types_type_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_maintenance_types_type_code ON public.maintenance_types USING btree (type_code);


--
-- Name: ix_meter_incidents_plug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_meter_incidents_plug ON public.smart_plug_meter_incidents USING btree (plug_id, opened_at);


--
-- Name: ix_notification_digest_queue_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_digest_queue_created_at ON public.notification_digest_queue USING btree (created_at);


--
-- Name: ix_notification_digest_queue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_digest_queue_id ON public.notification_digest_queue USING btree (id);


--
-- Name: ix_notification_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_logs_created_at ON public.notification_logs USING btree (created_at);


--
-- Name: ix_notification_logs_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_logs_id ON public.notification_logs USING btree (id);


--
-- Name: ix_notification_providers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_providers_id ON public.notification_providers USING btree (id);


--
-- Name: ix_notification_templates_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_templates_id ON public.notification_templates USING btree (id);


--
-- Name: ix_obico_events_printer_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_obico_events_printer_time ON public.obico_events USING btree (printer_id, observed_at, id);


--
-- Name: ix_obico_events_retention; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_obico_events_retention ON public.obico_events USING btree (verdict, observed_at, id);


--
-- Name: ix_obico_events_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_obico_events_time ON public.obico_events USING btree (observed_at, id);


--
-- Name: ix_oidc_providers_default_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_oidc_providers_default_group_id ON public.oidc_providers USING btree (default_group_id);


--
-- Name: ix_orca_base_profiles_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_orca_base_profiles_name ON public.orca_base_profiles USING btree (name);


--
-- Name: ix_order_plan_receipts_operation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_order_plan_receipts_operation_id ON public.order_plan_receipts USING btree (operation_id);


--
-- Name: ix_order_plan_submissions_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_order_plan_submissions_plan_id ON public.order_plan_submissions USING btree (plan_id);


--
-- Name: ix_plate_render_objects_render_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plate_render_objects_render_id ON public.plate_render_objects USING btree (render_id);


--
-- Name: ix_plate_renders_file_sha256; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plate_renders_file_sha256 ON public.plate_renders USING btree (file_sha256);


--
-- Name: ix_plate_renders_queue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plate_renders_queue ON public.plate_renders USING btree (status, renderer_version, next_attempt_at);


--
-- Name: ix_plug_energy_snapshots_plug_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plug_energy_snapshots_plug_time ON public.smart_plug_energy_snapshots USING btree (plug_id, recorded_at);


--
-- Name: ix_plug_power_history_plug_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plug_power_history_plug_time ON public.smart_plug_power_history USING btree (plug_id, recorded_at);


--
-- Name: ix_print_archive_parts_archive_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archive_parts_archive_id ON public.print_archive_parts USING btree (archive_id);


--
-- Name: ix_print_archive_parts_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archive_parts_name_key ON public.print_archive_parts USING btree (name_key);


--
-- Name: ix_print_archives_active_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_active_created ON public.print_archives USING btree (deleted_at, created_at);


--
-- Name: ix_print_archives_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_batch_id ON public.print_archives USING btree (batch_id);


--
-- Name: ix_print_archives_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_deleted_at ON public.print_archives USING btree (deleted_at);


--
-- Name: ix_print_archives_effective_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_effective_hash ON public.print_archives USING btree (COALESCE(source_content_hash, content_hash));


--
-- Name: ix_print_archives_library_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_library_file_id ON public.print_archives USING btree (library_file_id);


--
-- Name: ix_print_archives_plate_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_plate_index ON public.print_archives USING btree (plate_index);


--
-- Name: ix_print_archives_printer_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_printer_created ON public.print_archives USING btree (printer_id, created_at);


--
-- Name: ix_print_archives_project_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_project_created ON public.print_archives USING btree (project_id, created_at);


--
-- Name: ix_print_archives_project_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_project_line_id ON public.print_archives USING btree (project_line_id);


--
-- Name: ix_print_archives_queue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_queue_id ON public.print_archives USING btree (queue_id);


--
-- Name: ix_print_archives_queue_item_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_queue_item_identity ON public.print_archives USING btree (queue_item_identity);


--
-- Name: ix_print_archives_recovery_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_print_archives_recovery_identity ON public.print_archives USING btree (recovery_identity);


--
-- Name: ix_print_archives_source_auto_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_source_auto_identity ON public.print_archives USING btree (source_auto_identity);


--
-- Name: ix_print_archives_subtask_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_archives_subtask_id ON public.print_archives USING btree (subtask_id);


--
-- Name: ix_print_completion_receipts_archive_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_completion_receipts_archive_id ON public.print_completion_receipts USING btree (archive_id);


--
-- Name: ix_print_options_preferences_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_options_preferences_user_id ON public.print_options_preferences USING btree (user_id);


--
-- Name: ix_print_queue_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_queue_batch_id ON public.print_queue USING btree (batch_id);


--
-- Name: ix_print_queue_project_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_queue_project_line_id ON public.print_queue USING btree (project_line_id);


--
-- Name: ix_print_queue_project_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_queue_project_status ON public.print_queue USING btree (project_id, status);


--
-- Name: ix_print_queue_queue_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_queue_queue_source_id ON public.print_queue USING btree (queue_source_id);


--
-- Name: ix_print_queue_recovery_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_print_queue_recovery_identity ON public.print_queue USING btree (recovery_identity);


--
-- Name: ix_print_queue_source_auto_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_queue_source_auto_identity ON public.print_queue USING btree (source_auto_identity);


--
-- Name: ix_print_queue_swap_declaration_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_print_queue_swap_declaration_identity ON public.print_queue USING btree (swap_declaration_identity);


--
-- Name: ix_print_state_recovery_printer_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_state_recovery_printer_created ON public.print_state_recovery_actions USING btree (printer_id, created_at);


--
-- Name: ix_print_usage_events_archive_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_usage_events_archive_id ON public.print_usage_events USING btree (archive_id);


--
-- Name: ix_print_usage_events_printer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_print_usage_events_printer_id ON public.print_usage_events USING btree (printer_id);


--
-- Name: ix_printer_ha_sensors_printer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_printer_ha_sensors_printer_id ON public.printer_ha_sensors USING btree (printer_id);


--
-- Name: ix_printer_locations_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_printer_locations_name_key ON public.printer_locations USING btree (name_key);


--
-- Name: ix_printer_locations_parent_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_printer_locations_parent_name ON public.printer_locations USING btree (parent_id, name_key);


--
-- Name: ix_printer_queues_recovery_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_printer_queues_recovery_identity ON public.printer_queues USING btree (recovery_identity);


--
-- Name: ix_printer_sensor_history_printer_kind_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_printer_sensor_history_printer_kind_time ON public.printer_sensor_history USING btree (printer_id, sensor_kind, recorded_at);


--
-- Name: ix_printer_sensor_history_recorded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_printer_sensor_history_recorded_at ON public.printer_sensor_history USING btree (recorded_at);


--
-- Name: ix_printer_setting_audit_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_printer_setting_audit_printer ON public.printer_setting_audit USING btree (printer_id, created_at);


--
-- Name: ix_printer_tag_links_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_printer_tag_links_tag ON public.printer_tag_links USING btree (tag_id);


--
-- Name: ix_printer_tags_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_printer_tags_name_key ON public.printer_tags USING btree (name_key);


--
-- Name: ix_printers_awaiting_plate_clear_archive_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_printers_awaiting_plate_clear_archive_id ON public.printers USING btree (awaiting_plate_clear_archive_id);


--
-- Name: ix_printers_connector_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_printers_connector_identity ON public.printers USING btree (connector_identity);


--
-- Name: ix_product_facets_kind_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_facets_kind_value ON public.product_facets USING btree (kind, value);


--
-- Name: ix_product_part_stock_movements_archive_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_part_stock_movements_archive_id ON public.product_part_stock_movements USING btree (archive_id);


--
-- Name: ix_product_part_stock_movements_part_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_part_stock_movements_part_created ON public.product_part_stock_movements USING btree (product_part_id, created_at);


--
-- Name: ix_product_part_stock_movements_project_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_part_stock_movements_project_line_id ON public.product_part_stock_movements USING btree (project_line_id);


--
-- Name: ix_product_part_stock_movements_stock_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_part_stock_movements_stock_issue_id ON public.product_part_stock_movements USING btree (stock_issue_id);


--
-- Name: ix_product_part_stock_movements_stock_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_part_stock_movements_stock_item_id ON public.product_part_stock_movements USING btree (stock_item_id);


--
-- Name: ix_product_parts_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_parts_product_id ON public.product_parts USING btree (product_id);


--
-- Name: ix_product_parts_variant_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_parts_variant_option_id ON public.product_parts USING btree (variant_option_id);


--
-- Name: ix_product_plates_library_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_plates_library_file_id ON public.product_plates USING btree (library_file_id);


--
-- Name: ix_product_plates_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_plates_product_id ON public.product_plates USING btree (product_id);


--
-- Name: ix_product_variant_groups_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_variant_groups_product_id ON public.product_variant_groups USING btree (product_id);


--
-- Name: ix_product_variant_options_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_variant_options_group_id ON public.product_variant_options USING btree (group_id);


--
-- Name: ix_products_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_category_id ON public.products USING btree (category_id);


--
-- Name: ix_products_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_products_sku_key ON public.products USING btree (sku_key);


--
-- Name: ix_project_events_project_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_events_project_created ON public.project_events USING btree (project_id, created_at);


--
-- Name: ix_project_line_choices_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_line_choices_option_id ON public.project_line_choices USING btree (option_id);


--
-- Name: ix_project_line_part_counts_part_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_line_part_counts_part_id ON public.project_line_part_counts USING btree (part_id);


--
-- Name: ix_project_lines_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_lines_product_id ON public.project_lines USING btree (product_id);


--
-- Name: ix_project_lines_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_lines_project_id ON public.project_lines USING btree (project_id);


--
-- Name: ix_projects_contact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_projects_contact_id ON public.projects USING btree (contact_id);


--
-- Name: ix_projects_responsible_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_projects_responsible_id ON public.projects USING btree (responsible_id);


--
-- Name: ix_queue_sources_state_unreferenced_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_queue_sources_state_unreferenced_at ON public.queue_sources USING btree (state, unreferenced_at);


--
-- Name: ix_scheduled_dryings_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scheduled_dryings_printer ON public.scheduled_dryings USING btree (printer_id);


--
-- Name: ix_scheduled_dryings_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_scheduled_dryings_status ON public.scheduled_dryings USING btree (status);


--
-- Name: ix_sensor_history_sensor_kind_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sensor_history_sensor_kind_time ON public.smart_sensor_history USING btree (sensor_id, sensor_kind, recorded_at);


--
-- Name: ix_settings_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_settings_key ON public.settings USING btree (key);


--
-- Name: ix_slicer_pipelines_is_deleted; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_slicer_pipelines_is_deleted ON public.slicer_pipelines USING btree (is_deleted);


--
-- Name: ix_smart_sensor_bindings_sensor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_smart_sensor_bindings_sensor_id ON public.smart_sensor_bindings USING btree (sensor_id);


--
-- Name: ix_smart_sensor_thresholds_sensor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_smart_sensor_thresholds_sensor_id ON public.smart_sensor_thresholds USING btree (sensor_id);


--
-- Name: ix_smart_sensor_thresholds_sensor_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_smart_sensor_thresholds_sensor_kind ON public.smart_sensor_thresholds USING btree (sensor_id, kind);


--
-- Name: ix_smart_sensors_printer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_smart_sensors_printer_id ON public.smart_sensors USING btree (printer_id);


--
-- Name: ix_smart_sensors_zigbee_ieee; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_smart_sensors_zigbee_ieee ON public.smart_sensors USING btree (zigbee_ieee);


--
-- Name: ix_spool_k_profile_spool_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_spool_k_profile_spool_id ON public.spool_k_profile USING btree (spool_id);


--
-- Name: ix_spool_location_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_spool_location_id ON public.spool USING btree (location_id);


--
-- Name: ix_spool_usage_history_spool_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_spool_usage_history_spool_created ON public.spool_usage_history USING btree (spool_id, created_at);


--
-- Name: ix_stock_issue_lines_issue_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_issue_lines_issue_position ON public.stock_issue_lines USING btree (issue_id, "position");


--
-- Name: ix_stock_issue_lines_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_issue_lines_product_id ON public.stock_issue_lines USING btree (product_id);


--
-- Name: ix_stock_issues_customer_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_issues_customer_created ON public.stock_issues USING btree (customer_id, created_at);


--
-- Name: ix_stock_issues_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_issues_project_id ON public.stock_issues USING btree (project_id);


--
-- Name: ix_stock_item_choices_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_item_choices_option_id ON public.stock_item_choices USING btree (option_id);


--
-- Name: ix_stock_item_movements_created_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_item_movements_created_id ON public.stock_item_movements USING btree (created_at, id);


--
-- Name: ix_stock_item_movements_item_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_item_movements_item_created ON public.stock_item_movements USING btree (item_id, created_at);


--
-- Name: ix_stock_item_movements_stock_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_item_movements_stock_issue_id ON public.stock_item_movements USING btree (stock_issue_id);


--
-- Name: ix_stock_item_part_counts_part_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_item_part_counts_part_id ON public.stock_item_part_counts USING btree (part_id);


--
-- Name: ix_stock_items_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_stock_items_product_id ON public.stock_items USING btree (product_id);


--
-- Name: ix_swap_source_declaration_audit_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_swap_source_declaration_audit_source ON public.swap_source_declaration_audit USING btree (source_kind, source_id);


--
-- Name: ix_telegram_chats_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_telegram_chats_chat_id ON public.telegram_chats USING btree (chat_id);


--
-- Name: ix_telegram_chats_provider_chat; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_telegram_chats_provider_chat ON public.telegram_chats USING btree (provider_id, chat_id);


--
-- Name: ix_telegram_chats_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_telegram_chats_provider_id ON public.telegram_chats USING btree (provider_id);


--
-- Name: ix_user_email_preferences_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_email_preferences_id ON public.user_email_preferences USING btree (id);


--
-- Name: ix_user_email_preferences_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_user_email_preferences_user_id ON public.user_email_preferences USING btree (user_id);


--
-- Name: ix_user_notifications_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_notifications_user_created ON public.user_notifications USING btree (user_id, created_at);


--
-- Name: ix_user_notifications_user_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_notifications_user_read ON public.user_notifications USING btree (user_id, read_at);


--
-- Name: ix_user_oidc_links_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_oidc_links_provider_id ON public.user_oidc_links USING btree (provider_id);


--
-- Name: ix_user_oidc_links_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_oidc_links_user_id ON public.user_oidc_links USING btree (user_id);


--
-- Name: ix_user_otp_codes_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_otp_codes_user_id ON public.user_otp_codes USING btree (user_id);


--
-- Name: ix_user_totp_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_user_totp_user_id ON public.user_totp USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: uq_location_ha_sensors_location_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_location_ha_sensors_location_entity ON public.location_ha_sensors USING btree (location_id, entity_id);


--
-- Name: uq_meter_incidents_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_meter_incidents_active ON public.smart_plug_meter_incidents USING btree (plug_id) WHERE ((status)::text = 'active'::text);


--
-- Name: uq_print_options_pref_system_model; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_print_options_pref_system_model ON public.print_options_preferences USING btree (printer_model) WHERE (user_id IS NULL);


--
-- Name: uq_printer_ha_sensor_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_printer_ha_sensor_entity ON public.printer_ha_sensors USING btree (printer_id, entity_id);


--
-- Name: ux_filament_cali_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_filament_cali_active ON public.filament_calibration USING btree (printer_id, filament_id, nozzle_diameter, nozzle_volume_type, extruder_id) WHERE (is_active = true);


--
-- Name: ux_products_origin_plate; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_products_origin_plate ON public.products USING btree (origin_file_id, origin_plate_index) WHERE ((origin)::text = 'adhoc_plate'::text);


--
-- Name: ux_smart_sensor_binding_printer; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_smart_sensor_binding_printer ON public.smart_sensor_bindings USING btree (sensor_id, printer_id) WHERE (printer_id IS NOT NULL);


--
-- Name: ux_smart_sensor_binding_room; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_smart_sensor_binding_room ON public.smart_sensor_bindings USING btree (sensor_id, printer_location_id) WHERE (printer_location_id IS NOT NULL);


--
-- Name: ux_smart_sensor_binding_storage; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_smart_sensor_binding_storage ON public.smart_sensor_bindings USING btree (sensor_id, storage_location_id) WHERE (storage_location_id IS NOT NULL);


--
-- Name: ux_smart_sensor_binding_threshold_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_smart_sensor_binding_threshold_kind ON public.smart_sensor_binding_thresholds USING btree (binding_id, kind);


--
-- Name: active_print_spoolman active_print_spoolman_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_print_spoolman
    ADD CONSTRAINT active_print_spoolman_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE CASCADE;


--
-- Name: active_print_spoolman active_print_spoolman_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.active_print_spoolman
    ADD CONSTRAINT active_print_spoolman_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: ams_sensor_history ams_sensor_history_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_sensor_history
    ADD CONSTRAINT ams_sensor_history_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: ams_setting_audit ams_setting_audit_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_setting_audit
    ADD CONSTRAINT ams_setting_audit_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: ams_setting_audit ams_setting_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ams_setting_audit
    ADD CONSTRAINT ams_setting_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auto_queue_items auto_queue_items_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE SET NULL;


--
-- Name: auto_queue_items auto_queue_items_assigned_to_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_assigned_to_item_id_fkey FOREIGN KEY (assigned_to_item_id) REFERENCES public.print_queue(id) ON DELETE SET NULL;


--
-- Name: auto_queue_items auto_queue_items_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: auto_queue_items auto_queue_items_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE SET NULL;


--
-- Name: auto_queue_items auto_queue_items_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: auto_queue_items auto_queue_items_project_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_project_line_id_fkey FOREIGN KEY (project_line_id) REFERENCES public.project_lines(id) ON DELETE SET NULL;


--
-- Name: auto_queue_items auto_queue_items_queue_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_queue_source_id_fkey FOREIGN KEY (queue_source_id) REFERENCES public.queue_sources(id) ON DELETE RESTRICT;


--
-- Name: auto_queue_items auto_queue_items_target_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auto_queue_items
    ADD CONSTRAINT auto_queue_items_target_location_id_fkey FOREIGN KEY (target_location_id) REFERENCES public.printer_locations(id);


--
-- Name: calibration_audit calibration_audit_filament_calibration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit
    ADD CONSTRAINT calibration_audit_filament_calibration_id_fkey FOREIGN KEY (filament_calibration_id) REFERENCES public.filament_calibration(id) ON DELETE SET NULL;


--
-- Name: calibration_audit calibration_audit_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit
    ADD CONSTRAINT calibration_audit_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: calibration_audit calibration_audit_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit
    ADD CONSTRAINT calibration_audit_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.calibration_session(id) ON DELETE SET NULL;


--
-- Name: calibration_audit calibration_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_audit
    ADD CONSTRAINT calibration_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: calibration_session calibration_session_parent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session
    ADD CONSTRAINT calibration_session_parent_session_id_fkey FOREIGN KEY (parent_session_id) REFERENCES public.calibration_session(id) ON DELETE SET NULL;


--
-- Name: calibration_session calibration_session_print_queue_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session
    ADD CONSTRAINT calibration_session_print_queue_item_id_fkey FOREIGN KEY (print_queue_item_id) REFERENCES public.print_queue(id) ON DELETE SET NULL;


--
-- Name: calibration_session calibration_session_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session
    ADD CONSTRAINT calibration_session_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: calibration_session calibration_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calibration_session
    ADD CONSTRAINT calibration_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: cameras cameras_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cameras
    ADD CONSTRAINT cameras_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.printer_locations(id) ON DELETE RESTRICT;


--
-- Name: cloud_link_printers cloud_link_printers_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cloud_link_printers
    ADD CONSTRAINT cloud_link_printers_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: connector_submission_entries connector_submission_entries_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_submission_entries
    ADD CONSTRAINT connector_submission_entries_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.connector_submissions(id) ON DELETE CASCADE;


--
-- Name: customer_contacts customer_contacts_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_contacts
    ADD CONSTRAINT customer_contacts_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customer_contacts customer_contacts_delivery_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_contacts
    ADD CONSTRAINT customer_contacts_delivery_method_id_fkey FOREIGN KEY (delivery_method_id) REFERENCES public.delivery_methods(id) ON DELETE SET NULL;


--
-- Name: drying_schedules drying_schedules_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drying_schedules
    ADD CONSTRAINT drying_schedules_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: drying_schedules drying_schedules_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drying_schedules
    ADD CONSTRAINT drying_schedules_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: filament_calibration filament_calibration_calibrated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_calibration
    ADD CONSTRAINT filament_calibration_calibrated_by_user_id_fkey FOREIGN KEY (calibrated_by_user_id) REFERENCES public.users(id);


--
-- Name: filament_calibration filament_calibration_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filament_calibration
    ADD CONSTRAINT filament_calibration_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id);


--
-- Name: firmware_batch_items firmware_batch_items_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.firmware_batch_items
    ADD CONSTRAINT firmware_batch_items_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id);


--
-- Name: firmware_batch_items firmware_batch_items_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.firmware_batch_items
    ADD CONSTRAINT firmware_batch_items_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.firmware_batch_runs(id);


--
-- Name: firmware_batch_runs firmware_batch_runs_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.firmware_batch_runs
    ADD CONSTRAINT firmware_batch_runs_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: git_backup_logs git_backup_logs_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.git_backup_logs
    ADD CONSTRAINT git_backup_logs_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.git_backup_config(id) ON DELETE CASCADE;


--
-- Name: ha_sensor_history ha_sensor_history_location_sensor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ha_sensor_history
    ADD CONSTRAINT ha_sensor_history_location_sensor_id_fkey FOREIGN KEY (location_sensor_id) REFERENCES public.location_ha_sensors(id) ON DELETE CASCADE;


--
-- Name: ha_sensor_history ha_sensor_history_printer_sensor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ha_sensor_history
    ADD CONSTRAINT ha_sensor_history_printer_sensor_id_fkey FOREIGN KEY (printer_sensor_id) REFERENCES public.printer_ha_sensors(id) ON DELETE CASCADE;


--
-- Name: hms_muted_entries hms_muted_entries_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hms_muted_entries
    ADD CONSTRAINT hms_muted_entries_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: kprofile_notes kprofile_notes_filament_calibration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kprofile_notes
    ADD CONSTRAINT kprofile_notes_filament_calibration_id_fkey FOREIGN KEY (filament_calibration_id) REFERENCES public.filament_calibration(id) ON DELETE CASCADE;


--
-- Name: label_jobs label_jobs_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.label_jobs
    ADD CONSTRAINT label_jobs_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.label_devices(id) ON DELETE CASCADE;


--
-- Name: library_file_makerworld_meta library_file_makerworld_meta_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_makerworld_meta
    ADD CONSTRAINT library_file_makerworld_meta_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE CASCADE;


--
-- Name: library_file_notes library_file_notes_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_notes
    ADD CONSTRAINT library_file_notes_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE CASCADE;


--
-- Name: library_file_notes library_file_notes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_notes
    ADD CONSTRAINT library_file_notes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: library_file_tags library_file_tags_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_tags
    ADD CONSTRAINT library_file_tags_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.library_files(id) ON DELETE CASCADE;


--
-- Name: library_file_tags library_file_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_file_tags
    ADD CONSTRAINT library_file_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.library_tags(id) ON DELETE CASCADE;


--
-- Name: library_files library_files_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_files
    ADD CONSTRAINT library_files_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: library_files library_files_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_files
    ADD CONSTRAINT library_files_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.library_folders(id) ON DELETE CASCADE;


--
-- Name: library_folders library_folders_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folders
    ADD CONSTRAINT library_folders_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE SET NULL;


--
-- Name: library_folders library_folders_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_folders
    ADD CONSTRAINT library_folders_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.library_folders(id) ON DELETE CASCADE;


--
-- Name: library_scan_jobs library_scan_jobs_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_scan_jobs
    ADD CONSTRAINT library_scan_jobs_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.library_folders(id) ON DELETE CASCADE;


--
-- Name: location_ha_sensors location_ha_sensors_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_ha_sensors
    ADD CONSTRAINT location_ha_sensors_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: location_sensor_primary location_sensor_primary_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_sensor_primary
    ADD CONSTRAINT location_sensor_primary_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: long_lived_tokens long_lived_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.long_lived_tokens
    ADD CONSTRAINT long_lived_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: maintenance_history maintenance_history_performed_by_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_performed_by_chat_id_fkey FOREIGN KEY (performed_by_chat_id) REFERENCES public.telegram_chats(id) ON DELETE SET NULL;


--
-- Name: maintenance_history maintenance_history_performed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_performed_by_user_id_fkey FOREIGN KEY (performed_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: maintenance_history maintenance_history_printer_maintenance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_history
    ADD CONSTRAINT maintenance_history_printer_maintenance_id_fkey FOREIGN KEY (printer_maintenance_id) REFERENCES public.printer_maintenance(id) ON DELETE CASCADE;


--
-- Name: notification_digest_queue notification_digest_queue_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_digest_queue
    ADD CONSTRAINT notification_digest_queue_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- Name: notification_digest_queue notification_digest_queue_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_digest_queue
    ADD CONSTRAINT notification_digest_queue_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.notification_providers(id) ON DELETE CASCADE;


--
-- Name: notification_logs notification_logs_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- Name: notification_logs notification_logs_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.notification_providers(id) ON DELETE CASCADE;


--
-- Name: obico_events obico_events_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obico_events
    ADD CONSTRAINT obico_events_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: oidc_providers oidc_providers_default_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_default_group_id_fkey FOREIGN KEY (default_group_id) REFERENCES public.groups(id) ON DELETE SET NULL;


--
-- Name: order_plan_receipts order_plan_receipts_operation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_plan_receipts
    ADD CONSTRAINT order_plan_receipts_operation_id_fkey FOREIGN KEY (operation_id) REFERENCES public.order_plan_submissions(id) ON DELETE CASCADE;


--
-- Name: order_plan_submissions order_plan_submissions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_plan_submissions
    ADD CONSTRAINT order_plan_submissions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.order_working_plans(id) ON DELETE CASCADE;


--
-- Name: order_working_plans order_working_plans_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_working_plans
    ADD CONSTRAINT order_working_plans_id_fkey FOREIGN KEY (id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: plate_render_objects plate_render_objects_render_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plate_render_objects
    ADD CONSTRAINT plate_render_objects_render_id_fkey FOREIGN KEY (render_id) REFERENCES public.plate_renders(id) ON DELETE CASCADE;


--
-- Name: print_archive_parts print_archive_parts_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archive_parts
    ADD CONSTRAINT print_archive_parts_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE CASCADE;


--
-- Name: print_archives print_archives_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: print_archives print_archives_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE SET NULL;


--
-- Name: print_archives print_archives_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id);


--
-- Name: print_archives print_archives_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: print_archives print_archives_project_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_project_line_id_fkey FOREIGN KEY (project_line_id) REFERENCES public.project_lines(id) ON DELETE SET NULL;


--
-- Name: print_archives print_archives_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_archives
    ADD CONSTRAINT print_archives_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.printer_queues(id) ON DELETE SET NULL;


--
-- Name: print_completion_receipts print_completion_receipts_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_completion_receipts
    ADD CONSTRAINT print_completion_receipts_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE CASCADE;


--
-- Name: print_completion_receipts print_completion_receipts_assessment_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_completion_receipts
    ADD CONSTRAINT print_completion_receipts_assessment_actor_id_fkey FOREIGN KEY (assessment_actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: print_completion_receipts print_completion_receipts_plate_action_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_completion_receipts
    ADD CONSTRAINT print_completion_receipts_plate_action_actor_id_fkey FOREIGN KEY (plate_action_actor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: print_options_preferences print_options_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_options_preferences
    ADD CONSTRAINT print_options_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: print_queue print_queue_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE SET NULL;


--
-- Name: print_queue print_queue_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: print_queue print_queue_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id);


--
-- Name: print_queue print_queue_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: print_queue print_queue_project_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_project_line_id_fkey FOREIGN KEY (project_line_id) REFERENCES public.project_lines(id) ON DELETE SET NULL;


--
-- Name: print_queue print_queue_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.printer_queues(id);


--
-- Name: print_queue print_queue_queue_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_queue_source_id_fkey FOREIGN KEY (queue_source_id) REFERENCES public.queue_sources(id) ON DELETE RESTRICT;


--
-- Name: print_queue print_queue_source_auto_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_queue
    ADD CONSTRAINT print_queue_source_auto_item_id_fkey FOREIGN KEY (source_auto_item_id) REFERENCES public.auto_queue_items(id);


--
-- Name: print_usage_events print_usage_events_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_usage_events
    ADD CONSTRAINT print_usage_events_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE CASCADE;


--
-- Name: print_usage_events print_usage_events_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.print_usage_events
    ADD CONSTRAINT print_usage_events_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: printer_ha_sensors printer_ha_sensors_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_ha_sensors
    ADD CONSTRAINT printer_ha_sensors_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: printer_locations printer_locations_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_locations
    ADD CONSTRAINT printer_locations_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.printer_locations(id);


--
-- Name: printer_maintenance printer_maintenance_maintenance_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_maintenance
    ADD CONSTRAINT printer_maintenance_maintenance_type_id_fkey FOREIGN KEY (maintenance_type_id) REFERENCES public.maintenance_types(id) ON DELETE CASCADE;


--
-- Name: printer_maintenance printer_maintenance_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_maintenance
    ADD CONSTRAINT printer_maintenance_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: printer_queues printer_queues_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_queues
    ADD CONSTRAINT printer_queues_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id);


--
-- Name: printer_sensor_history printer_sensor_history_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_sensor_history
    ADD CONSTRAINT printer_sensor_history_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: printer_setting_audit printer_setting_audit_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_setting_audit
    ADD CONSTRAINT printer_setting_audit_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: printer_setting_audit printer_setting_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_setting_audit
    ADD CONSTRAINT printer_setting_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: printer_tag_links printer_tag_links_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_tag_links
    ADD CONSTRAINT printer_tag_links_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: printer_tag_links printer_tag_links_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printer_tag_links
    ADD CONSTRAINT printer_tag_links_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.printer_tags(id) ON DELETE CASCADE;


--
-- Name: printers printers_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.printers
    ADD CONSTRAINT printers_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.printer_locations(id);


--
-- Name: product_facets product_facets_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_facets
    ADD CONSTRAINT product_facets_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE CASCADE;


--
-- Name: product_facets product_facets_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_facets
    ADD CONSTRAINT product_facets_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_files product_files_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_files
    ADD CONSTRAINT product_files_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE CASCADE;


--
-- Name: product_files product_files_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_files
    ADD CONSTRAINT product_files_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_folders product_folders_library_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_folders
    ADD CONSTRAINT product_folders_library_folder_id_fkey FOREIGN KEY (library_folder_id) REFERENCES public.library_folders(id) ON DELETE CASCADE;


--
-- Name: product_folders product_folders_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_folders
    ADD CONSTRAINT product_folders_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_part_stock_movements product_part_stock_movements_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_part_stock_movements
    ADD CONSTRAINT product_part_stock_movements_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id) ON DELETE SET NULL;


--
-- Name: product_part_stock_movements product_part_stock_movements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_part_stock_movements
    ADD CONSTRAINT product_part_stock_movements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: product_part_stock_movements product_part_stock_movements_product_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_part_stock_movements
    ADD CONSTRAINT product_part_stock_movements_product_part_id_fkey FOREIGN KEY (product_part_id) REFERENCES public.product_parts(id) ON DELETE CASCADE;


--
-- Name: product_part_stock_movements product_part_stock_movements_project_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_part_stock_movements
    ADD CONSTRAINT product_part_stock_movements_project_line_id_fkey FOREIGN KEY (project_line_id) REFERENCES public.project_lines(id) ON DELETE SET NULL;


--
-- Name: product_part_stock_movements product_part_stock_movements_stock_issue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_part_stock_movements
    ADD CONSTRAINT product_part_stock_movements_stock_issue_id_fkey FOREIGN KEY (stock_issue_id) REFERENCES public.stock_issues(id) ON DELETE SET NULL;


--
-- Name: product_part_stock_movements product_part_stock_movements_stock_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_part_stock_movements
    ADD CONSTRAINT product_part_stock_movements_stock_item_id_fkey FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id) ON DELETE SET NULL;


--
-- Name: product_parts product_parts_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parts
    ADD CONSTRAINT product_parts_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_parts product_parts_variant_option_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_parts
    ADD CONSTRAINT product_parts_variant_option_id_fkey FOREIGN KEY (variant_option_id) REFERENCES public.product_variant_options(id) ON DELETE SET NULL;


--
-- Name: product_plates product_plates_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_plates
    ADD CONSTRAINT product_plates_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.library_files(id) ON DELETE CASCADE;


--
-- Name: product_plates product_plates_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_plates
    ADD CONSTRAINT product_plates_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_variant_groups product_variant_groups_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_groups
    ADD CONSTRAINT product_variant_groups_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_variant_options product_variant_options_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_variant_options
    ADD CONSTRAINT product_variant_options_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.product_variant_groups(id) ON DELETE CASCADE;


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- Name: project_events project_events_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_events
    ADD CONSTRAINT project_events_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_events project_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_events
    ADD CONSTRAINT project_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: project_line_choices project_line_choices_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_line_choices
    ADD CONSTRAINT project_line_choices_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.product_variant_groups(id) ON DELETE CASCADE;


--
-- Name: project_line_choices project_line_choices_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_line_choices
    ADD CONSTRAINT project_line_choices_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.project_lines(id) ON DELETE CASCADE;


--
-- Name: project_line_choices project_line_choices_option_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_line_choices
    ADD CONSTRAINT project_line_choices_option_id_fkey FOREIGN KEY (option_id) REFERENCES public.product_variant_options(id);


--
-- Name: project_line_part_counts project_line_part_counts_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_line_part_counts
    ADD CONSTRAINT project_line_part_counts_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.project_lines(id) ON DELETE CASCADE;


--
-- Name: project_line_part_counts project_line_part_counts_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_line_part_counts
    ADD CONSTRAINT project_line_part_counts_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.product_parts(id) ON DELETE CASCADE;


--
-- Name: project_line_part_stock project_line_part_stock_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_line_part_stock
    ADD CONSTRAINT project_line_part_stock_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.project_lines(id) ON DELETE CASCADE;


--
-- Name: project_line_part_stock project_line_part_stock_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_line_part_stock
    ADD CONSTRAINT project_line_part_stock_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.product_parts(id) ON DELETE CASCADE;


--
-- Name: project_lines project_lines_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lines
    ADD CONSTRAINT project_lines_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: project_lines project_lines_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_lines
    ADD CONSTRAINT project_lines_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_procurement project_procurement_product_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_procurement
    ADD CONSTRAINT project_procurement_product_part_id_fkey FOREIGN KEY (product_part_id) REFERENCES public.product_parts(id) ON DELETE CASCADE;


--
-- Name: project_procurement project_procurement_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_procurement
    ADD CONSTRAINT project_procurement_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: projects projects_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.customer_contacts(id) ON DELETE SET NULL;


--
-- Name: projects projects_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: projects projects_responsible_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_responsible_id_fkey FOREIGN KEY (responsible_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: scheduled_dryings scheduled_dryings_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_dryings
    ADD CONSTRAINT scheduled_dryings_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: scheduled_dryings scheduled_dryings_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_dryings
    ADD CONSTRAINT scheduled_dryings_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: scheduled_dryings scheduled_dryings_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_dryings
    ADD CONSTRAINT scheduled_dryings_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.drying_schedules(id) ON DELETE SET NULL;


--
-- Name: slicer_pipelines slicer_pipelines_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slicer_pipelines
    ADD CONSTRAINT slicer_pipelines_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: smart_plug_energy_snapshots smart_plug_energy_snapshots_plug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_energy_snapshots
    ADD CONSTRAINT smart_plug_energy_snapshots_plug_id_fkey FOREIGN KEY (plug_id) REFERENCES public.smart_plugs(id) ON DELETE CASCADE;


--
-- Name: smart_plug_meter_incidents smart_plug_meter_incidents_plug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_meter_incidents
    ADD CONSTRAINT smart_plug_meter_incidents_plug_id_fkey FOREIGN KEY (plug_id) REFERENCES public.smart_plugs(id) ON DELETE CASCADE;


--
-- Name: smart_plug_power_history smart_plug_power_history_plug_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plug_power_history
    ADD CONSTRAINT smart_plug_power_history_plug_id_fkey FOREIGN KEY (plug_id) REFERENCES public.smart_plugs(id) ON DELETE CASCADE;


--
-- Name: smart_plugs smart_plugs_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_plugs
    ADD CONSTRAINT smart_plugs_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- Name: smart_sensor_binding_thresholds smart_sensor_binding_thresholds_binding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_binding_thresholds
    ADD CONSTRAINT smart_sensor_binding_thresholds_binding_id_fkey FOREIGN KEY (binding_id) REFERENCES public.smart_sensor_bindings(id) ON DELETE CASCADE;


--
-- Name: smart_sensor_bindings smart_sensor_bindings_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_bindings
    ADD CONSTRAINT smart_sensor_bindings_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: smart_sensor_bindings smart_sensor_bindings_printer_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_bindings
    ADD CONSTRAINT smart_sensor_bindings_printer_location_id_fkey FOREIGN KEY (printer_location_id) REFERENCES public.printer_locations(id) ON DELETE RESTRICT;


--
-- Name: smart_sensor_bindings smart_sensor_bindings_sensor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_bindings
    ADD CONSTRAINT smart_sensor_bindings_sensor_id_fkey FOREIGN KEY (sensor_id) REFERENCES public.smart_sensors(id) ON DELETE CASCADE;


--
-- Name: smart_sensor_bindings smart_sensor_bindings_storage_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_bindings
    ADD CONSTRAINT smart_sensor_bindings_storage_location_id_fkey FOREIGN KEY (storage_location_id) REFERENCES public.locations(id) ON DELETE RESTRICT;


--
-- Name: smart_sensor_history smart_sensor_history_sensor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_history
    ADD CONSTRAINT smart_sensor_history_sensor_id_fkey FOREIGN KEY (sensor_id) REFERENCES public.smart_sensors(id) ON DELETE CASCADE;


--
-- Name: smart_sensor_thresholds smart_sensor_thresholds_sensor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensor_thresholds
    ADD CONSTRAINT smart_sensor_thresholds_sensor_id_fkey FOREIGN KEY (sensor_id) REFERENCES public.smart_sensors(id) ON DELETE CASCADE;


--
-- Name: smart_sensors smart_sensors_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.smart_sensors
    ADD CONSTRAINT smart_sensors_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.printer_locations(id);


--
-- Name: spool_assignment spool_assignment_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_assignment
    ADD CONSTRAINT spool_assignment_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: spool_assignment spool_assignment_spool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_assignment
    ADD CONSTRAINT spool_assignment_spool_id_fkey FOREIGN KEY (spool_id) REFERENCES public.spool(id) ON DELETE CASCADE;


--
-- Name: spool_k_profile spool_k_profile_filament_calibration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_k_profile
    ADD CONSTRAINT spool_k_profile_filament_calibration_id_fkey FOREIGN KEY (filament_calibration_id) REFERENCES public.filament_calibration(id) ON DELETE CASCADE;


--
-- Name: spool_k_profile spool_k_profile_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_k_profile
    ADD CONSTRAINT spool_k_profile_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: spool_k_profile spool_k_profile_spool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_k_profile
    ADD CONSTRAINT spool_k_profile_spool_id_fkey FOREIGN KEY (spool_id) REFERENCES public.spool(id) ON DELETE CASCADE;


--
-- Name: spool spool_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool
    ADD CONSTRAINT spool_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: spool_usage_history spool_usage_history_archive_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_usage_history
    ADD CONSTRAINT spool_usage_history_archive_id_fkey FOREIGN KEY (archive_id) REFERENCES public.print_archives(id);


--
-- Name: spool_usage_history spool_usage_history_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_usage_history
    ADD CONSTRAINT spool_usage_history_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- Name: spool_usage_history spool_usage_history_spool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spool_usage_history
    ADD CONSTRAINT spool_usage_history_spool_id_fkey FOREIGN KEY (spool_id) REFERENCES public.spool(id) ON DELETE CASCADE;


--
-- Name: spoolman_k_profile spoolman_k_profile_filament_calibration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_k_profile
    ADD CONSTRAINT spoolman_k_profile_filament_calibration_id_fkey FOREIGN KEY (filament_calibration_id) REFERENCES public.filament_calibration(id) ON DELETE CASCADE;


--
-- Name: spoolman_k_profile spoolman_k_profile_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_k_profile
    ADD CONSTRAINT spoolman_k_profile_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: spoolman_slot_assignments spoolman_slot_assignments_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spoolman_slot_assignments
    ADD CONSTRAINT spoolman_slot_assignments_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.printers(id) ON DELETE CASCADE;


--
-- Name: stock_issue_lines stock_issue_lines_issue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_issue_lines
    ADD CONSTRAINT stock_issue_lines_issue_id_fkey FOREIGN KEY (issue_id) REFERENCES public.stock_issues(id) ON DELETE CASCADE;


--
-- Name: stock_issue_lines stock_issue_lines_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_issue_lines
    ADD CONSTRAINT stock_issue_lines_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: stock_issues stock_issues_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_issues
    ADD CONSTRAINT stock_issues_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_issues stock_issues_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_issues
    ADD CONSTRAINT stock_issues_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: stock_issues stock_issues_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_issues
    ADD CONSTRAINT stock_issues_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: stock_item_choices stock_item_choices_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_choices
    ADD CONSTRAINT stock_item_choices_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.product_variant_groups(id) ON DELETE CASCADE;


--
-- Name: stock_item_choices stock_item_choices_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_choices
    ADD CONSTRAINT stock_item_choices_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.stock_items(id) ON DELETE CASCADE;


--
-- Name: stock_item_choices stock_item_choices_option_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_choices
    ADD CONSTRAINT stock_item_choices_option_id_fkey FOREIGN KEY (option_id) REFERENCES public.product_variant_options(id);


--
-- Name: stock_item_movements stock_item_movements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_movements
    ADD CONSTRAINT stock_item_movements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: stock_item_movements stock_item_movements_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_movements
    ADD CONSTRAINT stock_item_movements_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: stock_item_movements stock_item_movements_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_movements
    ADD CONSTRAINT stock_item_movements_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.stock_items(id) ON DELETE CASCADE;


--
-- Name: stock_item_movements stock_item_movements_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_movements
    ADD CONSTRAINT stock_item_movements_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE SET NULL;


--
-- Name: stock_item_movements stock_item_movements_project_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_movements
    ADD CONSTRAINT stock_item_movements_project_line_id_fkey FOREIGN KEY (project_line_id) REFERENCES public.project_lines(id) ON DELETE SET NULL;


--
-- Name: stock_item_movements stock_item_movements_stock_issue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_movements
    ADD CONSTRAINT stock_item_movements_stock_issue_id_fkey FOREIGN KEY (stock_issue_id) REFERENCES public.stock_issues(id) ON DELETE SET NULL;


--
-- Name: stock_item_part_counts stock_item_part_counts_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_part_counts
    ADD CONSTRAINT stock_item_part_counts_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.stock_items(id) ON DELETE CASCADE;


--
-- Name: stock_item_part_counts stock_item_part_counts_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_item_part_counts
    ADD CONSTRAINT stock_item_part_counts_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.product_parts(id) ON DELETE CASCADE;


--
-- Name: stock_items stock_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT stock_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: telegram_chats telegram_chats_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE RESTRICT;


--
-- Name: telegram_chats telegram_chats_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.notification_providers(id) ON DELETE CASCADE;


--
-- Name: telegram_chats telegram_chats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_chats
    ADD CONSTRAINT telegram_chats_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_email_preferences user_email_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_email_preferences
    ADD CONSTRAINT user_email_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_filament_presets user_filament_presets_local_preset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_filament_presets
    ADD CONSTRAINT user_filament_presets_local_preset_id_fkey FOREIGN KEY (local_preset_id) REFERENCES public.local_presets(id) ON DELETE CASCADE;


--
-- Name: user_filament_presets user_filament_presets_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_filament_presets
    ADD CONSTRAINT user_filament_presets_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_notifications user_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notifications
    ADD CONSTRAINT user_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_oidc_links user_oidc_links_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT user_oidc_links_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.oidc_providers(id) ON DELETE CASCADE;


--
-- Name: user_oidc_links user_oidc_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oidc_links
    ADD CONSTRAINT user_oidc_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_otp_codes user_otp_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_otp_codes
    ADD CONSTRAINT user_otp_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_totp user_totp_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_totp
    ADD CONSTRAINT user_totp_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: virtual_printers virtual_printers_target_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtual_printers
    ADD CONSTRAINT virtual_printers_target_folder_id_fkey FOREIGN KEY (target_folder_id) REFERENCES public.library_folders(id) ON DELETE SET NULL;


--
-- Name: virtual_printers virtual_printers_target_printer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.virtual_printers
    ADD CONSTRAINT virtual_printers_target_printer_id_fkey FOREIGN KEY (target_printer_id) REFERENCES public.printers(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict Z3ReL7sHyee4FqwFsxVoRGgIcwVImpR1gTchStKKhHkh7eaJW4NbSaSIFp99eKd

